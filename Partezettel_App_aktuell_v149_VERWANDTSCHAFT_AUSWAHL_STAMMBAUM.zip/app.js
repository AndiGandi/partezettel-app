// v95 Kinderliste: Kinderdatensätze werden separat nachgeladen.
// ==========================================================
// Partezettel Archiv – App-Logik
// ==========================================================

// ---------- Sichtbares Debug-Log (funktioniert ohne Mac/Web-Inspector) ----------
function debugLog(msg) {
  const el = document.getElementById("debug-log");
  const zeit = new Date().toLocaleTimeString("de-DE");
  console.log("[Partezettel]", msg);
  if (el) {
    el.textContent += `[${zeit}] ${msg}\n`;
    el.scrollTop = el.scrollHeight;
  }
}

window.addEventListener("error", (e) => {
  debugLog(`❌ JS-FEHLER: ${e.message} (${e.filename}:${e.lineno})`);
});
window.addEventListener("unhandledrejection", (e) => {
  debugLog(`❌ UNBEHANDELTER FEHLER: ${e.reason && e.reason.message ? e.reason.message : e.reason}`);
});

debugLog("App-Skript gestartet.");

document.addEventListener("DOMContentLoaded", () => {
  const clearBtn = document.getElementById("debug-clear");
  if (clearBtn) {
    clearBtn.addEventListener("click", () => {
      document.getElementById("debug-log").textContent = "";
    });
  }
});

let sb = null;
try {
  if (!window.supabase || typeof SUPABASE_URL === "undefined" || typeof SUPABASE_ANON_KEY === "undefined") {
    throw new Error("Supabase-Konfiguration fehlt.");
  }
  if (!SUPABASE_ANON_KEY || SUPABASE_ANON_KEY.includes("HIER_DEINEN_ANON_PUBLIC_KEY_EINFÜGEN")) {
    throw new Error("Supabase-Anon-Key fehlt in config.js.");
  }
  sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  debugLog("Supabase-Client initialisiert.");
} catch (err) {
  debugLog(`⚠️ Supabase nicht initialisiert: ${err.message}`);
}

let currentFotoBlobs = [];
let currentAudioBlob = null;
let mediaRecorder = null;
let audioChunks = [];
let recordStartTime = null;
let isRecording = false;
let personenCache = []; // {id, vorname, nachname, ...}
// Nur für die Auswahlfilter. Diese Daten werden ausschließlich gelesen und
// verändern keine bestehenden Familien- oder Kinderverknüpfungen.
let familienAuswahlCache = [];
let personenVerwandtschaftCache = new Map();
let partnerIdsAuswahlCache = new Set();

// ---------- Anmeldung ----------
async function ensureSession() {
  if (!sb) throw new Error("Supabase ist nicht verfügbar. Bitte config.js prüfen.");
  const { data: { session }, error: getSessionError } = await sb.auth.getSession();
  if (getSessionError) throw getSessionError;
  if (!session) throw new Error("Nicht angemeldet.");
  return session;
}

async function anmelden(email, password) {
  if (!sb) throw new Error("Supabase ist nicht verfügbar. Bitte config.js prüfen.");
  const { data, error } = await sb.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data.session;
}

async function zeigeAppWennAngemeldet() {
  const loginScreen = document.getElementById("login-screen");
  const appShell = document.getElementById("app-shell");
  const loginMessage = document.getElementById("login-message");
  if (!loginScreen || !appShell) return;
  try {
    const { data: { session }, error } = await sb.auth.getSession();
    if (error) throw error;
    if (session) {
      loginScreen.hidden = true;
      appShell.hidden = false;
      debugLog("Angemeldet.");
    } else {
      loginScreen.hidden = false;
      appShell.hidden = true;
    }
  } catch (err) {
    loginScreen.hidden = false;
    appShell.hidden = true;
    if (loginMessage) loginMessage.textContent = err.message;
  }
}

document.addEventListener("DOMContentLoaded", async () => {
  const loginForm = document.getElementById("login-form");
  const loginMessage = document.getElementById("login-message");
  const loginEmail = document.getElementById("login-email");
  const loginPassword = document.getElementById("login-password");
  const logoutBtn = document.getElementById("logout-btn");

  if (loginForm) {
    loginForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      loginMessage.textContent = "Anmeldung …";
      try {
        await anmelden(loginEmail.value.trim(), loginPassword.value);
        loginPassword.value = "";
        loginMessage.textContent = "";
        await zeigeAppWennAngemeldet();
        try { await flushQueue(); } catch (err) { debugLog(`⚠️ Warteschlange nach Anmeldung: ${err.message}`); }
        try { await loadPersonen(); } catch (err) { debugLog(`⚠️ Laden nach Anmeldung: ${err.message}`); }
      } catch (err) {
        loginMessage.textContent = `Anmeldung fehlgeschlagen: ${err.message}`;
      }
    });
  }
  if (logoutBtn) {
    logoutBtn.addEventListener("click", async () => {
      await sb.auth.signOut();
      await zeigeAppWennAngemeldet();
    });
  }
  if (sb) {
    sb.auth.onAuthStateChange((_event, session) => {
      const loginScreen = document.getElementById("login-screen");
      const appShell = document.getElementById("app-shell");
      if (session) {
        loginScreen.hidden = true;
        appShell.hidden = false;
      } else {
        loginScreen.hidden = false;
        appShell.hidden = true;
      }
    });
    await zeigeAppWennAngemeldet();
  }
});

// ---------- Tabs ----------
document.querySelectorAll(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", async () => {
    document.querySelectorAll(".tab-btn").forEach((b) => {
      b.classList.remove("is-active");
      b.setAttribute("aria-selected", "false");
    });
    document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("is-active"));
    // Falls die Personenbearbeitung offen ist, beim Wechsel des Hauptreiters schließen.
    const overlay = document.getElementById("detail-overlay");
    if (overlay) overlay.hidden = true;

    btn.classList.add("is-active");
    btn.setAttribute("aria-selected", "true");
    document.getElementById("tab-" + btn.dataset.tab).classList.add("is-active");
    // Beim Wechsel des Hauptbereichs immer an den Anfang der Ansicht springen.
    // So startet jede Ansicht oben und nicht an der zuletzt gespeicherten
    // Scrollposition der vorherigen Ansicht.
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
    if (btn.dataset.tab === "liste") await loadPersonen();
    if (btn.dataset.tab === "fotos") {
      // Beim direkten Wechsel auf „Fotos“ zuerst die Personen laden,
      // damit die Auswahl nicht leer bleibt, wenn der Cache noch nicht gefüllt ist.
      if (!Array.isArray(personenCache) || personenCache.length === 0) {
        try { await loadPersonen(); } catch (err) {
          debugLog(`⚠️ Personen für Gruppenfotos: ${err.message || err}`);
        }
      }
      fuelleGruppenfotoPersonen();
      await ladeGruppenfotoListe();
    }
    if (btn.dataset.tab === "stammbaum") await loadStammbaum();
  });
});

// ---------- Foto-Aufnahme + Bearbeitung ----------
const fotoInput = document.getElementById("foto-input");
const fotoInputGalerie = document.getElementById("foto-input-galerie");
const fotoStatus = document.getElementById("foto-status");
const fotoPreview = document.getElementById("foto-preview");

let fotoEditorQueue = [];
let fotoEditorResolve = null;
let fotoEditorImage = null;
let fotoEditorRotation = 0;
let fotoEditorCrop = { x: 0, y: 0, w: 1, h: 1 };
let fotoEditorDragging = false;
let fotoEditorDragStart = null;

const photoEditor = document.getElementById("photo-editor");
const photoCanvas = document.getElementById("photo-editor-canvas");
const photoCtx = photoCanvas.getContext("2d");
const fotoEditorBaseCanvas = document.createElement("canvas");
let fotoEditorResize = false;
let fotoEditorResizeX = 0;
let fotoEditorResizeY = 0;

function bildZuDataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

function drawPhotoEditor() {
  if (!fotoEditorImage) return;
  const img = fotoEditorImage;
  const maxW = 1200;
  const scale = Math.min(1, maxW / img.naturalWidth);
  const w = Math.max(1, Math.round(img.naturalWidth * scale));
  const h = Math.max(1, Math.round(img.naturalHeight * scale));
  const rotated = Math.abs(fotoEditorRotation % 180) === 90;
  photoCanvas.width = rotated ? h : w;
  photoCanvas.height = rotated ? w : h;

  // Erst das unverdeckte Bild in ein eigenes Canvas zeichnen.
  fotoEditorBaseCanvas.width = photoCanvas.width;
  fotoEditorBaseCanvas.height = photoCanvas.height;
  const bctx = fotoEditorBaseCanvas.getContext("2d");
  bctx.clearRect(0, 0, fotoEditorBaseCanvas.width, fotoEditorBaseCanvas.height);
  bctx.save();
  bctx.translate(fotoEditorBaseCanvas.width / 2, fotoEditorBaseCanvas.height / 2);
  bctx.rotate(fotoEditorRotation * Math.PI / 180);
  bctx.drawImage(img, -w / 2, -h / 2, w, h);
  bctx.restore();

  photoCtx.clearRect(0, 0, photoCanvas.width, photoCanvas.height);
  photoCtx.drawImage(fotoEditorBaseCanvas, 0, 0);

  const cw = photoCanvas.width * fotoEditorCrop.w;
  const ch = photoCanvas.height * fotoEditorCrop.h;
  const cx = photoCanvas.width * fotoEditorCrop.x;
  const cy = photoCanvas.height * fotoEditorCrop.y;
  photoCtx.save();
  photoCtx.fillStyle = "rgba(0,0,0,.50)";
  photoCtx.fillRect(0, 0, photoCanvas.width, photoCanvas.height);
  photoCtx.globalCompositeOperation = "destination-out";
  photoCtx.fillRect(cx, cy, cw, ch);
  photoCtx.globalCompositeOperation = "source-over";
  photoCtx.strokeStyle = "white";
  photoCtx.lineWidth = Math.max(3, photoCanvas.width / 300);
  photoCtx.strokeRect(cx, cy, cw, ch);
  // Ecken als sichtbare Griffe
  const r = Math.max(12, photoCanvas.width / 45);
  photoCtx.fillStyle = "white";
  [[cx,cy],[cx+cw,cy],[cx,cy+ch],[cx+cw,cy+ch]].forEach(([x,y]) => photoCtx.fillRect(x-r/2,y-r/2,r,r));
  photoCtx.restore();
}

function openPhotoEditor(file) {
  return new Promise(async resolve => {
    fotoEditorResolve = resolve;
    fotoEditorRotation = 0;
    fotoEditorCrop = { x: 0, y: 0, w: 1, h: 1 };
    fotoEditorImage = await loadImage(await bildZuDataURL(file));
    photoEditor.hidden = false;
    syncCropControls();
    drawPhotoEditor();
  });
}

function closePhotoEditor(result) {
  photoEditor.hidden = true;
  const resolve = fotoEditorResolve;
  fotoEditorResolve = null;
  fotoEditorImage = null;
  if (resolve) resolve(result);
}

async function blobZuJPEGUnter200KB(blob) {
  if (!blob) return null;
  const MAX_BYTES = 200 * 1024;
  if (blob.size <= MAX_BYTES && blob.type === "image/jpeg") return new File([blob], "partezettel.jpg", { type: "image/jpeg" });

  const img = await loadImage(await bildZuDataURL(blob));
  let scale = 1;
  let quality = 0.82;

  const encode = (width, height, q) => new Promise(resolve => {
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(width));
    canvas.height = Math.max(1, Math.round(height));
    const ctx = canvas.getContext("2d", { alpha: false });
    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    canvas.toBlob(resolve, "image/jpeg", q);
  });

  // Zuerst nur die JPEG-Qualität reduzieren. Erst wenn das nicht reicht,
  // wird die Auflösung schrittweise reduziert. Dadurch bleiben kleine Bilder
  // und bereits gut komprimierte Fotos unverändert bzw. möglichst groß.
  for (let attempt = 0; attempt < 8; attempt++) {
    const candidate = await encode(img.naturalWidth * scale, img.naturalHeight * scale, quality);
    if (candidate && candidate.size <= MAX_BYTES) {
      return new File([candidate], "partezettel.jpg", { type: "image/jpeg" });
    }
    if (quality > 0.42) {
      quality -= 0.08;
    } else {
      scale *= 0.88;
      quality = 0.76;
    }
  }

  // Letzter Versuch mit stärkerer Reduzierung, damit das Ziel auch bei
  // sehr detailreichen Bildern möglichst zuverlässig erreicht wird.
  while (scale > 0.25) {
    const candidate = await encode(img.naturalWidth * scale, img.naturalHeight * scale, 0.68);
    if (candidate && candidate.size <= MAX_BYTES) {
      return new File([candidate], "partezettel.jpg", { type: "image/jpeg" });
    }
    scale *= 0.82;
  }
  const fallback = await encode(img.naturalWidth * scale, img.naturalHeight * scale, 0.60);
  return fallback ? new File([fallback], "partezettel.jpg", { type: "image/jpeg" }) : null;
}

function exportEditedPhoto() {
  if (!fotoEditorImage || !fotoEditorBaseCanvas.width) return null;
  const src = fotoEditorBaseCanvas;
  const x = Math.max(0, Math.round(src.width * fotoEditorCrop.x));
  const y = Math.max(0, Math.round(src.height * fotoEditorCrop.y));
  const w = Math.max(1, Math.min(src.width - x, Math.round(src.width * fotoEditorCrop.w)));
  const h = Math.max(1, Math.min(src.height - y, Math.round(src.height * fotoEditorCrop.h)));
  const out = document.createElement("canvas");
  out.width = w; out.height = h;
  out.getContext("2d").drawImage(src, x, y, w, h, 0, 0, w, h);
  return new Promise(resolve => out.toBlob(async blob => resolve(blob ? await blobZuJPEGUnter200KB(blob) : null), "image/jpeg", .92));
}

async function bearbeiteFotos(files) {
  const result = [];
  for (const file of Array.from(files || [])) {
    const edited = await openPhotoEditor(file);
    if (edited) result.push(edited);
  }
  return result;
}

async function handleFotoAuswahl(files) {
  const auswahl = Array.from(files || []).filter(Boolean);
  if (!auswahl.length) return;
  const bearbeitet = await bearbeiteFotos(auswahl);
  if (!bearbeitet.length) return;
  currentFotoBlobs.push(...bearbeitet);
  fotoStatus.textContent = currentFotoBlobs.length === 1 ? "1 Foto ausgewählt ✓" : `${currentFotoBlobs.length} Fotos ausgewählt ✓`;
  if (fotoWeiterBtn) fotoWeiterBtn.hidden = false;
  const url = URL.createObjectURL(currentFotoBlobs[0]);
  fotoPreview.src = url;
  fotoPreview.hidden = false;
  fotoPreview.style.display = "block";
}

fotoInput.addEventListener("change", async () => { await handleFotoAuswahl(fotoInput.files); fotoInput.value = ""; });
const fotoWeiterBtn = document.getElementById("foto-weiter-btn");
if (fotoWeiterBtn) fotoWeiterBtn.addEventListener("click", () => fotoInput.click());

// ---------- Sprachaufnahme (kein Zeitlimit) ----------
const audioBtn = document.getElementById("audio-record-btn");
const audioStatus = document.getElementById("audio-status");
const audioPreview = document.getElementById("audio-preview");

function pickAudioMimeType() {
  const candidates = [
    "audio/mp4",
    "audio/webm;codecs=opus",
    "audio/webm",
    "audio/ogg;codecs=opus",
  ];
  for (const type of candidates) {
    if (window.MediaRecorder && MediaRecorder.isTypeSupported(type)) return type;
  }
  return "";
}

let currentAudioMimeType = "audio/webm";
let currentAudioExt = "webm";

if (audioBtn && audioStatus && audioPreview) {
  audioBtn.addEventListener("click", async () => {
    if (!isRecording) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const chosenType = pickAudioMimeType();
        mediaRecorder = chosenType ? new MediaRecorder(stream, { mimeType: chosenType }) : new MediaRecorder(stream);
        audioChunks = [];
        mediaRecorder.ondataavailable = (e) => audioChunks.push(e.data);
        mediaRecorder.onstop = () => {
          currentAudioMimeType = mediaRecorder.mimeType || chosenType || "audio/webm";
          currentAudioExt = currentAudioMimeType.includes("mp4") ? "m4a"
            : currentAudioMimeType.includes("ogg") ? "ogg"
            : "webm";
          currentAudioBlob = new Blob(audioChunks, { type: currentAudioMimeType });
          const url = URL.createObjectURL(currentAudioBlob);
          audioPreview.src = url;
          audioPreview.hidden = false;
          const dauer = Math.round((Date.now() - recordStartTime) / 1000);
          audioStatus.textContent = `Aufnahme: ${dauer}s ✓`;
          stream.getTracks().forEach((t) => t.stop());
        };
        mediaRecorder.start();
        recordStartTime = Date.now();
        isRecording = true;
        audioBtn.textContent = "⏹️ Aufnahme stoppen";
        audioStatus.textContent = "Aufnahme läuft …";
      } catch (err) {
        audioStatus.textContent = "Mikrofonzugriff fehlgeschlagen";
        debugLog(`❌ Mikrofon: ${err.message || err}`);
      }
    } else {
      mediaRecorder.stop();
      isRecording = false;
      audioBtn.textContent = "🎙️ Aufnahme starten";
    }
  });
}
fotoInputGalerie.addEventListener("change", async () => { await handleFotoAuswahl(fotoInputGalerie.files); fotoInputGalerie.value = ""; });

document.getElementById("photo-rotate-left").addEventListener("click", () => { fotoEditorRotation -= 90; drawPhotoEditor(); });
document.getElementById("photo-rotate-right").addEventListener("click", () => { fotoEditorRotation += 90; drawPhotoEditor(); });
document.getElementById("photo-reset").addEventListener("click", () => { fotoEditorRotation=0; fotoEditorCrop={x:0,y:0,w:1,h:1}; syncCropControls(); drawPhotoEditor(); });
const cropLeft = document.getElementById("crop-left");
const cropRight = document.getElementById("crop-right");
const cropTop = document.getElementById("crop-top");
const cropBottom = document.getElementById("crop-bottom");
function syncCropControls() {
  if (!cropLeft) return;
  cropLeft.value = Math.round(fotoEditorCrop.x * 100);
  cropRight.value = Math.round((1 - (fotoEditorCrop.x + fotoEditorCrop.w)) * 100);
  cropTop.value = Math.round(fotoEditorCrop.y * 100);
  cropBottom.value = Math.round((1 - (fotoEditorCrop.y + fotoEditorCrop.h)) * 100);
}
function updateCropFromControls() {
  if (!cropLeft) return;
  let l=Number(cropLeft.value)/100, r=Number(cropRight.value)/100, t=Number(cropTop.value)/100, b=Number(cropBottom.value)/100;
  if (l+r>0.90) { r=Math.min(r,0.90-l); cropRight.value=Math.round(r*100); }
  if (t+b>0.90) { b=Math.min(b,0.90-t); cropBottom.value=Math.round(b*100); }
  fotoEditorCrop={x:l,y:t,w:1-l-r,h:1-t-b};
  drawPhotoEditor();
}
[cropLeft,cropRight,cropTop,cropBottom].filter(Boolean).forEach(el=>el.addEventListener("input", updateCropFromControls));
document.getElementById("photo-cancel").addEventListener("click", () => closePhotoEditor(null));
document.getElementById("photo-apply").addEventListener("click", async () => closePhotoEditor(await exportEditedPhoto()));

function clampCrop() {
  fotoEditorCrop.w = Math.max(.08, Math.min(1, fotoEditorCrop.w));
  fotoEditorCrop.h = Math.max(.08, Math.min(1, fotoEditorCrop.h));
  fotoEditorCrop.x = Math.max(0, Math.min(1 - fotoEditorCrop.w, fotoEditorCrop.x));
  fotoEditorCrop.y = Math.max(0, Math.min(1 - fotoEditorCrop.h, fotoEditorCrop.y));
}

function photoCanvasPoint(e) {
  const rect = photoCanvas.getBoundingClientRect();
  return {
    x: Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width)),
    y: Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height)),
  };
}

photoCanvas.addEventListener("pointerdown", e => {
  if (!fotoEditorImage) return;
  const p = photoCanvasPoint(e);
  const c = fotoEditorCrop;
  const edge = Math.max(0.025, 18 / Math.max(photoCanvas.width, photoCanvas.height));
  const nearL = Math.abs(p.x - c.x) < edge;
  const nearR = Math.abs(p.x - (c.x + c.w)) < edge;
  const nearT = Math.abs(p.y - c.y) < edge;
  const nearB = Math.abs(p.y - (c.y + c.h)) < edge;
  const nearCorner = (nearL || nearR) && (nearT || nearB);
  const inside = p.x >= c.x && p.x <= c.x + c.w && p.y >= c.y && p.y <= c.y + c.h;
  if (!nearCorner && !inside) return;
  fotoEditorDragging = true;
  fotoEditorResize = nearCorner;
  fotoEditorResizeX = nearR ? 1 : (nearL ? -1 : 0);
  fotoEditorResizeY = nearB ? 1 : (nearT ? -1 : 0);
  photoCanvas.setPointerCapture?.(e.pointerId);
  fotoEditorDragStart = { x:p.x, y:p.y, cx:c.x, cy:c.y, cw:c.w, ch:c.h };
  e.preventDefault();
});

photoCanvas.addEventListener("pointermove", e => {
  if (!fotoEditorDragging) return;
  const p = photoCanvasPoint(e);
  const dx = p.x - fotoEditorDragStart.x;
  const dy = p.y - fotoEditorDragStart.y;
  const s = fotoEditorDragStart;
  if (fotoEditorResize) {
    let nx=s.cx, ny=s.cy, nw=s.cw, nh=s.ch;
    if (fotoEditorResizeX > 0) nw=s.cw+dx;
    if (fotoEditorResizeX < 0) { nx=s.cx+dx; nw=s.cw-dx; }
    if (fotoEditorResizeY > 0) nh=s.ch+dy;
    if (fotoEditorResizeY < 0) { ny=s.cy+dy; nh=s.ch-dy; }
    fotoEditorCrop={x:nx,y:ny,w:nw,h:nh};
  } else {
    fotoEditorCrop.x=s.cx+dx;
    fotoEditorCrop.y=s.cy+dy;
  }
  clampCrop();
  syncCropControls();
  drawPhotoEditor();
  e.preventDefault();
});

photoCanvas.addEventListener("pointerup", () => { fotoEditorDragging=false; fotoEditorResize=false; });
photoCanvas.addEventListener("pointercancel", () => { fotoEditorDragging=false; fotoEditorResize=false; });

// ---------- Datumsauswahl ----------
const MONATE = ["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];
function initDatum(prefix) {
  const tag=document.getElementById(prefix+"-tag"), monat=document.getElementById(prefix+"-monat"), jahr=document.getElementById(prefix+"-jahr");
  if (!tag || !monat || !jahr) return;
  initDatumElemente(tag, monat, jahr);
}
function initDatumElemente(tag, monat, jahr) {
  // Dynamische Partnerschaftsblöcke werden direkt über ihre Elemente initialisiert.
  // Dadurch ist die Datumsauswahl unabhängig von dynamisch vergebenen DOM-IDs.
  tag.replaceChildren(new Option("Tag", ""));
  for(let i=1;i<=31;i++) tag.appendChild(new Option(String(i), String(i).padStart(2,"0")));
  monat.replaceChildren(new Option("Monat", ""));
  MONATE.forEach((m,i)=>monat.appendChild(new Option(m, String(i+1).padStart(2,"0"))));
  jahr.replaceChildren(new Option("Jahr", ""));
  for(let y=new Date().getFullYear();y>=1600;y--) jahr.appendChild(new Option(String(y), String(y)));
}
function initJahrOnly(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.replaceChildren(new Option("Jahr", ""));
  for (let y = new Date().getFullYear(); y >= 1600; y--) {
    el.appendChild(new Option(String(y), String(y)));
  }
}

function getDatumElemente(tag, monat, jahr) {
  const t = tag?.value || "";
  const m = monat?.value || "";
  const y = jahr?.value || "";
  return t && m && y ? `${y}-${m}-${t}` : null;
}
function getDatum(prefix) {
  const t=document.getElementById(prefix+"-tag")?.value, m=document.getElementById(prefix+"-monat")?.value, y=document.getElementById(prefix+"-jahr")?.value;
  return t&&m&&y ? `${y}-${m}-${t}` : null;
}
function setDatum(prefix, value) {
  const t=document.getElementById(prefix+"-tag"),m=document.getElementById(prefix+"-monat"),y=document.getElementById(prefix+"-jahr");
  if(!t||!m||!y) return;
  setDatumElemente(t,m,y,value);
}
function setDatumElemente(t,m,y,value) {
  if(!value){t.value="";m.value="";y.value="";return;}
  const teile=String(value).slice(0,10).split("-");
  const yy=teile[0]||"", mm=teile[1]||"", dd=teile[2]||"";
  // Nur Werte auswählen, die in den jeweiligen Selects tatsächlich vorhanden sind.
  // So bleiben vollständige Daten sichtbar und Teilangaben (z. B. nur Jahr) möglich.
  y.value=/^\d{4}$/.test(yy) ? yy : "";
  m.value=/^\d{2}$/.test(mm) ? mm : "";
  t.value=/^\d{2}$/.test(dd) ? dd : "";
}
function setDatumJahr(prefix, jahr) {
  const t=document.getElementById(prefix+"-tag"),m=document.getElementById(prefix+"-monat"),y=document.getElementById(prefix+"-jahr");
  if(!t||!m||!y) return;
  setDatumJahrElemente(t,m,y,jahr);
}
function setDatumJahrElemente(t,m,y,jahr) {
  t.value="";
  m.value="";
  y.value=/^\d{4}$/.test(String(jahr||"")) ? String(jahr) : "";
}
["geburtsdatum","sterbedatum","d-geburtsdatum","d-sterbedatum","d-partner-beginn","d-partner-ende"].forEach(initDatum);
["geburtsjahr","sterbejahr","d-geburtsjahr","d-sterbejahr"].forEach(initJahrOnly);

// Vollständiges Datum und "nur Jahr bekannt" schließen sich gegenseitig aus.
// Bei einem vollständigen Datum wird das reine Jahresfeld gesperrt; bei einem
// reinen Jahr werden Tag/Monat/Jahr des vollständigen Datums gesperrt.
function synchronisiereNurJahrFeld(datumPrefix, jahrOnlyId) {
  const tag = document.getElementById(`${datumPrefix}-tag`);
  const monat = document.getElementById(`${datumPrefix}-monat`);
  const jahr = document.getElementById(`${datumPrefix}-jahr`);
  const nurJahr = document.getElementById(jahrOnlyId);
  if (!tag || !monat || !jahr || !nurJahr) return;

  const aktualisieren = () => {
    const vollstaendig = !!(tag.value && monat.value && jahr.value);
    const nurJahrGewaeht = !!nurJahr.value;

    if (vollstaendig) {
      nurJahr.value = "";
      nurJahr.disabled = true;
      tag.disabled = false;
      monat.disabled = false;
      jahr.disabled = false;
    } else if (nurJahrGewaeht) {
      tag.value = "";
      monat.value = "";
      jahr.value = "";
      tag.disabled = true;
      monat.disabled = true;
      jahr.disabled = true;
      nurJahr.disabled = false;
    } else {
      nurJahr.disabled = false;
      tag.disabled = false;
      monat.disabled = false;
      jahr.disabled = false;
    }
  };

  if (!nurJahr.dataset.syncInit) {
    [tag, monat, jahr, nurJahr].forEach((el) => el.addEventListener("change", aktualisieren));
    nurJahr.dataset.syncInit = "1";
  }
  aktualisieren();
}

synchronisiereNurJahrFeld("geburtsdatum", "geburtsjahr");
synchronisiereNurJahrFeld("sterbedatum", "sterbejahr");
synchronisiereNurJahrFeld("d-geburtsdatum", "d-geburtsjahr");
synchronisiereNurJahrFeld("d-sterbedatum", "d-sterbejahr");

// ---------- Formular absenden ----------
const form = document.getElementById("person-form");
const formMessage = document.getElementById("form-message");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  debugLog("Formular abgeschickt – Verarbeitung startet.");
  formMessage.textContent = "Speichere …";

  const eintrag = {
    id: crypto.randomUUID(),
    vorname: document.getElementById("vorname").value.trim(),
    nachname: document.getElementById("nachname").value.trim(),
    geschlecht: document.getElementById("geschlecht").value || null,
    ledigenname: document.getElementById("ledigenname").value.trim() || null,
    geburtsdatum: getDatum("geburtsdatum"),
    geburtsjahr: getDatum("geburtsdatum") ? null : (document.getElementById("geburtsjahr").value.trim() ? Number(document.getElementById("geburtsjahr").value.trim()) : null),
    sterbedatum: getDatum("sterbedatum"),
    sterbejahr: getDatum("sterbedatum") ? null : (document.getElementById("sterbejahr").value.trim() ? Number(document.getElementById("sterbejahr").value.trim()) : null),
    taufbuch_link: document.getElementById("taufbuch-link").value.trim() || null,
    trauungsbuch_link: document.getElementById("trauungsbuch-link").value.trim() || null,
    sterbebuch_link: document.getElementById("sterbebuch-link").value.trim() || null,
    taufbuch_zeile: document.getElementById("taufbuch-zeile").value.trim() ? Number(document.getElementById("taufbuch-zeile").value) : null,
    trauungsbuch_zeile: document.getElementById("trauungsbuch-zeile").value.trim() ? Number(document.getElementById("trauungsbuch-zeile").value) : null,
    sterbebuch_zeile: document.getElementById("sterbebuch-zeile").value.trim() ? Number(document.getElementById("sterbebuch-zeile").value) : null,
    notiz: document.getElementById("notiz").value.trim() || null,
    fotos: currentFotoBlobs,
    audio: currentAudioBlob,
    audio_dauer: audioPreview.hidden ? null : Math.round((audioPreview.duration || 0)),
  };

  if (!eintrag.vorname || !eintrag.nachname) {
    formMessage.textContent = "Bitte Vor- und Nachname eintragen.";
    return;
  }

  if (navigator.onLine) {
    const result = await sendEintrag(eintrag, (msg) => { formMessage.textContent = msg; });
    if (result.ok) {
      formMessage.textContent = "Gespeichert ✓";
      resetForm();
    } else {
      await queueEintrag(eintrag);
      formMessage.textContent = `Fehler: ${result.error} — In Warteschlange gespeichert, wird später erneut versucht.`;
      resetForm();
    }
  } else {
    await queueEintrag(eintrag);
    formMessage.textContent = "Offline – Eintrag wird gesendet, sobald wieder Verbindung besteht.";
    resetForm();
  }
});

function resetForm() {
  form.reset();
  ["geburtsdatum","sterbedatum"].forEach(p=>setDatum(p,null));
  document.getElementById("geburtsjahr").value = "";
  document.getElementById("sterbejahr").value = "";
  document.getElementById("taufbuch-link").value = "";
  document.getElementById("trauungsbuch-link").value = "";
  document.getElementById("sterbebuch-link").value = "";
  document.getElementById("taufbuch-zeile").value = "";
  document.getElementById("trauungsbuch-zeile").value = "";
  document.getElementById("sterbebuch-zeile").value = "";
  document.getElementById("ledigenname").value = "";

  // Neue Person beginnt nach dem Speichern garantiert ohne alte Medien.
  currentFotoBlobs = [];
  if (fotoWeiterBtn) fotoWeiterBtn.hidden = true;
  if (fotoPreview) {
    const oldUrl = fotoPreview.src;
    fotoPreview.hidden = true;
    fotoPreview.setAttribute("hidden", "");
    fotoPreview.style.setProperty("display", "none", "important");
    fotoPreview.removeAttribute("src");
    if (oldUrl && oldUrl.startsWith("blob:")) URL.revokeObjectURL(oldUrl);
  }
  if (fotoInput) fotoInput.value = "";
  if (fotoInputGalerie) fotoInputGalerie.value = "";

  currentAudioBlob = null;
  audioChunks = [];
  if (audioPreview) {
    audioPreview.hidden = true;
    audioPreview.removeAttribute("src");
  }
  if (audioStatus) audioStatus.textContent = "Keine Aufnahme";
  if (fotoStatus) fotoStatus.textContent = "Kein Foto ausgewählt";
}

function mitTimeout(promise, ms, meldung) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(meldung)), ms)),
  ]);
}

// ---------- Eintrag an Supabase senden ----------
async function sendEintrag(eintrag, onProgress) {
  const step = (msg) => { if (onProgress) onProgress(msg); debugLog(msg); };
  try {
    step("Schritt 1/4: Anmelden …");
    await mitTimeout(
      ensureSession(),
      15000,
      "Zeitüberschreitung bei der Anmeldung (Netzwerk antwortet nicht)"
    );

    step("Schritt 2/4: Person speichern …");
    const { error: personError } = await mitTimeout(
      sb.from("personen").upsert({
        id: eintrag.id,
        vorname: eintrag.vorname,
        nachname: eintrag.nachname,
        geschlecht: eintrag.geschlecht,
        "Ledigenname": eintrag.ledigenname,
        geburtsdatum: eintrag.geburtsdatum,
        geburtsjahr: eintrag.geburtsjahr,
        sterbedatum: eintrag.sterbedatum,
        sterbejahr: eintrag.sterbejahr,
        taufbuch_link: eintrag.taufbuch_link,
        trauungsbuch_link: eintrag.trauungsbuch_link,
        sterbebuch_link: eintrag.sterbebuch_link,
        taufbuch_zeile: eintrag.taufbuch_zeile,
        trauungsbuch_zeile: eintrag.trauungsbuch_zeile,
        sterbebuch_zeile: eintrag.sterbebuch_zeile,
        Notiz: eintrag.notiz,
      }, { onConflict: "id" }),
      15000,
      "Zeitüberschreitung beim Speichern der Person (Netzwerk antwortet nicht)"
    );
    if (personError) throw personError;

    // 2. Fotos hochladen
    if (eintrag.fotos && eintrag.fotos.length) {
      step(`Schritt 3/4: ${eintrag.fotos.length} Foto${eintrag.fotos.length === 1 ? "" : "s"} hochladen …`);
      for (const foto of eintrag.fotos) {
        const ext = foto.type && foto.type.includes("png") ? "png" : foto.type && foto.type.includes("webp") ? "webp" : "jpg";
        const path = `${eintrag.id}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
        if (!foto || typeof foto.arrayBuffer !== "function") {
          throw new Error("Foto-Daten konnten nicht gelesen werden");
        }
        const fotoDaten = await foto.arrayBuffer();
        if (!fotoDaten || fotoDaten.byteLength === 0) {
          throw new Error("Foto enthält keine Bilddaten");
        }
        const { error: uploadError } = await mitTimeout(
          sb.storage.from(BUCKET_FOTOS).upload(path, fotoDaten, {
            contentType: foto.type || "image/jpeg",
            upsert: false,
          }),
          20000,
          "Zeitüberschreitung beim Foto-Upload (Netzwerk antwortet nicht)"
        );
        if (uploadError) throw uploadError;
        const { error: insertError } = await sb.from("fotos").insert({ personen_id: eintrag.id, dateipfad: path });
        if (insertError) throw insertError;
      }
    }

    // 3. Sprachnotiz hochladen
    if (eintrag.audio) {
      step("Schritt 4/4: Sprachnotiz hochladen …");
      const ext = eintrag.audio.type && eintrag.audio.type.includes("mp4") ? "m4a"
        : eintrag.audio.type && eintrag.audio.type.includes("ogg") ? "ogg"
        : "webm";
      const path = `${eintrag.id}/${Date.now()}.${ext}`;
      const { error: uploadError } = await mitTimeout(
        sb.storage.from(BUCKET_AUDIO).upload(path, eintrag.audio),
        20000,
        "Zeitüberschreitung beim Audio-Upload (Netzwerk antwortet nicht)"
      );
      if (uploadError) throw uploadError;
      await sb.from("sprachnotizen").insert({
        person_id: eintrag.id,
        dateipfad: path,
        dauer_sekunden: eintrag.audio_dauer,
      });
    }

    return { ok: true };
  } catch (err) {
    console.error("Senden fehlgeschlagen:", err);
    const meldung = (err && (err.message || err.error_description || err.msg)) || "Unbekannter Fehler";
    debugLog(`❌ Fehler: ${meldung}`);
    return { ok: false, error: meldung };
  }
}

// ---------- Offline-Warteschlange (IndexedDB) ----------
const DB_NAME = "partezettel-queue";
const STORE_NAME = "eintraege";

function openQueueDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      req.result.createObjectStore(STORE_NAME, { keyPath: "id" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function queueEintrag(eintrag) {
  const db = await openQueueDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).put(eintrag);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function getQueue() {
  const db = await openQueueDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const req = tx.objectStore(STORE_NAME).getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function removeFromQueue(id) {
  const db = await openQueueDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function flushQueue() {
  const queue = await getQueue();
  const banner = document.getElementById("pending-banner");
  if (queue.length === 0) {
    banner.hidden = true;
    return;
  }
  banner.hidden = false;
  banner.textContent = `${queue.length} wartende Einträge werden gesendet …`;

  for (const eintrag of queue) {
    const result = await sendEintrag(eintrag);
    if (result.ok) await removeFromQueue(eintrag.id);
  }

  const remaining = await getQueue();
  if (remaining.length === 0) {
    banner.hidden = true;
  } else {
    banner.textContent = `${remaining.length} Einträge warten noch auf Verbindung.`;
  }
}

window.addEventListener("online", flushQueue);


let personenSortierung = "name";
let personenSortRichtung = 1;
function sortierJahr(person, feld) {
  if (feld === "geburtsjahr") return person.geburtsdatum ? Number(String(person.geburtsdatum).slice(0,4)) : (person.geburtsjahr ? Number(person.geburtsjahr) : null);
  if (feld === "sterbejahr") return person.sterbedatum ? Number(String(person.sterbedatum).slice(0,4)) : (person.sterbejahr ? Number(person.sterbejahr) : null);
  return null;
}
function lebensalterInTagen(person) {
  if (!person?.geburtsdatum && !person?.geburtsjahr) return null;
  const geburt = person.geburtsdatum ? new Date(`${person.geburtsdatum}T00:00:00`) : new Date(`${person.geburtsjahr}-07-01T00:00:00`);
  if (Number.isNaN(geburt.getTime())) return null;

  // Ein Sterbejahr ohne genaues Sterbedatum wird ebenfalls berücksichtigt.
  // Fehlen Sterbedatum UND Sterbejahr, darf kein aktuelles Datum als Todestag
  // angenommen werden – sonst entstehen bei historischen Personen falsche
  // Altersangaben von weit über 100 Jahren.
  let ende = null;
  if (person.sterbedatum) {
    ende = new Date(`${person.sterbedatum}T00:00:00`);
  } else if (person.sterbejahr) {
    const jahr = Number(person.sterbejahr);
    if (!Number.isInteger(jahr) || jahr < 1000 || jahr > 3000) return null;
    ende = new Date(`${jahr}-12-31T00:00:00`);
  } else {
    return null;
  }
  if (Number.isNaN(ende.getTime()) || ende < geburt) return null;
  return Math.floor((ende - geburt) / 86400000);
}
function lebensalterAnzeige(person) {
  const tage = lebensalterInTagen(person);
  if (tage === null) return "";
  const jahre = Math.floor(tage / 365.2425);
  // Nur das Sterbejahr bekannt -> Alter ist nur ungefähr bestimmbar.
  const nurSterbejahr = !person.sterbedatum && !!person.sterbejahr;
  return `${nurSterbejahr ? "ca. " : ""}${jahre} Jahre`;
}
function personenVergleich(a,b) {
  if (personenSortierung === "alter") {
    const aa=lebensalterInTagen(a), ab=lebensalterInTagen(b);
    if (aa===null && ab!==null) return 1; if (aa!==null && ab===null) return -1;
    if (aa!==null && ab!==null && aa!==ab) return aa-ab;
  } else if (personenSortierung === "geburtsjahr" || personenSortierung === "sterbejahr") {
    const ay=sortierJahr(a,personenSortierung), by=sortierJahr(b,personenSortierung);
    if (ay===null && by!==null) return 1; if (ay!==null && by===null) return -1;
    if (ay!==null && by!==null && ay!==by) return ay-by;
  } else if (personenSortierung === "erstellt") {
    const at=new Date(a.created_at||a.erstellt_am||0).getTime(), bt=new Date(b.created_at||b.erstellt_am||0).getTime();
    if (at!==bt) return bt-at;
  } else if (personenSortierung === "familie") {
    const af=String(a._familienSortKey||a.nachname||"").toLocaleLowerCase("de"), bf=String(b._familienSortKey||b.nachname||"").toLocaleLowerCase("de");
    const fc=af.localeCompare(bf,"de"); if(fc) return fc;
  }
  const nc=String(a.nachname||"").localeCompare(String(b.nachname||""),"de",{sensitivity:"base"});
  return nc || String(a.vorname||"").localeCompare(String(b.vorname||""),"de",{sensitivity:"base"});
}
function sortierePersonen(personen) { return [...personen].sort((a,b)=>personenVergleich(a,b)*personenSortRichtung); }
function personenAuswahlText(person) {
  if (!person) return "(unbekannte Person)";
  const nachname = String(person.nachname || "").trim();
  const vorname = String(person.vorname || "").trim();
  const name = [nachname, vorname].filter(Boolean).join(", ") || "(unbekannte Person)";
  const ledigenname = String(person.Ledigenname || "").trim();
  const geburtsjahr = person.geburtsdatum ? String(person.geburtsdatum).slice(0, 4) : (person.geburtsjahr ? String(person.geburtsjahr) : "");
  const sterbejahr = person.sterbedatum ? String(person.sterbedatum).slice(0, 4) : (person.sterbejahr ? String(person.sterbejahr) : "");
  let text = name;
  if (ledigenname && ledigenname.toLocaleLowerCase("de") !== nachname.toLocaleLowerCase("de")) {
    text += ` (geb. ${ledigenname})`;
  }
  if (/^\d{4}$/.test(geburtsjahr)) text += ` (geb. ${geburtsjahr})`;
  if (/^\d{4}$/.test(sterbejahr)) text += ` (gest. ${sterbejahr})`;
  return text;
}

function personenAuswahlSortierung(a, b) {
  const an = String(a?.nachname || "").trim();
  const bn = String(b?.nachname || "").trim();
  const n = an.localeCompare(bn, "de", { sensitivity: "base" });
  if (n) return n;
  const av = String(a?.vorname || "").trim();
  const bv = String(b?.vorname || "").trim();
  const v = av.localeCompare(bv, "de", { sensitivity: "base" });
  if (v) return v;
  const ay = Number(a?.geburtsjahr || (a?.geburtsdatum ? String(a.geburtsdatum).slice(0,4) : 0)) || 0;
  const by = Number(b?.geburtsjahr || (b?.geburtsdatum ? String(b.geburtsdatum).slice(0,4) : 0)) || 0;
  if (ay && by) return ay - by;
  if (ay) return -1;
  if (by) return 1;
  return String(a?.id || "").localeCompare(String(b?.id || ""));
}

function berechneFamilienSortKeys(personen,familien) {
  const ids=new Set(personen.map(p=>p.id)), adj=new Map(personen.map(p=>[p.id,new Set()]));
  for(const f of familien||[]) { const a=f.partner_a_id,b=f.partner_b_id; if(ids.has(a)&&ids.has(b)){adj.get(a).add(b);adj.get(b).add(a);} for(const k of f._kinder||[]){if(!ids.has(k))continue;if(ids.has(a)){adj.get(a).add(k);adj.get(k).add(a);}if(ids.has(b)){adj.get(b).add(k);adj.get(k).add(b);}}}
  const byId=new Map(personen.map(p=>[p.id,p])),seen=new Set();
  for(const p of personen){if(seen.has(p.id))continue;const stack=[p.id],comp=[];seen.add(p.id);while(stack.length){const id=stack.pop();comp.push(id);for(const n of adj.get(id)||[]){if(!seen.has(n)){seen.add(n);stack.push(n);}}}const key=comp.map(id=>byId.get(id)?.nachname||"").filter(Boolean).sort((x,y)=>x.localeCompare(y,"de",{sensitivity:"base"}))[0]||p.nachname||"";for(const id of comp)byId.get(id)._familienSortKey=key; }
}


// Wenn ein Todesdatum nachträglich erfasst wird, wird ein noch offenes
// Ehe-/Partnerschaftsende automatisch mit diesem Datum befüllt.
// Ein bereits vorhandenes Ende (z. B. Scheidung) wird niemals überschrieben.
// Bei ausschließlich bekanntem Sterbejahr bleibt das Datenbankfeld "ende"
// leer; die bestehende Anzeige kennzeichnet die Partnerschaft dennoch als
// durch den Tod beendet.
async function synchronisierePartnerschaftsEndeBeiTod(personId, sterbedatum, sterbejahr) {
  if (!personId || (!sterbedatum && !sterbejahr)) return;

  const { data: familien, error } = await sb
    .from("familien")
    .select("id, partner_a_id, partner_b_id, familientyp, beginn, ende, ende_automatik_ignorieren")
    .or(`partner_a_id.eq.${personId},partner_b_id.eq.${personId}`);

  if (error) throw error;

  const typErlaubt = (typ) => {
    const t = String(typ || "").trim().toLocaleLowerCase("de");
    return t === "ehe" || t === "partnerschaft";
  };

  for (const familie of familien || []) {
    if (!typErlaubt(familie.familientyp) || familie.ende || familie.ende_automatik_ignorieren) continue;

    if (sterbedatum) {
      const { error: updateError } = await sb
        .from("familien")
        .update({ ende: sterbedatum })
        .eq("id", familie.id)
        .is("ende", null);

      if (updateError) throw updateError;
    }
    // Bei einem reinen Sterbejahr kein künstliches Datum speichern.
    // partnerschaftTodesende() liefert das Jahr weiterhin für die Anzeige.
  }
}

// ---------- Partnerschaftslogik ----------
function datumAnzeige(datum) {
  if (!datum) return "";
  const teile = String(datum).split("-");
  return teile.length === 3 ? teile.reverse().join(".") : String(datum);
}

function personAusLookup(lookup, id) {
  if (!id) return null;
  if (lookup instanceof Map) return lookup.get(id) || null;
  return (lookup || []).find((p) => p.id === id) || null;
}

// Eine Partnerschaft gilt auch ohne gespeichertes Ende als beendet,
// wenn einer der beiden Partner bereits verstorben ist. Dabei wird nichts
// automatisch in der Datenbank überschrieben; die Information wird nur für
// Auswahl und Anzeige verwendet.
function partnerschaftTodesende(familie, lookup = personenCache, bezugsPersonId = null) {
  // Wenn der Benutzer die automatische Todesbeendigung ausdrücklich verworfen hat
  // (z. B. weil die Ehe geschieden wurde, das Scheidungsdatum aber noch unbekannt ist),
  // darf der Tod nicht erneut als Ende eingesetzt oder angezeigt werden.
  if (familie?.ende_automatik_ignorieren) return null;

  // Der Tod eines der beiden Partner beendet die Ehe/Partnerschaft.
  // bezugsPersonId wird aus Kompatibilitätsgründen weiter akzeptiert, darf
  // aber den Tod des aktuell geöffneten Partners nicht ausblenden.
  const totePartner = [familie?.partner_a_id, familie?.partner_b_id]
    .filter(Boolean)
    .map((id) => personAusLookup(lookup, id))
    .filter((p) => p && (p.sterbedatum || p.sterbejahr));
  if (!totePartner.length) return null;

  const exakt = totePartner
    .map((p) => p.sterbedatum)
    .filter(Boolean)
    .sort()[0];
  if (exakt) return { datum: exakt, jahr: exakt.slice(0, 4), exakt: true };

  const jahr = totePartner
    .map((p) => Number(p.sterbejahr))
    .filter((y) => Number.isFinite(y) && y > 0)
    .sort((a, b) => a - b)[0];
  return jahr ? { datum: null, jahr: String(jahr), exakt: false } : null;
}

function partnerschaftIstBeendet(familie, lookup = personenCache) {
  // Auch eine ausdrücklich als beendet markierte Ehe ohne bekanntes Datum
  // bleibt für eine neue Partnerschaft gesperrt.
  return !!familie?.ende || !!familie?.ende_automatik_ignorieren || !!partnerschaftTodesende(familie, lookup);
}

function ehejahreAnzeige(familie, lookup = personenCache) {
  if (String(familie?.familientyp || "").trim().toLocaleLowerCase("de") !== "ehe") return "";
  const beginn = familie?.beginn ? String(familie.beginn).slice(0, 10) : "";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(beginn)) return "";

  let ende = familie?.ende ? String(familie.ende).slice(0, 10) : "";
  if (!ende) {
    const tod = partnerschaftTodesende(familie, lookup);
    if (tod?.exakt && tod.datum) ende = String(tod.datum).slice(0, 10);
    else if (tod?.jahr) {
      const startJahr = Number(beginn.slice(0, 4));
      const endeJahr = Number(tod.jahr);
      if (Number.isFinite(startJahr) && Number.isFinite(endeJahr) && endeJahr >= startJahr) {
        return `${endeJahr - startJahr} Jahre`;
      }
      return "";
    }
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(ende)) return "";

  const start = new Date(`${beginn}T00:00:00`);
  const end = new Date(`${ende}T00:00:00`);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end < start) return "";

  let jahre = end.getFullYear() - start.getFullYear();
  const monatsTagEnde = end.getMonth() * 100 + end.getDate();
  const monatsTagStart = start.getMonth() * 100 + start.getDate();
  if (monatsTagEnde < monatsTagStart) jahre--;
  return jahre >= 0 ? `${jahre} Jahre` : "";
}

function partnerschaftEndeAnzeige(familie, lookup = personenCache) {
  if (familie?.ende) return `Ende: ${datumAnzeige(familie.ende)}`;
  const tod = partnerschaftTodesende(familie, lookup);
  if (!tod) return "Ende: offen";
  return tod.exakt ? `Ende: ${datumAnzeige(tod.datum)} · Tod` : `Ende: Tod ${tod.jahr}`;
}

// ---------- Personenliste laden ----------
async function loadPersonen() {
  const banner = document.getElementById("pending-banner");
  try {
    await ensureSession();
  } catch (err) {
    const msg = (err && (err.message || err.error_description || err.msg)) || "Unbekannter Fehler";
    if (banner) { banner.hidden = false; banner.textContent = `Fehler beim Laden: ${msg}`; }
    debugLog(`❌ Personen laden: ${msg}`);
    return;
  }
  const list = document.getElementById("personen-list");
  const empty = document.getElementById("list-empty");
  const { data, error } = await sb
    .from("personen")
    .select("id, vorname, nachname, geschlecht, Ledigenname, geburtsdatum, geburtsjahr, sterbedatum, sterbejahr, Notiz, created_at, erstellt_am")
    .order("nachname", { ascending: true });

  if (error) {
    console.error(error);
    return;
  }

  personenCache = data || [];
  try {
    const [{ data: familien }, { data: familienKinder }, { data: beziehungen }] = await Promise.all([
      sb.from("familien").select("id, partner_a_id, partner_b_id, familientyp, beginn, ende, ende_automatik_ignorieren"),
      sb.from("familien_kinder").select("familie_id, kind_id"),
      sb.from("beziehung").select("personen_a_id, personen_b_id, beziehungstyp")
    ]);
    familienAuswahlCache = familien || [];
    partnerIdsAuswahlCache = new Set();
    for (const f of familienAuswahlCache) {
      const typ = String(f.familientyp || "").toLowerCase();
      // Nur laufende Ehe/Partnerschaft sperrt die Person in der Auswahl.
      // Beendete Beziehungen bleiben für eine spätere Ehe/Partnerschaft auswählbar.
      if ((typ === "ehe" || typ === "partnerschaft") && !partnerschaftIstBeendet(f, personenCache)) {
        if (f.partner_a_id) partnerIdsAuswahlCache.add(f.partner_a_id);
        if (f.partner_b_id) partnerIdsAuswahlCache.add(f.partner_b_id);
      }
    }
    // Ältere Daten können noch ausschließlich in "beziehung" stehen.
    // Diese werden ebenfalls nur dann als belegte Partnerschaft behandelt,
    // wenn sie ausdrücklich Ehe oder Partnerschaft sind.
    for (const b of beziehungen || []) {
      if (b.beziehungstyp === "Ehe" || b.beziehungstyp === "Partnerschaft") {
        if (b.personen_a_id) partnerIdsAuswahlCache.add(b.personen_a_id);
        if (b.personen_b_id) partnerIdsAuswahlCache.add(b.personen_b_id);
      }
    }
    const kinderByFamilie = new Map();
    for (const k of familienKinder || []) { if (!kinderByFamilie.has(k.familie_id)) kinderByFamilie.set(k.familie_id, []); kinderByFamilie.get(k.familie_id).push(k.kind_id); }
    for (const f of familien || []) f._kinder=kinderByFamilie.get(f.id)||[];

    // Kleine Verwandtschaftszusammenfassung für die Personenliste.
    // Die Werte werden ausschließlich aus den bestehenden Familien- und
    // Kinderverknüpfungen berechnet; es werden keine neuen Daten gespeichert.
    personenVerwandtschaftCache = new Map(personenCache.map((p) => [p.id, {
      eltern: new Set(),
      ehePartnerschaften: new Set(),
      kinder: new Set(),
    }]));
    for (const fk of familienKinder || []) {
      const familie = (familien || []).find((f) => f.id === fk.familie_id);
      if (!familie || !fk.kind_id) continue;
      const info = personenVerwandtschaftCache.get(fk.kind_id);
      if (!info) continue;
      for (const partnerId of [familie.partner_a_id, familie.partner_b_id]) {
        if (partnerId && partnerId !== fk.kind_id) info.eltern.add(partnerId);
      }
    }
    for (const familie of familien || []) {
      const typ = String(familie.familientyp || '').trim().toLocaleLowerCase('de');
      const istEheOderPartnerschaft = typ === 'ehe' || typ === 'partnerschaft';
      for (const partnerId of [familie.partner_a_id, familie.partner_b_id]) {
        if (!partnerId || !istEheOderPartnerschaft) continue;
        const info = personenVerwandtschaftCache.get(partnerId);
        if (!info) continue;
        info.ehePartnerschaften.add(familie.id);
        for (const kindId of familie._kinder || []) {
          if (kindId && kindId !== partnerId) info.kinder.add(kindId);
        }
      }
    }
    berechneFamilienSortKeys(personenCache,familien||[]);
  } catch (familyErr) { debugLog(`⚠️ Familien-Sortierung: ${familyErr.message}`); }
  if (banner) banner.hidden = true;
  renderPersonenList(personenCache);
  empty.hidden = personenCache.length > 0;
}

const schluesselfotoCache = new Map();

async function ladeSchluesselfotos(personen) {
  schluesselfotoCache.clear();
  if (!personen.length) return;
  const ids = personen.map(p => p.id);
  const { data, error } = await sb.from("fotos").select("id, personen_id, dateipfad, ist_schluesselfoto").in("personen_id", ids).eq("ist_schluesselfoto", true);
  if (error) { debugLog(`❌ Schlüsselfotos laden: ${error.message}`); return; }
  for (const foto of data || []) {
    const { data: signed } = await sb.storage.from(BUCKET_FOTOS).createSignedUrl(foto.dateipfad, 3600);
    if (signed?.signedUrl) schluesselfotoCache.set(foto.personen_id, signed.signedUrl);
  }
}

async function renderPersonenList(personen) {
  personen = sortierePersonen(personen);
  const list = document.getElementById("personen-list");
  list.innerHTML = "";
  await ladeSchluesselfotos(personen);
  personen.forEach((p) => {
    const li = document.createElement("li");
    li.className = "person-card";
    const sterbeJahrAnzeige = p.sterbedatum
      ? p.sterbedatum.split("-")[0]
      : (p.sterbejahr ? String(p.sterbejahr) : "");
    const jahre = [p.geburtsdatum ? p.geburtsdatum.split("-")[0] : (p.geburtsjahr ? String(p.geburtsjahr) : ""), sterbeJahrAnzeige]
      .filter(Boolean)
      .join(" – ");
    const alterAnzeige = lebensalterAnzeige(p);
    const fotoUrl = schluesselfotoCache.get(p.id);
    const verwandtschaft = personenVerwandtschaftCache.get(p.id);
    const elternAnzahl = verwandtschaft?.eltern?.size || 0;
    const ehePartnerschaftenAnzahl = verwandtschaft?.ehePartnerschaften?.size || 0;
    const kinderAnzahl = verwandtschaft?.kinder?.size || 0;
    li.innerHTML = `
      ${fotoUrl ? `<img class="person-card__photo" src="${fotoUrl}" alt="Schlüsselfoto von ${p.vorname} ${p.nachname}">` : `<div class="person-card__photo-placeholder" aria-hidden="true">👤</div>`}
      <div class="person-card__content">
        <div class="person-card__name">${p.vorname} ${p.nachname}</div>
        ${jahre || alterAnzeige ? `<div class="person-card__years">${jahre}${jahre && alterAnzeige ? " · " : ""}${alterAnzeige}</div>` : ""}
        <div class="person-card__relations" aria-label="Verwandtschaft: Eltern ${elternAnzahl}, Ehe oder Partnerschaften ${ehePartnerschaftenAnzahl}, Kinder ${kinderAnzahl}">👥 Eltern: ${elternAnzahl} · 💍 Ehe/Partn.: ${ehePartnerschaftenAnzahl} · 👶 Kinder: ${kinderAnzahl}</div>
        ${p.Notiz ? `<div class="person-card__note">${p.Notiz}</div>` : ""}
      </div>
    `;
    li.addEventListener("click", () => openPersonDetail(p.id));
    list.appendChild(li);
  });
}



document.getElementById("search-input").addEventListener("input", (e) => {
  const q = e.target.value.toLowerCase();
  const filtered = personenCache.filter((p) =>
    `${p.vorname} ${p.nachname}`.toLowerCase().includes(q)
  );
  renderPersonenList(filtered);
});


const personenSortSelect=document.getElementById("personen-sortierung");
const personenSortButton=document.getElementById("personen-sort-richtung");
function aktualisierePersonenSortierung(){const q=(document.getElementById("search-input")?.value||"").toLowerCase();renderPersonenList(personenCache.filter(p=>`${p.vorname} ${p.nachname}`.toLowerCase().includes(q)));}
if(personenSortSelect)personenSortSelect.addEventListener("change",()=>{personenSortierung=personenSortSelect.value;aktualisierePersonenSortierung();});
if(personenSortButton)personenSortButton.addEventListener("click",()=>{personenSortRichtung*=-1;personenSortButton.textContent=personenSortRichtung===1?"↑":"↓";aktualisierePersonenSortierung();});

document.getElementById("refresh-btn").addEventListener("click", loadPersonen);

// ---------- Init ----------
(async function init() {
  try {
    await ensureSession();
    await flushQueue();
  } catch (err) {
    const msg = (err && (err.message || err.error_description || err.msg)) || "Unbekannter Fehler";
    debugLog(`⚠️ ${msg}`);
  }

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("sw.js").catch((e) => console.error("SW-Fehler:", e));
  }
})();

// ==========================================================
// PERSON-DETAIL / BEARBEITEN
// ==========================================================

let currentDetailPersonId = null;
let detailOpenedFromTree = false;
let detailReturnTreePersonId = null;
let autoPartnerSave = false;
let detailAudioMediaRecorder = null;
let detailAudioChunks = [];
let detailAudioStart = null;
let detailIsRecording = false;

const detailOverlay = document.getElementById("detail-overlay");
const detailFamilieMessage = document.getElementById("d-familie-message");

function setDetailFamilieMessage(text) {
  if (detailFamilieMessage) detailFamilieMessage.textContent = text || "";
}

function aktualisiereLinkButton(id, wert) {
  const btn = document.getElementById(id);
  if (!btn) return;
  const link = String(wert || "").trim();
  if (link) {
    btn.href = link;
    btn.hidden = false;
    btn.classList.add("btn--link-present");
  } else {
    btn.href = "#";
    btn.hidden = true;
    btn.classList.remove("btn--link-present");
  }
}

async function openPersonDetail(personId, options = {}) {
  currentDetailPersonId = personId;
  detailOpenedFromTree = options.fromTree === true;
  detailReturnTreePersonId = detailOpenedFromTree ? personId : null;
  await ensureSession();

  const { data: person, error } = await sb.from("personen").select("*").eq("id", personId).single();
  if (error) { debugLog(`❌ Fehler beim Laden der Person: ${error.message}`); return; }

  document.getElementById("d-vorname").value = person.vorname || "";
  document.getElementById("d-nachname").value = person.nachname || "";
  document.getElementById("d-geschlecht").value = person.geschlecht || "";
  document.getElementById("d-ledigenname").value = person.Ledigenname || "";
  setDatum("d-geburtsdatum", person.geburtsdatum);
  setDatum("d-sterbedatum", person.sterbedatum);
  document.getElementById("d-geburtsjahr").value = person.geburtsjahr ? String(person.geburtsjahr) : "";
  document.getElementById("d-sterbejahr").value = person.sterbejahr ? String(person.sterbejahr) : "";
  synchronisiereNurJahrFeld("d-geburtsdatum", "d-geburtsjahr");
  synchronisiereNurJahrFeld("d-sterbedatum", "d-sterbejahr");
  document.getElementById("d-taufbuch-link").value = person.taufbuch_link || "";
  document.getElementById("d-trauungsbuch-link").value = person.trauungsbuch_link || "";
  document.getElementById("d-sterbebuch-link").value = person.sterbebuch_link || "";
  document.getElementById("d-taufbuch-zeile").value = person.taufbuch_zeile ?? "";
  document.getElementById("d-trauungsbuch-zeile").value = person.trauungsbuch_zeile ?? "";
  document.getElementById("d-sterbebuch-zeile").value = person.sterbebuch_zeile ?? "";
  aktualisiereLinkButton("d-taufbuch-open", person.taufbuch_link);
  aktualisiereLinkButton("d-trauungsbuch-open", person.trauungsbuch_link);
  aktualisiereLinkButton("d-sterbebuch-open", person.sterbebuch_link);
  document.getElementById("d-notiz").value = person.Notiz || "";
  document.getElementById("d-person-message").textContent = "";
  document.getElementById("d-foto-message").textContent = "";
  document.getElementById("d-audio-message").textContent = "";
  setDetailFamilieMessage("");
  document.getElementById("d-delete-message").textContent = "";

  // Personendaten sofort öffnen. Nachgelagerte Medien/Familien dürfen das
  // Öffnen der Detailansicht nicht blockieren.
  detailOverlay.hidden = false;
  // Die Detailansicht immer am Anfang öffnen, damit der Name sofort sichtbar ist.
  detailOverlay.scrollTop = 0;
  const detailSheet = detailOverlay.querySelector(".detail-sheet");
  if (detailSheet) detailSheet.scrollTop = 0;
  requestAnimationFrame(() => {
    detailOverlay.scrollTop = 0;
    if (detailSheet) detailSheet.scrollTop = 0;
  });

  try { await loadDetailFotos(personId); } catch (err) { debugLog(`⚠️ Fotos der Person konnten nicht geladen werden: ${err.message || err}`); }
  try { await loadDetailAudio(personId); } catch (err) { debugLog(`⚠️ Sprachnotizen der Person konnten nicht geladen werden: ${err.message || err}`); }
  // Für die Familienansicht immer aktuelle Personennamen verwenden.
  try { await loadPersonen(); } catch (_) {}
  try { await loadDetailFamilie(personId); } catch (err) { debugLog(`⚠️ Familienangaben konnten nicht geladen werden: ${err.message || err}`); }
}

document.getElementById("detail-close-btn").addEventListener("click", async () => {
  const fromTree = detailOpenedFromTree;
  const returnTreePersonId = detailReturnTreePersonId;
  detailOverlay.hidden = true;
  detailOpenedFromTree = false;
  detailReturnTreePersonId = null;
  if (fromTree) {
    const select = document.getElementById("tree-person-select");
    if (select && returnTreePersonId) select.value = returnTreePersonId;
    try { await loadStammbaum(); } catch (err) { debugLog(`⚠️ Stammbaum nach Rückkehr: ${err.message || err}`); }
  } else {
    loadPersonen();
  }
});

// Trauungsbuch-Link bei Ehepartnern synchronisieren.
// Es wird ausschließlich das Trauungsbuch-Feld behandelt. Bereits vorhandene
// Links werden nicht überschrieben; nur ein fehlender Link wird ergänzt.
async function synchronisiereTrauungsbuchEhepartner(personId, link) {
  const eigenerLink = String(link || "").trim();
  if (!personId || !eigenerLink) return;

  const { data: familien, error: familienError } = await sb.from("familien")
    .select("id, partner_a_id, partner_b_id, familientyp")
    .or(`partner_a_id.eq.${personId},partner_b_id.eq.${personId}`)
    .eq("familientyp", "Ehe");
  if (familienError) throw familienError;

  const partnerIds = [...new Set((familien || [])
    .map((f) => familiePartnerIds(f, personId)[0])
    .filter(Boolean))];
  if (!partnerIds.length) return;

  const { data: partnerPersonen, error: partnerError } = await sb.from("personen")
    .select("id, trauungsbuch_link")
    .in("id", partnerIds);
  if (partnerError) throw partnerError;

  for (const partner of partnerPersonen || []) {
    // Bestehende Daten des Partners niemals überschreiben.
    if (String(partner.trauungsbuch_link || "").trim()) continue;
    const { error } = await sb.from("personen")
      .update({ trauungsbuch_link: eigenerLink })
      .eq("id", partner.id);
    if (error) throw error;
  }
}

// Bei einer neu angelegten Ehe kann der Link bereits beim anderen Ehepartner
// vorhanden sein. In diesem Fall wird nur die fehlende Seite ergänzt.
async function synchronisiereTrauungsbuchBeiEhe(personAId, personBId) {
  if (!personAId || !personBId) return;

  const { data: personen, error } = await sb.from("personen")
    .select("id, trauungsbuch_link")
    .in("id", [personAId, personBId]);
  if (error) throw error;

  const a = (personen || []).find((p) => p.id === personAId);
  const b = (personen || []).find((p) => p.id === personBId);
  const linkA = String(a?.trauungsbuch_link || "").trim();
  const linkB = String(b?.trauungsbuch_link || "").trim();
  const gemeinsamerLink = linkA || linkB;
  if (!gemeinsamerLink) return;

  if (!linkA) {
    const { error: e } = await sb.from("personen")
      .update({ trauungsbuch_link: gemeinsamerLink })
      .eq("id", personAId);
    if (e) throw e;
  }
  if (!linkB) {
    const { error: e } = await sb.from("personen")
      .update({ trauungsbuch_link: gemeinsamerLink })
      .eq("id", personBId);
    if (e) throw e;
  }
}

// ---- Person-Felder speichern ----
document.getElementById("d-save-person-btn").addEventListener("click", async () => {
  const msg = document.getElementById("d-person-message");
  msg.textContent = "Speichere …";
  const vorname = document.getElementById("d-vorname").value.trim();
  const nachname = document.getElementById("d-nachname").value.trim();
  if (!vorname || !nachname) {
    msg.textContent = "Vor- und Nachname dürfen nicht leer sein.";
    return;
  }
  const { error } = await sb.from("personen").update({
    vorname,
    nachname,
    geschlecht: document.getElementById("d-geschlecht").value || null,
    "Ledigenname": document.getElementById("d-ledigenname").value.trim() || null,
    geburtsdatum: getDatum("d-geburtsdatum"),
    geburtsjahr: getDatum("d-geburtsdatum") ? null : (document.getElementById("d-geburtsjahr").value.trim() ? Number(document.getElementById("d-geburtsjahr").value.trim()) : null),
    sterbedatum: getDatum("d-sterbedatum"),
    sterbejahr: getDatum("d-sterbedatum") ? null : (document.getElementById("d-sterbejahr").value.trim() ? Number(document.getElementById("d-sterbejahr").value.trim()) : null),
    taufbuch_link: document.getElementById("d-taufbuch-link").value.trim() || null,
    trauungsbuch_link: document.getElementById("d-trauungsbuch-link").value.trim() || null,
    sterbebuch_link: document.getElementById("d-sterbebuch-link").value.trim() || null,
    taufbuch_zeile: document.getElementById("d-taufbuch-zeile").value.trim() ? Number(document.getElementById("d-taufbuch-zeile").value) : null,
    trauungsbuch_zeile: document.getElementById("d-trauungsbuch-zeile").value.trim() ? Number(document.getElementById("d-trauungsbuch-zeile").value) : null,
    sterbebuch_zeile: document.getElementById("d-sterbebuch-zeile").value.trim() ? Number(document.getElementById("d-sterbebuch-zeile").value) : null,
    Notiz: document.getElementById("d-notiz").value.trim() || null,
  }).eq("id", currentDetailPersonId);
  if (error) {
    msg.textContent = `Fehler: ${error.message}`;
    return;
  }

  // Wird ein Todesdatum nachträglich eingetragen, ein bisher offenes
  // Ehe-/Partnerschaftsende automatisch übernehmen. Ein vorhandenes
  // manuelles Ende wird dabei niemals verändert.
  try {
    await synchronisierePartnerschaftsEndeBeiTod(
      currentDetailPersonId,
      getDatum("d-sterbedatum"),
      document.getElementById("d-sterbejahr").value.trim()
        ? Number(document.getElementById("d-sterbejahr").value.trim())
        : null
    );
  } catch (err) {
    debugLog(`⚠️ Partnerschaftsende durch Tod: ${err.message || err}`);
  }

  // Lokalen Cache sofort aktualisieren, damit die Partnerschaftsanzeige
  // unmittelbar nach dem Speichern den neuen Tod berücksichtigt.
  const cachePerson = personenCache.find((p) => p.id === currentDetailPersonId);
  if (cachePerson) {
    cachePerson.geburtsdatum = getDatum("d-geburtsdatum");
    cachePerson.geburtsjahr = cachePerson.geburtsdatum ? null : (
      document.getElementById("d-geburtsjahr").value.trim()
        ? Number(document.getElementById("d-geburtsjahr").value.trim())
        : null
    );
    cachePerson.sterbedatum = getDatum("d-sterbedatum");
    cachePerson.sterbejahr = cachePerson.sterbedatum ? null : (
      document.getElementById("d-sterbejahr").value.trim()
        ? Number(document.getElementById("d-sterbejahr").value.trim())
        : null
    );
  }

  // Nur das Trauungsbuch darf bei einer Ehe auf den Partner ergänzt werden.
  // Leere Partnerfelder werden gefüllt; bestehende Partner-Links bleiben unangetastet.
  try {
    await synchronisiereTrauungsbuchEhepartner(
      currentDetailPersonId,
      document.getElementById("d-trauungsbuch-link").value.trim()
    );
  } catch (err) {
    debugLog(`⚠️ Trauungsbuch-Synchronisierung: ${err.message || err}`);
  }

  msg.textContent = "Gespeichert ✓";
  aktualisiereLinkButton("d-taufbuch-open", document.getElementById("d-taufbuch-link").value.trim());
  aktualisiereLinkButton("d-trauungsbuch-open", document.getElementById("d-trauungsbuch-link").value.trim());
  aktualisiereLinkButton("d-sterbebuch-open", document.getElementById("d-sterbebuch-link").value.trim());
  await loadDetailFamilie(currentDetailPersonId);
});

document.getElementById("d-taufbuch-link")?.addEventListener("input", (e) => {
  aktualisiereLinkButton("d-taufbuch-open", e.target.value);
});
document.getElementById("d-trauungsbuch-link")?.addEventListener("input", (e) => {
  aktualisiereLinkButton("d-trauungsbuch-open", e.target.value);
});
document.getElementById("d-sterbebuch-link")?.addEventListener("input", (e) => {
  aktualisiereLinkButton("d-sterbebuch-open", e.target.value);
});

// ---- Fotos im Detail ----
async function loadDetailFotos(personId) {
  const container = document.getElementById("d-fotos-list");
  container.innerHTML = "";
  const [{ data: eigene, error: eigeneError }, { data: links, error: linksError }] = await Promise.all([
    sb.from("fotos").select("*").eq("personen_id", personId),
    sb.from("foto_personen").select("foto_id").eq("personen_id", personId)
  ]);
  if (eigeneError) { debugLog(`❌ Fotos laden: ${eigeneError.message}`); return; }
  if (linksError) { debugLog(`❌ Foto-Verknüpfungen laden: ${linksError.message}`); return; }
  const ids = [...new Set([...(eigene || []).map(f => f.id), ...(links || []).map(x => x.foto_id)])];
  let verknuepfte = [];
  if (ids.length) {
    const { data, error } = await sb.from("fotos").select("*").in("id", ids);
    if (error) { debugLog(`❌ Verknüpfte Fotos laden: ${error.message}`); return; }
    verknuepfte = data || [];
  }
  const fotos = [...verknuepfte].sort((a, b) => Number(!!b.ist_schluesselfoto) - Number(!!a.ist_schluesselfoto));
  for (const foto of fotos) {
    const { data: signed } = await sb.storage.from(BUCKET_FOTOS).createSignedUrl(foto.dateipfad, 3600);
    const { data: markierungen } = await sb.from("foto_personen")
      .select("id, personen_id, nummer, position_x, position_y, position_format")
      .eq("foto_id", foto.id)
      .order("nummer", { ascending: true });
    const istGruppenfoto = !!foto.gruppenfoto || (markierungen || []).length > 0;
    const div = document.createElement("div");
    div.className = `detail-media-item${istGruppenfoto ? " detail-group-photo-item" : ""}`;

    if (istGruppenfoto) {
      div.innerHTML = `
        <div class="detail-group-photo-wrap">
          <img src="${signed ? signed.signedUrl : ""}" alt="Gruppenfoto">
          <div class="detail-group-photo-markers"></div>
        </div>
        <div class="detail-group-photo-info">
          <span class="beziehung-text">${foto.ist_schluesselfoto ? "⭐ Schlüsselfoto · Gruppenfoto" : "Gruppenfoto"}</span>
          <div class="detail-group-photo-legend"></div>
          <div class="detail-group-photo-actions">
            <button class="foto-personen-open-btn btn btn--secondary" type="button">👥 Personen</button>
            <button class="key-photo-btn" type="button" title="Als Schlüsselfoto festlegen" ${foto.ist_schluesselfoto ? "disabled" : ""}>⭐ Schlüssel</button>
            <button class="del-btn" title="Verknüpfung entfernen">🗑️</button>
          </div>
        </div>`;
      const wrap = div.querySelector(".detail-group-photo-wrap");
      const markerEl = div.querySelector(".detail-group-photo-markers");
      const legendEl = div.querySelector(".detail-group-photo-legend");
      (markierungen || []).forEach(row => {
        const marker = document.createElement("span");
        marker.className = "detail-group-photo-marker";
        marker.textContent = row.nummer;
        marker.style.left = `${Number(row.position_x ?? 50)}%`;
        marker.style.top = `${Number(row.position_y ?? 50)}%`;
        marker.title = `${row.nummer}: ${fotoPersonName(row.personen_id)}`;
        markerEl.appendChild(marker);
        const entry = document.createElement("span");
        entry.className = "detail-group-photo-legend-item";
        entry.textContent = `#${row.nummer} ${fotoPersonName(row.personen_id)}`;
        legendEl.appendChild(entry);
      });
      wrap.addEventListener("click", (event) => {
        event.stopPropagation();
        openGruppenfotoViewer(signed?.signedUrl, markierungen || [], foto);
      });
    } else {
      div.innerHTML = `<img src="${signed ? signed.signedUrl : ""}" alt="Foto"><span class="beziehung-text">${foto.ist_schluesselfoto ? "⭐ Schlüsselfoto" : "Foto"}</span><button class="key-photo-btn" type="button" title="Als Schlüsselfoto festlegen" ${foto.ist_schluesselfoto ? "disabled" : ""}>⭐ Schlüssel</button><button class="del-btn" title="Löschen">🗑️</button>`;
      const fotoImg = div.querySelector("img");
      const openFoto = (event) => {
        if (event) event.stopPropagation();
        const viewer = document.getElementById("detail-photo-viewer");
        const viewerImg = document.getElementById("detail-photo-viewer-img");
        if (!viewer || !viewerImg || !fotoImg.src) return;
        viewerImg.src = fotoImg.src;
        viewer.hidden = false;
      };
      fotoImg.addEventListener("click", openFoto);
      fotoImg.addEventListener("pointerup", openFoto);
    }
    div.querySelector(".foto-personen-open-btn")?.addEventListener("click", (event) => { event.stopPropagation(); openFotoPersonenModal(foto); });
    div.querySelector(".key-photo-btn").addEventListener("click", async () => {
      const msg = document.getElementById("d-foto-message");
      msg.textContent = "Schlüsselfoto wird gesetzt …";
      const { error: resetError } = await sb.from("fotos").update({ ist_schluesselfoto: false }).eq("personen_id", personId);
      if (resetError) { msg.textContent = `Fehler: ${resetError.message}`; return; }
      const { error: keyError } = await sb.from("fotos").update({ ist_schluesselfoto: true }).eq("id", foto.id);
      if (keyError) { msg.textContent = `Fehler: ${keyError.message}`; return; }
      msg.textContent = "Schlüsselfoto gesetzt ✓";
      await loadDetailFotos(personId);
      await loadPersonen();
    });
    div.querySelector(".del-btn").addEventListener("click", async () => {
      if (!confirm(istGruppenfoto ? "Diese Person vom Gruppenfoto entfernen?" : "Foto bzw. Verknüpfung wirklich entfernen?")) return;
      const { data: links } = await sb.from("foto_personen").select("id, personen_id").eq("foto_id", foto.id);
      if ((links || []).length) {
        await sb.from("foto_personen").delete().eq("foto_id", foto.id).eq("personen_id", personId);
        const verbleibend = (links || []).filter(x => x.personen_id !== personId);
        const istEigentuemer = foto.personen_id === personId;
        if (!verbleibend.length && istEigentuemer) {
          await sb.storage.from(BUCKET_FOTOS).remove([foto.dateipfad]);
          await sb.from("fotos").delete().eq("id", foto.id);
        }
      } else {
        await sb.storage.from(BUCKET_FOTOS).remove([foto.dateipfad]);
        await sb.from("fotos").delete().eq("id", foto.id);
      }
      await loadDetailFotos(personId);
      loadPersonen();
    });
    container.appendChild(div);
  }
}


async function uploadDetailFoto(file) {
  const msg = document.getElementById("d-foto-message");
  msg.textContent = "Foto anpassen …";
  const edited = await openPhotoEditor(file);
  if (!edited) { msg.textContent = "Foto nicht übernommen."; return; }
  const optimiert = await blobZuJPEGUnter200KB(edited);
  if (!optimiert) { msg.textContent = "Foto konnte nicht optimiert werden."; return; }
  msg.textContent = `Lade hoch … (${Math.round(optimiert.size / 1024)} KB)`;
  const path = `${currentDetailPersonId}/${Date.now()}-${Math.random().toString(36).slice(2,8)}.jpg`;
  const { error: uploadError } = await sb.storage.from(BUCKET_FOTOS).upload(path, optimiert, {
    contentType: "image/jpeg",
    upsert: false,
  });
  if (uploadError) { msg.textContent = `Fehler: ${uploadError.message}`; return; }
  const { error: insertError } = await sb.from("fotos").insert({ personen_id: currentDetailPersonId, dateipfad: path, ist_schluesselfoto: false });
  msg.textContent = insertError ? `Fehler: ${insertError.message}` : "Foto hinzugefügt ✓";
  loadDetailFotos(currentDetailPersonId);
}


function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'\"':"&quot;","\'":"&#39;"}[ch]));
}

// ---- Zentrale Fotoübersicht ----
const gruppenfotoInput = document.getElementById("gruppenfoto-input");
const gruppenfotoPreview = document.getElementById("gruppenfoto-preview");
const gruppenfotoStatus = document.getElementById("gruppenfoto-status");
const gruppenfotoPersonenListe = document.getElementById("gruppenfoto-personen-liste");
const gruppenfotoPersonenSuche = document.getElementById("gruppenfoto-personen-suche");
const gruppenfotoPersonenAnzahl = document.getElementById("gruppenfoto-personen-anzahl");
const gruppenfotoSpeichern = document.getElementById("gruppenfoto-speichern");
const gruppenfotoMessage = document.getElementById("gruppenfoto-message");
const gruppenfotoListe = document.getElementById("gruppenfoto-liste");
const gruppenfotoLeer = document.getElementById("gruppenfoto-leer");
let gruppenfotoDatei = null;

function fotoPersonJahrDatumAnzeige(person) {
  if (!person) return "";
  const datum = (wert, jahr) => {
    if (wert) {
      const m = String(wert).match(/^(\d{4})-(\d{2})-(\d{2})/);
      if (m) return `${m[3]}.${m[2]}.${m[1]}`;
      return String(wert);
    }
    return jahr ? String(jahr) : "";
  };
  const geb = datum(person.geburtsdatum, person.geburtsjahr);
  const gest = datum(person.sterbedatum, person.sterbejahr);
  const teile = [];
  if (geb) teile.push(`geb. ${geb}`);
  if (gest) teile.push(`gest. ${gest}`);
  return teile.join(" · ");
}

function fotoPersonAnzeige(person) {
  if (!person) return { name: "Unbekannte Person", daten: "" };
  const name = [person.vorname, person.nachname].filter(Boolean).join(" " ) || "Unbekannte Person";
  return { name, daten: fotoPersonJahrDatumAnzeige(person) };
}

function gruppenfotoAusgewaehltePersonen() {
  return [...(gruppenfotoPersonenListe?.querySelectorAll('input[type="checkbox"]:checked') || [])].map(el => el.value).filter(Boolean);
}

function aktualisiereGruppenfotoPersonenAnzahl() {
  if (gruppenfotoPersonenAnzahl) {
    const n = gruppenfotoAusgewaehltePersonen().length;
    gruppenfotoPersonenAnzahl.textContent = `${n} ${n === 1 ? "Person ausgewählt" : "Personen ausgewählt"}`;
  }
}

function fuelleGruppenfotoPersonen() {
  if (!gruppenfotoPersonenListe) return;
  const bisher = new Set(gruppenfotoAusgewaehltePersonen());
  const suchtext = (gruppenfotoPersonenSuche?.value || "").trim().toLocaleLowerCase("de");
  const personen = (personenCache || []).slice().sort((a,b) => `${a.nachname||""} ${a.vorname||""}`.localeCompare(`${b.nachname||""} ${b.vorname||""}`, "de"));
  const gefiltert = personen.filter(p => {
    if (!suchtext) return true;
    return `${p.vorname || ""} ${p.nachname || ""}`.toLocaleLowerCase("de").includes(suchtext);
  });
  gruppenfotoPersonenListe.innerHTML = gefiltert.map(p => {
    const anzeige = fotoPersonAnzeige(p);
    return `
    <label class="gruppenfoto-person-option">
      <input type="checkbox" value="${p.id}" ${bisher.has(p.id) ? "checked" : ""}>
      <span class="gruppenfoto-person-option__text"><strong>${escapeHtml(anzeige.name)}</strong>${anzeige.daten ? `<small>${escapeHtml(anzeige.daten)}</small>` : ""}</span>
    </label>`;
  }).join("");
  gruppenfotoPersonenListe.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.addEventListener("change", aktualisiereGruppenfotoPersonenAnzahl));
  aktualisiereGruppenfotoPersonenAnzahl();
}

gruppenfotoPersonenSuche?.addEventListener("input", fuelleGruppenfotoPersonen);

async function ladeGruppenfotoListe() {
  if (!gruppenfotoListe) return;
  const { data, error } = await sb.from("fotos").select("*").eq("gruppenfoto", true).order("id", { ascending: false });
  if (error) { gruppenfotoMessage.textContent = `Fehler: ${error.message}`; return; }
  gruppenfotoListe.innerHTML = "";
  gruppenfotoLeer.hidden = !!(data && data.length);
  for (const foto of (data || [])) {
    const { data: signed } = await sb.storage.from(BUCKET_FOTOS).createSignedUrl(foto.dateipfad, 3600);
    const div = document.createElement("div");
    div.className = "detail-media-item";
    div.innerHTML = `<img src="${signed?.signedUrl || ""}" alt="Foto"><span class="beziehung-text">Foto</span><button type="button" class="btn btn--secondary gruppenfoto-personen-btn">👥 Personen</button>`;
    div.querySelector("img")?.addEventListener("click", () => openFotoPersonenModal(foto));
    div.querySelector(".gruppenfoto-personen-btn").addEventListener("click", () => openFotoPersonenModal(foto));
    gruppenfotoListe.appendChild(div);
  }
}

gruppenfotoInput?.addEventListener("change", () => {
  const file = gruppenfotoInput.files?.[0];
  gruppenfotoDatei = file || null;
  if (!file) { gruppenfotoPreview.hidden = true; gruppenfotoStatus.textContent = "Kein Foto ausgewählt"; return; }
  gruppenfotoPreview.src = URL.createObjectURL(file);
  gruppenfotoPreview.hidden = false;
  gruppenfotoStatus.textContent = `${file.name} ausgewählt ✓`;
});

gruppenfotoSpeichern?.addEventListener("click", async () => {
  gruppenfotoMessage.textContent = "";
  if (!gruppenfotoDatei) { gruppenfotoMessage.textContent = "Bitte zuerst ein Foto auswählen."; return; }
  const ids = gruppenfotoAusgewaehltePersonen();
  if (!ids.length) { gruppenfotoMessage.textContent = "Bitte mindestens eine Person auswählen."; return; }
  gruppenfotoSpeichern.disabled = true;
  try {
    gruppenfotoMessage.textContent = "Foto anpassen …";
    const edited = await openPhotoEditor(gruppenfotoDatei);
    if (!edited) { gruppenfotoMessage.textContent = "Foto nicht übernommen."; return; }
    const optimiert = await blobZuJPEGUnter200KB(edited);
    if (!optimiert) throw new Error("Foto konnte nicht optimiert werden.");
    const path = `gruppenfotos/${Date.now()}-${Math.random().toString(36).slice(2,8)}.jpg`;
    gruppenfotoMessage.textContent = `Lade hoch … (${Math.round(optimiert.size / 1024)} KB)`;
    const { error: uploadError } = await sb.storage.from(BUCKET_FOTOS).upload(path, optimiert, { contentType: "image/jpeg", upsert: false });
    if (uploadError) throw uploadError;
    const { data: foto, error: insertError } = await sb.from("fotos").insert({ personen_id: ids[0], dateipfad: path, ist_schluesselfoto: false, gruppenfoto: true }).select().single();
    if (insertError) { await sb.storage.from(BUCKET_FOTOS).remove([path]); throw insertError; }
    const rows = ids.map((personen_id, index) => ({ foto_id: foto.id, personen_id, nummer: index + 1, position_x: 50, position_y: 50 }));
    const { error: linkError } = await sb.from("foto_personen").insert(rows);
    if (linkError) { await sb.storage.from(BUCKET_FOTOS).remove([path]); await sb.from("fotos").delete().eq("id", foto.id); throw linkError; }
    gruppenfotoMessage.textContent = "Foto gespeichert ✓";
    gruppenfotoDatei = null; gruppenfotoInput.value = ""; gruppenfotoPreview.hidden = true; gruppenfotoStatus.textContent = "Kein Foto ausgewählt";
    gruppenfotoPersonenListe.querySelectorAll('input[type="checkbox"]').forEach(cb => { cb.checked = false; });
    if (gruppenfotoPersonenSuche) gruppenfotoPersonenSuche.value = "";
    aktualisiereGruppenfotoPersonenAnzahl();
    await ladeGruppenfotoListe();
    await openFotoPersonenModal(foto);
  } catch (err) {
    gruppenfotoMessage.textContent = `Fehler: ${err.message || err}`;
  } finally { gruppenfotoSpeichern.disabled = false; }
});

// ---- Gruppenfoto: mehrere Personen + manuelle Nummern/Positionen ----
let fotoPersonenAktuell = null;
let fotoMarkierungen = [];
let fotoAktiveMarkierungId = null;

const fotoPersonenModal = document.getElementById("foto-personen-modal");
const fotoMarkierbild = document.getElementById("foto-markierbild");
const fotoMarkierbildWrap = document.getElementById("foto-markierbild-wrap");
const fotoMarkierflaeche = document.getElementById("foto-markierflaeche");
const fotoMarkierungenEl = document.getElementById("foto-markierungen");
const fotoPersonenListe = document.getElementById("foto-personen-liste");
const fotoPersonAuswahl = document.getElementById("foto-person-auswahl");
const fotoPersonSuche = document.getElementById("foto-person-suche");
const fotoPersonenMessage = document.getElementById("foto-personen-message");

function fotoPersonName(id) {
  if (!id) return "unbekannte Person";
  const p = personenCache.find(x => x.id === id);
  return p ? `${p.vorname || ""} ${p.nachname || ""}`.trim() : "unbekannte Person";
}

async function openFotoPersonenModal(foto) {
  if (!fotoPersonenModal) return;
  // Die Personenliste muss auch erreichbar sein, wenn der Nutzer direkt über
  // den Fotos-Menüpunkt kommt und die Personenansicht noch nicht geladen wurde.
  if (!Array.isArray(personenCache) || personenCache.length === 0) {
    try { await loadPersonen(); } catch (err) {
      fotoPersonenMessage.textContent = `Personen konnten nicht geladen werden: ${err.message || err}`;
    }
  }
  fotoPersonenAktuell = foto;
  fotoAktiveMarkierungId = null;
  fotoPersonenMessage.textContent = "Lade …";
  const { data: rows, error } = await sb.from("foto_personen").select("id, foto_id, personen_id, nummer, position_x, position_y, position_format").eq("foto_id", foto.id).order("nummer", { ascending: true });
  if (error) { fotoPersonenMessage.textContent = `Fehler: ${error.message}`; return; }
  fotoMarkierungen = rows || [];
  const { data: signed } = await sb.storage.from(BUCKET_FOTOS).createSignedUrl(foto.dateipfad, 3600);
  fotoMarkierbild.src = signed?.signedUrl || "";
  // Für die nachträgliche Zuordnung alle Personen anzeigen. Bereits zugeordnete
  // Personen bleiben sichtbar und werden mit ihrer vorhandenen Nummer markiert.
  // So ist auch bei einem großen Gruppenfoto sofort erkennbar, wer schon zugeordnet ist.
  fotoPersonAuswahl._alleVerfuegbarenPersonen = (personenCache || [])
    .slice()
    .sort((a,b) => `${a.nachname||""} ${a.vorname||""}`.localeCompare(`${b.nachname||""} ${b.vorname||""}`, "de"));
  if (fotoPersonSuche) fotoPersonSuche.value = "";
  renderFotoPersonAuswahl();
  fotoPersonAuswahl.disabled = !(fotoPersonAuswahl._alleVerfuegbarenPersonen || []).some(p =>
    !fotoMarkierungen.some(r => r.personen_id === p.id)
  );
  fotoPersonenModal.hidden = false;
  const renderAfterLoad = async () => {
    await migriereAlteFotoPositionen();
    renderFotoMarkierungen();
    fotoPersonenMessage.textContent = "";
  };
  if (fotoMarkierbild.complete && fotoMarkierbild.naturalWidth) renderAfterLoad();
  else fotoMarkierbild.addEventListener("load", renderAfterLoad, { once: true });
}


function renderFotoPersonAuswahl() {
  if (!fotoPersonAuswahl) return;
  const alle = fotoPersonAuswahl._alleVerfuegbarenPersonen || [];
  const suchtext = (fotoPersonSuche?.value || "").trim().toLocaleLowerCase("de");
  const gefiltert = suchtext ? alle.filter(p => {
    const a = fotoPersonAnzeige(p);
    return `${a.name} ${a.daten || ""}`.toLocaleLowerCase("de").includes(suchtext);
  }) : alle;
  const belegteNummern = new Map(
    fotoMarkierungen
      .filter(r => r.personen_id)
      .map(r => [r.personen_id, r.nummer])
  );
  fotoPersonAuswahl.innerHTML = '<option value="">— Person auswählen —</option>' + gefiltert.map(p => {
    const anzeige = fotoPersonAnzeige(p);
    const nr = belegteNummern.get(p.id);
    return `<option value="${p.id}" ${nr ? "disabled" : ""}>${escapeHtml(anzeige.name)}${anzeige.daten ? ` — ${escapeHtml(anzeige.daten)}` : ""}${nr ? ` — bereits Nr. ${nr}` : ""}</option>`;
  }).join("");
}

fotoPersonSuche?.addEventListener("input", renderFotoPersonAuswahl);

async function migriereAlteFotoPositionen() {
  if (!fotoMarkierbildWrap || !fotoMarkierbild.naturalWidth) return;
  const legacy = fotoMarkierungen.filter(r => (r.position_format || "flaeche") !== "bild");
  if (!legacy.length) return;

  const bildRect = fotoMarkierbild.getBoundingClientRect();
  const flaechenRect = fotoMarkierflaeche.getBoundingClientRect();
  if (!bildRect.width || !bildRect.height || !flaechenRect.width || !flaechenRect.height) return;

  for (const row of legacy) {
    const oldXpx = flaechenRect.left + (Number(row.position_x ?? 50) / 100) * flaechenRect.width;
    const oldYpx = flaechenRect.top + (Number(row.position_y ?? 50) / 100) * flaechenRect.height;
    const x = Math.max(0, Math.min(100, ((oldXpx - bildRect.left) / bildRect.width) * 100));
    const y = Math.max(0, Math.min(100, ((oldYpx - bildRect.top) / bildRect.height) * 100));
    const { error } = await sb.from("foto_personen").update({ position_x: x, position_y: y, position_format: "bild" }).eq("id", row.id);
    if (!error) { row.position_x = x; row.position_y = y; row.position_format = "bild"; }
  }
}

function renderFotoMarkierungen() {
  fotoMarkierungenEl.innerHTML = "";
  fotoPersonenListe.innerHTML = "";
  const sorted = [...fotoMarkierungen].sort((a,b) => Number(a.nummer)-Number(b.nummer));

  for (const row of sorted) {
    const m = document.createElement("div");
    m.className = "foto-markierung" + (row.id === fotoAktiveMarkierungId ? " is-active" : "");
    m.textContent = row.nummer;
    m.style.left = `${Number(row.position_x ?? 50)}%`;
    m.style.top = `${Number(row.position_y ?? 50)}%`;
    m.title = `${row.nummer}: ${fotoPersonName(row.personen_id)}`;
    m.addEventListener("click", (e) => {
      e.stopPropagation();
      fotoAktiveMarkierungId = row.id;
      renderFotoMarkierungen();
    });
    fotoMarkierungenEl.appendChild(m);

    const line = document.createElement("div");
    line.className = "foto-person-zeile";

    const name = document.createElement("span");
    name.className = "foto-person-zeile__name";
    name.textContent = fotoPersonName(row.personen_id);

    const num = document.createElement("span");
    num.className = "foto-person-zeile__num";
    num.textContent = `#${row.nummer}`;

    const assignBtn = document.createElement("button");
    assignBtn.type = "button";
    assignBtn.className = "btn btn--secondary foto-person-aendern-btn";
    assignBtn.textContent = row.personen_id ? "Person ändern" : "Person zuordnen";

    const positionBtn = document.createElement("button");
    positionBtn.type = "button";
    positionBtn.className = "btn btn--ghost foto-position-btn";
    positionBtn.textContent = "Position";

    const numberBtn = document.createElement("button");
    numberBtn.type = "button";
    numberBtn.className = "btn btn--ghost foto-nummer-btn";
    numberBtn.textContent = "Nr.";

    const deleteBtn = document.createElement("button");
    deleteBtn.type = "button";
    deleteBtn.className = "btn btn--ghost foto-person-loeschen-btn";
    deleteBtn.textContent = "✕";
    deleteBtn.setAttribute("aria-label", `Nr. ${row.nummer} entfernen`);

    line.append(num, name, assignBtn, positionBtn, numberBtn, deleteBtn);

    assignBtn.addEventListener("click", () => {
      if (line.querySelector(".foto-person-change-wrap")) return;

      const verfuegbar = (personenCache || [])
        .slice()
        .sort((a,b) =>
          `${a.nachname || ""} ${a.vorname || ""}`.localeCompare(
            `${b.nachname || ""} ${b.vorname || ""}`, "de"
          )
        );

      const wrap = document.createElement("div");
      wrap.className = "foto-person-change-wrap";

      const search = document.createElement("input");
      search.type = "search";
      search.className = "foto-person-change-search";
      search.placeholder = "Name oder Geburtsjahr suchen …";
      search.autocomplete = "off";
      search.setAttribute("aria-label", "Person suchen");

      const select = document.createElement("select");
      select.className = "foto-person-change-select";
      select.setAttribute("aria-label", "Person für diesen Marker auswählen");

      const save = document.createElement("button");
      save.type = "button";
      save.className = "btn btn--primary";
      save.textContent = "Zuordnung speichern";

      const cancel = document.createElement("button");
      cancel.type = "button";
      cancel.className = "btn btn--ghost";
      cancel.textContent = "Abbrechen";

      function fillSelect() {
        const q = treeNormalizeName(search.value);
        const filtered = q
          ? verfuegbar.filter(p => {
              const a = fotoPersonAnzeige(p);
              return treeNormalizeName(`${a.name} ${a.daten || ""}`).includes(q);
            })
          : verfuegbar;

        select.innerHTML = '<option value="">— Person auswählen —</option>' +
          filtered.map(p => {
            const anzeige = fotoPersonAnzeige(p);
            const belegung = fotoMarkierungen.find(x => x.id !== row.id && x.personen_id === p.id);
            const istAktuell = p.id === row.personen_id;
            const status = belegung && !istAktuell ? ` — bereits Nr. ${belegung.nummer}` : "";
            return `<option value="${escapeHtml(p.id)}" ${istAktuell ? "selected" : ""} ${belegung && !istAktuell ? "disabled" : ""}>${escapeHtml(anzeige.name)}${anzeige.daten ? ` — ${escapeHtml(anzeige.daten)}` : ""}${status}</option>`;
          }).join("");

        save.disabled = !select.value;
      }

      search.addEventListener("input", fillSelect);
      select.addEventListener("change", () => {
        save.disabled = !select.value;
      });

      wrap.append(search, select, save, cancel);

      // Die bestehende Zeile bleibt sichtbar; die Zuordnung wird darunter
      // geöffnet, damit die Bedienelemente auf iPhone/iPad eindeutig sind.
      line.classList.add("is-editing");
      line.appendChild(wrap);
      assignBtn.hidden = true;
      positionBtn.hidden = true;
      numberBtn.hidden = true;
      deleteBtn.hidden = true;

      fillSelect();
      search.focus();

      save.addEventListener("click", async () => {
        const neueId = select.value || null;
        if (!neueId) {
          fotoPersonenMessage.textContent = "Bitte zuerst eine Person auswählen.";
          return;
        }

        const belegung = fotoMarkierungen.find(x => x.id !== row.id && x.personen_id === neueId);
        if (belegung) {
          fotoPersonenMessage.textContent = `Diese Person ist bereits Nr. ${belegung.nummer} zugeordnet.`;
          return;
        }

        save.disabled = true;
        save.textContent = "Speichere …";

        const { error } = await sb.from("foto_personen")
          .update({ personen_id: neueId })
          .eq("id", row.id);

        if (error) {
          save.disabled = false;
          save.textContent = "Zuordnung speichern";
          fotoPersonenMessage.textContent = `Fehler beim Speichern: ${error.message}`;
          return;
        }

        row.personen_id = neueId;
        fotoPersonenMessage.textContent = `Nr. ${row.nummer}: ${fotoPersonName(neueId)} gespeichert ✓`;
        renderFotoMarkierungen();
      });

      cancel.addEventListener("click", () => {
        fotoPersonenMessage.textContent = "";
        renderFotoMarkierungen();
      });
    });

    positionBtn.addEventListener("click", () => {
      fotoAktiveMarkierungId = row.id;
      fotoPersonenMessage.textContent = `Tippe jetzt auf die Position von Nr. ${row.nummer}.`;
      renderFotoMarkierungen();
    });

    numberBtn.addEventListener("click", async () => {
      const wert = Number(prompt(`Neue Nummer für ${fotoPersonName(row.personen_id)}:`, row.nummer));
      if (!Number.isInteger(wert) || wert < 1) return;
      if (fotoMarkierungen.some(x => x.id !== row.id && Number(x.nummer) === wert)) {
        fotoPersonenMessage.textContent = `Nr. ${wert} ist bereits vergeben.`;
        return;
      }
      const { error } = await sb.from("foto_personen").update({ nummer: wert }).eq("id", row.id);
      if (!error) {
        row.nummer = wert;
        fotoAktiveMarkierungId = null;
        renderFotoMarkierungen();
      } else {
        fotoPersonenMessage.textContent = `Fehler beim Speichern der Nummer: ${error.message}`;
      }
    });

    deleteBtn.addEventListener("click", async () => {
      if (!confirm(`Nr. ${row.nummer} wirklich vom Foto entfernen?`)) return;
      const { error } = await sb.from("foto_personen").delete().eq("id", row.id);
      if (!error) {
        fotoMarkierungen = fotoMarkierungen.filter(x => x.id !== row.id);
        fotoAktiveMarkierungId = null;
        renderFotoMarkierungen();
      } else {
        fotoPersonenMessage.textContent = `Fehler beim Entfernen: ${error.message}`;
      }
    });

    fotoPersonenListe.appendChild(line);
  }
}

fotoMarkierbildWrap?.addEventListener("click", async (event) => {
  if (!fotoAktiveMarkierungId || !fotoMarkierbild.naturalWidth) return;

  const bildRect = fotoMarkierbild.getBoundingClientRect();
  if (!bildRect.width || !bildRect.height) return;

  // Position wird ausschließlich relativ zum tatsächlich dargestellten Bild
  // gespeichert. Dadurch bleibt sie bei jeder späteren Darstellung exakt gleich.
  const x = Math.max(0, Math.min(100, ((event.clientX - bildRect.left) / bildRect.width) * 100));
  const y = Math.max(0, Math.min(100, ((event.clientY - bildRect.top) / bildRect.height) * 100));

  const row = fotoMarkierungen.find(r => r.id === fotoAktiveMarkierungId);
  if (!row) return;
  const { error } = await sb.from("foto_personen").update({ position_x: x, position_y: y, position_format: "bild" }).eq("id", row.id);
  if (!error) { row.position_x = x; row.position_y = y; row.position_format = "bild"; fotoAktiveMarkierungId = null; fotoPersonenMessage.textContent = "Position gespeichert ✓"; renderFotoMarkierungen(); }
  else fotoPersonenMessage.textContent = `Fehler: ${error.message}`;
});

document.getElementById("foto-person-hinzufuegen")?.addEventListener("click", async () => {
  const personenId = fotoPersonAuswahl.value;
  if (!personenId || !fotoPersonenAktuell) return;
  const maxNr = Math.max(0, ...fotoMarkierungen.map(r => Number(r.nummer) || 0));
  const { data, error } = await sb.from("foto_personen").insert({ foto_id: fotoPersonenAktuell.id, personen_id: personenId, nummer: maxNr + 1, position_x: 50, position_y: 50, position_format: "bild" }).select().single();
  if (error) { fotoPersonenMessage.textContent = `Fehler: ${error.message}`; return; }
  fotoMarkierungen.push(data); fotoPersonAuswahl.value = ""; renderFotoMarkierungen();
});

document.getElementById("foto-unbekannt-hinzufuegen")?.addEventListener("click", async () => {
  if (!fotoPersonenAktuell) return;
  const maxNr = Math.max(0, ...fotoMarkierungen.map(r => Number(r.nummer) || 0));
  const { data, error } = await sb.from("foto_personen").insert({ foto_id: fotoPersonenAktuell.id, personen_id: null, nummer: maxNr + 1, position_x: 50, position_y: 50, position_format: "bild" }).select().single();
  if (error) { fotoPersonenMessage.textContent = `Fehler: ${error.message}`; return; }
  fotoMarkierungen.push(data); renderFotoMarkierungen();
});

document.getElementById("foto-personen-close")?.addEventListener("click", () => { fotoPersonenModal.hidden = true; fotoPersonenAktuell = null; fotoMarkierungen = []; fotoAktiveMarkierungId = null; });
fotoPersonenModal?.addEventListener("click", e => { if (e.target === fotoPersonenModal) fotoPersonenModal.hidden = true; });

const detailPhotoViewer = document.getElementById("detail-photo-viewer");
const detailPhotoViewerImg = document.getElementById("detail-photo-viewer-img");
const detailPhotoViewerClose = document.getElementById("detail-photo-viewer-close");
const detailPhotoViewerMarkers = document.getElementById("detail-photo-viewer-markers");
const detailPhotoViewerLegend = document.getElementById("detail-photo-viewer-legend");

function closeDetailPhotoViewer() {
  if (!detailPhotoViewer) return;
  detailPhotoViewer.hidden = true;
  if (detailPhotoViewerImg) detailPhotoViewerImg.src = "";
  if (detailPhotoViewerMarkers) detailPhotoViewerMarkers.innerHTML = "";
  if (detailPhotoViewerLegend) { detailPhotoViewerLegend.innerHTML = ""; detailPhotoViewerLegend.hidden = true; }
}

let detailViewerFoto = null;
let detailViewerMarkierungen = [];
let detailViewerUrl = "";

function renderGruppenfotoViewer(url, markierungen = [], foto = null) {
  if (!detailPhotoViewer || !detailPhotoViewerImg || !url) return;
  detailViewerFoto = foto || null;
  detailViewerMarkierungen = markierungen || [];
  detailViewerUrl = url;
  detailPhotoViewerImg.src = url;
  if (detailPhotoViewerMarkers) detailPhotoViewerMarkers.innerHTML = "";
  if (detailPhotoViewerLegend) detailPhotoViewerLegend.innerHTML = "";

  const rows = [...(markierungen || [])].sort((a,b) => Number(a.nummer) - Number(b.nummer));
  rows.forEach(row => {
    const marker = document.createElement("span");
    marker.className = "detail-photo-viewer__marker";
    marker.textContent = row.nummer;
    marker.style.left = `${Number(row.position_x ?? 50)}%`;
    marker.style.top = `${Number(row.position_y ?? 50)}%`;
    marker.title = `${row.nummer}: ${fotoPersonName(row.personen_id)}`;
    detailPhotoViewerMarkers?.appendChild(marker);

    const legend = document.createElement("div");
    legend.className = "detail-photo-viewer__legend-item";
    const badge = document.createElement("span");
    badge.className = "detail-photo-viewer__legend-num";
    badge.textContent = row.nummer;
    const name = document.createElement("button");
    name.type = "button";
    name.className = "detail-photo-viewer__legend-name";
    name.textContent = fotoPersonName(row.personen_id);
    name.disabled = false;
    if (row.personen_id) {
      name.dataset.personId = row.personen_id;
    } else {
      name.classList.add("is-unknown");
      name.title = "Tippen, um eine Person zuzuordnen";
    }

    // Auf dem iPad zuverlässig über Touch/Pointer reagieren.
    // Der gesamte Legenden-Eintrag ist anklickbar, nicht nur der Text.
    if (!row.personen_id) {
      const openChooser = (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (legend.querySelector(".detail-photo-viewer__assign")) return;
        name.hidden = true;
        const wrap = document.createElement("div");
        wrap.className = "detail-photo-viewer__assign";
        const search = document.createElement("input");
        search.type = "search";
        search.placeholder = "Name suchen …";
        search.autocomplete = "off";
        const select = document.createElement("select");
        select.innerHTML = '<option value="">— Person auswählen —</option>';
        const save = document.createElement("button");
        save.type = "button"; save.className = "btn btn--secondary"; save.textContent = "Zuordnen";
        const cancel = document.createElement("button");
        cancel.type = "button"; cancel.className = "btn btn--ghost"; cancel.textContent = "Abbrechen";

        const verfuegbar = (personenCache || [])
          .filter(p => !detailViewerMarkierungen.some(x => x.id !== row.id && x.personen_id === p.id))
          .slice()
          .sort((a,b) => `${a.nachname||""} ${a.vorname||""}`.localeCompare(`${b.nachname||""} ${b.vorname||""}`, "de"));
        const fill = () => {
          const q = search.value.trim().toLocaleLowerCase("de");
          const list = q ? verfuegbar.filter(p => {
            const a = fotoPersonAnzeige(p);
            return `${a.name} ${a.daten||""}`.toLocaleLowerCase("de").includes(q);
          }) : verfuegbar;
          select.innerHTML = '<option value="">— Person auswählen —</option>' + list.map(p => {
            const a = fotoPersonAnzeige(p);
            return `<option value="${p.id}">${escapeHtml(a.name)}${a.daten ? ` — ${escapeHtml(a.daten)}` : ""}</option>`;
          }).join("");
        };
        fill();
        search.addEventListener("input", fill);
        save.addEventListener("click", async () => {
          const neueId = select.value;
          if (!neueId) return;
          if (detailViewerMarkierungen.some(x => x.id !== row.id && x.personen_id === neueId)) return;
          const { error } = await sb.from("foto_personen").update({ personen_id: neueId }).eq("id", row.id);
          if (error) {
            const msg = document.createElement("div");
            msg.className = "form-message"; msg.textContent = `Fehler: ${error.message}`;
            wrap.appendChild(msg);
            return;
          }
          row.personen_id = neueId;
          renderGruppenfotoViewer(detailViewerUrl, detailViewerMarkierungen, detailViewerFoto);
        });
        cancel.addEventListener("click", () => renderGruppenfotoViewer(detailViewerUrl, detailViewerMarkierungen, detailViewerFoto));
        wrap.append(search, select, save, cancel);
        legend.appendChild(wrap);
        search.focus();
      };
      name.addEventListener("click", openChooser);
      name.addEventListener("pointerup", (event) => { if (event.pointerType === "touch") openChooser(event); });
      legend.style.cursor = "pointer";
    } else {
      const openPerson = async (event) => {
        event.preventDefault();
        event.stopPropagation();
        const personId = row.personen_id;
        closeDetailPhotoViewer();
        // Personen-Tab aktivieren, damit die darunterliegende Ansicht
        // ebenfalls auf dem richtigen Bereich steht.
        document.querySelector('.tab-btn[data-tab="liste"]')?.click();
        try {
          await openPersonDetail(personId);
        } catch (err) {
          debugLog(`❌ Person aus Gruppenfoto öffnen: ${err.message || err}`);
        }
      };
      name.addEventListener("click", openPerson);
      name.addEventListener("pointerup", (event) => {
        if (event.pointerType === "touch") openPerson(event);
      });
      legend.addEventListener("click", (event) => {
        if (event.target === name) return;
        openPerson(event);
      });
      legend.style.cursor = "pointer";
    }
    legend.append(badge, name);
    detailPhotoViewerLegend?.appendChild(legend);
  });
  if (detailPhotoViewerLegend) detailPhotoViewerLegend.hidden = rows.length === 0;
  detailPhotoViewer.hidden = false;
}

function openGruppenfotoViewer(url, markierungen = [], foto = null) {
  renderGruppenfotoViewer(url, markierungen, foto);
}

detailPhotoViewerClose?.addEventListener("click", closeDetailPhotoViewer);
detailPhotoViewer?.addEventListener("click", (event) => {
  if (event.target === detailPhotoViewer) closeDetailPhotoViewer();
});

// Auch das gerade ausgewählte Foto bei „Neu erfassen“ kann vergrößert werden.
function openPreviewFoto() {
  if (!fotoPreview?.src || fotoPreview.hidden) return;
  if (detailPhotoViewerImg) detailPhotoViewerImg.src = fotoPreview.src;
  if (detailPhotoViewer) detailPhotoViewer.hidden = false;
}
fotoPreview?.addEventListener("click", openPreviewFoto);
fotoPreview?.addEventListener("pointerup", openPreviewFoto);

document.getElementById("d-foto-input").addEventListener("change", async (e) => {
  if (e.target.files.length) {
    for (const file of Array.from(e.target.files)) await uploadDetailFoto(file);
    e.target.value = "";
  }
});
document.getElementById("d-foto-input-galerie").addEventListener("change", async (e) => {
  if (e.target.files.length) {
    for (const file of Array.from(e.target.files)) await uploadDetailFoto(file);
    e.target.value = "";
  }
});

// ---- Sprachnotizen im Detail ----
async function loadDetailAudio(personId) {
  const container = document.getElementById("d-audio-list");
  container.innerHTML = "";
  const { data, error } = await sb.from("sprachnotizen").select("*").eq("person_id", personId);
  if (error) { debugLog(`❌ Sprachnotizen laden: ${error.message}`); return; }
  for (const note of data || []) {
    const { data: signed } = await sb.storage.from(BUCKET_AUDIO).createSignedUrl(note.dateipfad, 3600);
    const div = document.createElement("div");
    div.className = "detail-media-item";
    div.innerHTML = `<audio controls src="${signed ? signed.signedUrl : ""}"></audio><button class="del-btn" title="Löschen">🗑️</button>`;
    div.querySelector(".del-btn").addEventListener("click", async () => {
      await sb.storage.from(BUCKET_AUDIO).remove([note.dateipfad]);
      await sb.from("sprachnotizen").delete().eq("id", note.id);
      loadDetailAudio(personId);
    });
    container.appendChild(div);
  }
}

document.getElementById("d-audio-record-btn").addEventListener("click", async () => {
  const msg = document.getElementById("d-audio-message");
  const btn = document.getElementById("d-audio-record-btn");
  if (!detailIsRecording) {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const chosenType = pickAudioMimeType();
      detailAudioMediaRecorder = chosenType ? new MediaRecorder(stream, { mimeType: chosenType }) : new MediaRecorder(stream);
      detailAudioChunks = [];
      detailAudioMediaRecorder.ondataavailable = (e) => detailAudioChunks.push(e.data);
      detailAudioMediaRecorder.onstop = async () => {
        const mimeType = detailAudioMediaRecorder.mimeType || chosenType || "audio/webm";
        const ext = mimeType.includes("mp4") ? "m4a" : mimeType.includes("ogg") ? "ogg" : "webm";
        const blob = new Blob(detailAudioChunks, { type: mimeType });
        const dauer = Math.round((Date.now() - detailAudioStart) / 1000);
        stream.getTracks().forEach((t) => t.stop());
        msg.textContent = "Lade hoch …";
        const path = `${currentDetailPersonId}/${Date.now()}.${ext}`;
        const { error: uploadError } = await sb.storage.from(BUCKET_AUDIO).upload(path, blob);
        if (uploadError) { msg.textContent = `Fehler: ${uploadError.message}`; return; }
        const { error: insertError } = await sb.from("sprachnotizen").insert({
          person_id: currentDetailPersonId, dateipfad: path, dauer_sekunden: dauer,
        });
        msg.textContent = insertError ? `Fehler: ${insertError.message}` : "Sprachnotiz hinzugefügt ✓";
        loadDetailAudio(currentDetailPersonId);
      };
      detailAudioMediaRecorder.start();
      detailAudioStart = Date.now();
      detailIsRecording = true;
      btn.textContent = "⏹️ Aufnahme stoppen";
    } catch (err) {
      msg.textContent = "Mikrofonzugriff fehlgeschlagen";
    }
  } else {
    detailAudioMediaRecorder.stop();
    detailIsRecording = false;
    btn.textContent = "🎙️ Neue Aufnahme hinzufügen";
  }
});

// ---- Familie im Detail ----
function personNameById(id) {
  const p = personenCache.find((x) => x.id === id);
  return p ? `${p.vorname} ${p.nachname}` : "(unbekannte Person)";
}

function familiePartnerIds(familie, personId) {
  return [familie.partner_a_id, familie.partner_b_id].filter((id) => id && id !== personId);
}

async function loadDetailFamilie(personId) {
  const parentSelectVater = document.getElementById("d-vater");
  const parentSelectMutter = document.getElementById("d-mutter");
  const partnerList = document.getElementById("d-partner-list");
  const childList = document.getElementById("d-kinder-list");
  if (!parentSelectVater || !parentSelectMutter || !partnerList || !childList) return;

  // Die Familienansicht darf nicht davon abhängen, ob die globale Personenliste
  // vorher geladen wurde. Das Stammbaum-Fenster lädt Personen separat.
  // Deshalb wird hier sichergestellt, dass die Auswahl und die Kinderliste
  // einen vollständigen Personenbestand haben.
  if (personenCache.length < 2) {
    const { data: familienPersonen, error: familienPersonenError } = await sb
      .from("personen")
      .select("id, vorname, nachname, Ledigenname, geburtsdatum, geburtsjahr, sterbedatum, sterbejahr, geschlecht, Notiz")
      .order("nachname", { ascending: true });
    if (familienPersonenError) {
      debugLog(`❌ Personen für Familienauswahl laden: ${familienPersonenError.message}`);
    } else if (Array.isArray(familienPersonen)) {
      personenCache = familienPersonen;
    }
  }

  const [{ data: childLinks, error: childError }, partnerAResult, partnerBResult] = await Promise.all([
    sb.from("familien_kinder").select("id, familie_id, beziehungstyp").eq("kind_id", personId),
    sb.from("familien").select("*").eq("partner_a_id", personId),
    sb.from("familien").select("*").eq("partner_b_id", personId),
  ]);
  if (childError) debugLog(`❌ Eltern laden: ${childError.message}`);
  if (partnerAResult.error) debugLog(`❌ Familien laden (A): ${partnerAResult.error.message}`);
  if (partnerBResult.error) debugLog(`❌ Familien laden (B): ${partnerBResult.error.message}`);
  const partnerFamilies = [
    ...(partnerAResult.data || []),
    ...(partnerBResult.data || []),
  ].filter((f, index, arr) => arr.findIndex((x) => x.id === f.id) === index);

  const parentFamilyIds = (childLinks || []).map((x) => x.familie_id);
  let parentFamilies = [];
  if (parentFamilyIds.length) {
    const { data, error } = await sb.from("familien")
      .select("*")
      .in("id", parentFamilyIds);
    if (error) {
      debugLog(`❌ Elternfamilien laden: ${error.message}`);
    } else {
      // Jede Familienverknüpfung eines Kindes definiert seine Elternfamilie.
      // Der Familientyp kann "Partnerschaft", "Ehe" oder "Eltern" sein.
      parentFamilies = data || [];
    }
  }

  const detailPersonIds = new Set([personId]);
  for (const f of partnerFamilies) {
    for (const id of [f.partner_a_id, f.partner_b_id]) if (id) detailPersonIds.add(id);
  }
  for (const f of parentFamilies) {
    for (const id of [f.partner_a_id, f.partner_b_id]) if (id) detailPersonIds.add(id);
  }
  const detailPersonMap = new Map(personenCache.map((p) => [p.id, p]));
  if (detailPersonIds.size) {
    const { data: detailPersons, error: detailPersonsError } = await sb
      .from("personen")
      .select("id, vorname, nachname, Ledigenname, geburtsdatum, geburtsjahr, sterbedatum, sterbejahr, geschlecht")
      .in("id", Array.from(detailPersonIds));
    if (detailPersonsError) {
      debugLog(`❌ Personendaten für Familienanzeige: ${detailPersonsError.message}`);
    } else {
      for (const p of detailPersons || []) detailPersonMap.set(p.id, p);
    }
  }
  const detailPerson = (id) => detailPersonMap.get(id) || personenCache.find((p) => p.id === id) || null;

  // Nur eine Elternfamilie ist die aktive Elternbeziehung des Kindes.
  // Bei alten, fehlerhaften Mehrfachverknüpfungen wird die erste vollständige
  // Familie bevorzugt; beim Speichern werden alle alten Links bereinigt.
  const aktuelleElternfamilie = parentFamilies.find((f) =>
    f.partner_a_id && f.partner_b_id
  ) || parentFamilies[0] || null;

  let vaterId = null;
  let mutterId = null;
  if (aktuelleElternfamilie) {
    const a = detailPerson(aktuelleElternfamilie.partner_a_id);
    const b = detailPerson(aktuelleElternfamilie.partner_b_id);

    for (const p of [a, b]) {
      if (!p) continue;
      if (p.geschlecht === "männlich") vaterId = p.id;
      if (p.geschlecht === "weiblich") mutterId = p.id;
    }

    // Legacy-Daten ohne Geschlecht: A=Vater, B=Mutter.
    if (a && b && !vaterId && !mutterId) {
      vaterId = a.id;
      mutterId = b.id;
    } else if (a && b && !vaterId) {
      vaterId = a.id === mutterId ? b.id : a.id;
    } else if (a && b && !mutterId) {
      mutterId = a.id === vaterId ? b.id : a.id;
    }
  }

  [parentSelectVater, parentSelectMutter].forEach((select) => {
    select.innerHTML = '<option value="">— nicht angegeben —</option>';
    personenCache.filter((p) => p.id !== personId).sort(personenAuswahlSortierung).forEach((p) => {
      const opt = document.createElement("option");
      opt.value = p.id;
      opt.textContent = personenAuswahlText(p);
      select.appendChild(opt);
    });
  });

  parentSelectVater.value = vaterId || "";
  parentSelectMutter.value = mutterId || "";

  partnerList.innerHTML = "";
  for (const f of partnerFamilies || []) {
    const otherId = familiePartnerIds(f, personId)[0];
    if (!otherId) continue;
    const div = document.createElement("div");
    div.className = "detail-media-item familie-item";
    const typ = f.familientyp || "Partnerschaft";
    const tod = partnerschaftTodesende(f, detailPersonMap, personId);
    div.innerHTML = `
      <div class="beziehung-text familie-edit-block">
        <button type="button" class="familie-partner-link" title="Person bearbeiten">${personenAuswahlText(detailPerson(otherId))}</button>
        <div class="familie-edit-fields">
          <label class="field"><span>Art</span>
            <select class="familie-typ-edit">
              <option value="Partnerschaft">Partnerschaft</option>
              <option value="Ehe">Ehe</option>
            </select>
          </label>
          <label class="field"><span>Beginn</span>
            <div class="date-parts familie-beginn-edit">
              <select class="familie-beginn-tag"><option value="">Tag</option></select>
              <select class="familie-beginn-monat"><option value="">Monat</option></select>
              <select class="familie-beginn-jahr"><option value="">Jahr</option></select>
            </div>
          </label>
          <label class="field"><span>Ende</span>
            <div class="date-parts familie-ende-edit">
              <select class="familie-ende-tag"><option value="">Tag</option></select>
              <select class="familie-ende-monat"><option value="">Monat</option></select>
              <select class="familie-ende-jahr"><option value="">Jahr</option></select>
            </div>
          </label>
          <label class="field familie-jahre-field"><span>Ehejahre</span>
            <div class="familie-jahre">${ehejahreAnzeige({ ...f, familientyp: typ }, detailPersonMap) || "–"}</div>
          </label>
          <div class="familie-actions">
            <button class="del-btn" title="Partnerschaft löschen">🗑️</button>
          </div>
          <div class="familie-auto-ende"></div>
          <button type="button" class="btn btn--secondary familie-save-btn">Partnerschaft speichern</button>
        </div>
      </div>`;

    const typEdit = div.querySelector(".familie-typ-edit");
    const beginnEdit = div.querySelector(".familie-beginn-edit");
    const endeEdit = div.querySelector(".familie-ende-edit");
    const beginnPrefix = `familie-${f.id}-beginn`;
    const endePrefix = `familie-${f.id}-ende`;
    beginnEdit.querySelector(".familie-beginn-tag").id = `${beginnPrefix}-tag`;
    beginnEdit.querySelector(".familie-beginn-monat").id = `${beginnPrefix}-monat`;
    beginnEdit.querySelector(".familie-beginn-jahr").id = `${beginnPrefix}-jahr`;
    endeEdit.querySelector(".familie-ende-tag").id = `${endePrefix}-tag`;
    endeEdit.querySelector(".familie-ende-monat").id = `${endePrefix}-monat`;
    endeEdit.querySelector(".familie-ende-jahr").id = `${endePrefix}-jahr`;
    // Die dynamischen Selects direkt initialisieren. Das ist robuster als eine
    // Suche über dynamisch erzeugte IDs und stellt sicher, dass Tag/Monat/Jahr
    // immer vollständig als Auswahl vorhanden sind.
    const beginnTag = beginnEdit.querySelector(".familie-beginn-tag");
    const beginnMonat = beginnEdit.querySelector(".familie-beginn-monat");
    const beginnJahr = beginnEdit.querySelector(".familie-beginn-jahr");
    const endeTag = endeEdit.querySelector(".familie-ende-tag");
    const endeMonat = endeEdit.querySelector(".familie-ende-monat");
    const endeJahr = endeEdit.querySelector(".familie-ende-jahr");
    initDatumElemente(beginnTag, beginnMonat, beginnJahr);
    initDatumElemente(endeTag, endeMonat, endeJahr);
    const autoEndeEl = div.querySelector(".familie-auto-ende");
    // Merkt, ob der Benutzer das automatisch vorgeschlagene Ende bewusst
    // verändert hat. Dadurch kann ein gelöschtes Todesende als "Ende unbekannt"
    // gespeichert werden, ohne beim nächsten Laden sofort wieder aufzutauchen.
    let endeManuellGeaendert = false;
    typEdit.value = typ;
    setDatumElemente(beginnTag, beginnMonat, beginnJahr, f.beginn || null);
    if (f.ende) {
      // Ein tatsächlich gespeichertes Ende hat immer Vorrang.
      setDatumElemente(endeTag, endeMonat, endeJahr, f.ende);
    } else if (tod?.exakt) {
      // Exaktes Sterbedatum des zuerst verstorbenen Partners als Anzeige.
      // Es wird erst beim ausdrücklichen Speichern in die Familienbeziehung übernommen.
      setDatumElemente(endeTag, endeMonat, endeJahr, tod.datum);
    } else if (tod?.jahr) {
      // Nur Sterbejahr bekannt: ausschließlich das Jahr anzeigen.
      // Kein künstliches Datum (z. B. 01.01.) in der Datenbank.
      setDatumJahrElemente(endeTag, endeMonat, endeJahr, tod.jahr);
    } else {
      setDatumElemente(endeTag, endeMonat, endeJahr, null);
    }
    // Der Hinweis gehört dauerhaft zur Partnerschaft, wenn ihr Ende durch den
    // Tod des ANDEREN Partners bestimmt wurde. Ein manuelles Ende (z. B.
    // Scheidung) bleibt davon unberührt. Bei nur bekanntem Sterbejahr kann das
    // Jahr angezeigt werden, ohne ein künstliches Datum zu speichern.
    if (tod && (!f.ende || (tod.exakt && f.ende === tod.datum))) {
      autoEndeEl.textContent = tod.exakt
        ? `Ende automatisch durch Tod: ${datumAnzeige(tod.datum)}`
        : `Ende automatisch durch Tod: ${tod.jahr}`;
      autoEndeEl.className = "familie-auto-ende capture-status";
    }

    [endeTag, endeMonat, endeJahr].forEach((el) => el.addEventListener("change", () => {
      endeManuellGeaendert = true;
    }));

    div.querySelector(".familie-partner-link").addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      await openPersonDetail(otherId);
    });

    div.querySelector(".familie-save-btn").addEventListener("click", async () => {
      let eingegebenesEnde = getDatum(endePrefix);
      // Ist kein manuelles Ende eingegeben und ist der Todestag des anderen
      // Partners bekannt, wird dieser beim Speichern als Partnerschaftsende
      // übernommen. Bei nur bekanntem Sterbejahr bleibt das Ende absichtlich
      // NULL; der Hinweis bleibt trotzdem erhalten.
      // Nur wenn der Benutzer das Ende nicht verändert hat, darf der Tod
      // weiterhin automatisch als Ende übernommen werden. Wird ein
      // automatisch vorgeschlagenes Datum bewusst gelöscht, wird dies als
      // "Ende unbekannt / bereits beendet" gespeichert.
      let automatikIgnorieren = !!f.ende_automatik_ignorieren;
      if (endeManuellGeaendert) {
        automatikIgnorieren = !eingegebenesEnde;
      } else if (!eingegebenesEnde && tod?.exakt && !automatikIgnorieren) {
        eingegebenesEnde = tod.datum;
      }
      const updates = {
        familientyp: typEdit.value || "Partnerschaft",
        beginn: getDatum(beginnPrefix),
        ende: eingegebenesEnde,
        ende_automatik_ignorieren: automatikIgnorieren,
      };
      const msg = document.getElementById("d-familie-message");
      msg.textContent = "Partnerschaft wird gespeichert …";
      const { error } = await sb.from("familien").update(updates).eq("id", f.id);
      if (error) {
        msg.textContent = `Fehler: ${error.message}`;
      } else {
        msg.textContent = "Partnerschaft gespeichert ✓";
        await loadDetailFamilie(personId);
      }
    });

    div.querySelector(".del-btn").addEventListener("click", async () => {
      if (!confirm("Diese Partnerschaft mit allen zugehörigen Kinder-Verknüpfungen löschen?")) return;
      const { error } = await sb.from("familien").delete().eq("id", f.id);
      if (error) setDetailFamilieMessage(`Fehler: ${error.message}`);
      else await loadDetailFamilie(personId);
    });
    partnerList.appendChild(div);

    // Dauer der Ehe immer direkt nach dem Einfügen berechnen. Die Anzeige
    // hängt damit nicht davon ab, ob die vorherige HTML-Erzeugung den
    // Familientyp bereits korrekt normalisiert hat.
    const jahreEl = div.querySelector(".familie-jahre");
    const aktualisiereEhejahre = () => {
      const start = getDatumElemente(beginnTag, beginnMonat, beginnJahr);
      const end = getDatumElemente(endeTag, endeMonat, endeJahr);
      let text = "";
      if (String(typEdit.value || "").trim().toLocaleLowerCase("de") === "ehe" && start) {
        let endeDatum = end;
        if (!endeDatum && tod?.exakt) endeDatum = tod.datum;
        if (endeDatum) {
          const a = new Date(`${start}T00:00:00`);
          const b = new Date(`${String(endeDatum).slice(0,10)}T00:00:00`);
          if (!Number.isNaN(a.getTime()) && !Number.isNaN(b.getTime()) && b >= a) {
            let j = b.getFullYear() - a.getFullYear();
            if ((b.getMonth() * 100 + b.getDate()) < (a.getMonth() * 100 + a.getDate())) j--;
            if (j >= 0) text = `${j} Jahre`;
          }
        } else if (tod?.jahr) {
          const sj = Number(String(start).slice(0,4));
          const ej = Number(tod.jahr);
          if (Number.isFinite(sj) && Number.isFinite(ej) && ej >= sj) text = `${ej-sj} Jahre`;
        }
      }
      jahreEl.textContent = text;
    };
    [beginnTag, beginnMonat, beginnJahr, endeTag, endeMonat, endeJahr, typEdit].forEach((el) => el.addEventListener("change", aktualisiereEhejahre));
    aktualisiereEhejahre();
  }
  // Kompatibilitäts-Fallback: Falls der neue Familien-Datensatz nicht verfügbar ist,
  // lesen wir Partnerschaften aus der seit v9/v10 bewährten Tabelle beziehung.
  let kompatPartner = [];
  if (!partnerFamilies.length) {
    const { data: beziehungen, error: beziehungsError } = await sb
      .from("beziehung")
      .select("id, personen_a_id, personen_b_id, beziehungstyp")
      .or(`personen_a_id.eq.${personId},personen_b_id.eq.${personId}`);
    if (beziehungsError) {
      debugLog(`❌ Partnerschaften-Fallback: ${beziehungsError.message}`);
    } else {
      kompatPartner = (beziehungen || []).filter((b) =>
        b.beziehungstyp === "Ehe" || b.beziehungstyp === "Partnerschaft"
      );
    }
  }

  if (!partnerList.children.length) {
    for (const b of kompatPartner) {
      const otherId = b.personen_a_id === personId ? b.personen_b_id : b.personen_a_id;
      if (!otherId) continue;
      const div = document.createElement("div");
      div.className = "detail-media-item familie-item";
      div.innerHTML = `<span class="beziehung-text">${personenAuswahlText(detailPerson(otherId))} — ${b.beziehungstyp}</span><button class="del-btn" title="Partnerschaft löschen">🗑️</button>`;
      div.querySelector(".del-btn").addEventListener("click", async () => {
        if (!confirm("Diese Partnerschaft löschen?")) return;
        const { error } = await sb.from("beziehung").delete().eq("id", b.id);
        if (error) setDetailFamilieMessage(`Fehler: ${error.message}`);
        else await loadDetailFamilie(personId);
      });
      partnerList.appendChild(div);
    }
  }
  if (!partnerList.children.length) partnerList.innerHTML = '<span class="capture-status">Keine Partnerschaft erfasst</span>';

  // Kinder ausschließlich über die Familien dieses konkreten Paares laden.
  // Zuerst werden die Familien des aktuellen Elternteils ermittelt. Die
  // Kinderverknüpfungen werden danach über genau diese Familien gelesen.
  const partnerFamilyIds = (partnerFamilies || []).map((f) => f.id).filter(Boolean);
  let childLinksForPerson = [];
  if (partnerFamilyIds.length) {
    const { data, error } = await sb.from("familien_kinder")
      .select("id, familie_id, kind_id, beziehungstyp")
      .in("familie_id", partnerFamilyIds);
    if (error) {
      debugLog(`❌ Kinder laden: ${error.message}`);
    } else {
      childLinksForPerson = data || [];
    }
  }

  // Kinder immer direkt aus personen holen. Falls diese Abfrage scheitert,
  // wird der bereits geladene vollständige Personen-Cache verwendet.
  const childIds = [...new Set(childLinksForPerson.map((x) => x.kind_id).filter(Boolean))];
  let childPersons = [];
  if (childIds.length) {
    const { data, error } = await sb.from("personen").select("*").in("id", childIds);
    if (error) {
      debugLog(`❌ Kinderdaten direkt laden: ${error.message}`);
      childPersons = (personenCache || []).filter((p) => childIds.includes(p.id));
    } else {
      childPersons = data || [];
    }
  }
  const childPersonMap = new Map((childPersons || []).map((p) => [p.id, p]));

  childList.innerHTML = "";
  childLinksForPerson.sort((a, b) => {
    const childA = childPersonMap.get(a.kind_id);
    const childB = childPersonMap.get(b.kind_id);
    const dateA = String(childA?.geburtsdatum || "");
    const dateB = String(childB?.geburtsdatum || "");
    // Wie früher: Kinder chronologisch nach Geburtsdatum. Unbekannte Daten
    // stehen danach; bei Gleichstand entscheidet der Name.
    if (dateA && dateB) {
      const cmp = dateA.localeCompare(dateB);
      if (cmp !== 0) return cmp;
    } else if (dateA) return -1;
    else if (dateB) return 1;
    return personenAuswahlText(childA || { vorname: "", nachname: "" })
      .localeCompare(personenAuswahlText(childB || { vorname: "", nachname: "" }), "de", { sensitivity: "base" });
  });

  for (const link of childLinksForPerson) {
    const child = childPersonMap.get(link.kind_id);
    if (!child) {
      debugLog(`⚠️ Kind ${link.kind_id} ist verknüpft, aber der Personendatensatz konnte nicht geladen werden.`);
      continue;
    }
    const div = document.createElement("div");
    div.className = "detail-media-item familie-item";
    div.innerHTML = `<span class="beziehung-text" role="button" tabindex="0" title="Personendaten öffnen">${personenAuswahlText(child)}${link.beziehungstyp && link.beziehungstyp !== "biologisch" ? ` — ${link.beziehungstyp}` : ""}</span><button class="del-btn" title="Kind-Verknüpfung löschen">🗑️</button>`;
    const childNameEl = div.querySelector(".beziehung-text");
    const openChild = async (event) => { if (event) event.stopPropagation(); await openPersonDetail(child.id); };
    childNameEl.addEventListener("click", openChild);
    childNameEl.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") { event.preventDefault(); openChild(event); }
    });
    div.querySelector(".del-btn").addEventListener("click", async (event) => {
      event.stopPropagation();
      const childName = personenAuswahlText(child);
      if (!confirm(`Möchtest du die Kinder-Verknüpfung von „${childName}“ wirklich löschen?`)) return;
      const { error } = await sb.from("familien_kinder").delete().eq("id", link.id);
      if (error) { setDetailFamilieMessage(`Fehler: ${error.message}`); return; }
      try {
        await loescheElternfamilieWennLeer(link.familie_id);
        await loadDetailFamilie(personId);
      } catch (err) { setDetailFamilieMessage(`Fehler: ${err.message}`); }
    });
    childList.appendChild(div);
  }
  if (!childList.children.length) childList.innerHTML = '<span class="capture-status">Keine Kinder erfasst</span>';

  await fillFamilienPersonSelect("d-partner-person", personId);
  const partnerAddBtn = document.getElementById("d-add-partner-btn");
  if (partnerAddBtn) {
    const hatPartnerschaft = !!partnerList.querySelector(".familie-item");
    partnerAddBtn.hidden = !hatPartnerschaft;
    partnerAddBtn.textContent = hatPartnerschaft ? "Weitere Partnerschaft hinzufügen" : "Partnerschaft hinzufügen";
  }
  await fillFamilienPersonSelect("d-kind-person", personId);
  const familySelect = document.getElementById("d-kind-partner-family");
  familySelect.innerHTML = "";
  const validPartnerFamilies = (partnerFamilies || []).filter((f) => {
    const otherId = familiePartnerIds(f, personId)[0];
    return !!otherId;
  });
  if (!validPartnerFamilies.length) {
    familySelect.appendChild(new Option("— keine Partnerschaft vorhanden —", ""));
    familySelect.disabled = true;
  } else {
    familySelect.disabled = false;
    familySelect.appendChild(new Option(
      validPartnerFamilies.length === 1 ? "— diese Partnerschaft —" : "— Partnerschaft auswählen —",
      ""
    ));
    for (const f of validPartnerFamilies) {
      const otherId = familiePartnerIds(f, personId)[0];
      const opt = document.createElement("option");
      opt.value = f.id;
      opt.textContent = `${personenAuswahlText(detailPerson(otherId))} — ${f.familientyp || "Partnerschaft"}`;
      familySelect.appendChild(opt);
    }
    // Bei genau einem Paar ist dieses Paar eindeutig und wird automatisch
    // ausgewählt. Bei mehreren Partnerschaften muss der Benutzer das Paar
    // ausdrücklich auswählen. Andere Personen/Familien erscheinen hier nie.
    if (validPartnerFamilies.length === 1) familySelect.value = validPartnerFamilies[0].id;
  }
}

async function fillFamilienPersonSelect(selectId, excludePersonId) {
  const select = document.getElementById(selectId);
  if (!select) return;

  select.innerHTML = '<option value="">— auswählen —</option>';

  // Die Auswahl darf nie von einem unvollständigen Cache abhängen.
  // "select *" ist absichtlich gewählt, damit zusätzliche/ältere Spalten
  // in der Tabelle nicht dazu führen, dass die gesamte Personenabfrage fehlschlägt.
  let personenFuerAuswahl = [];
  try {
    const { data, error } = await sb.from("personen")
      .select("*")
      .order("nachname", { ascending: true });
    if (error) throw error;
    personenFuerAuswahl = Array.isArray(data) ? data : [];
    if (personenFuerAuswahl.length) personenCache = personenFuerAuswahl;
  } catch (err) {
    debugLog(`⚠️ Personen für Auswahl direkt laden: ${err.message || err}`);
    personenFuerAuswahl = Array.isArray(personenCache) ? personenCache : [];
  }

  let kandidaten = personenFuerAuswahl.filter((p) => p.id !== excludePersonId);

  // Partnerauswahl: eine Person mit einer laufenden Ehe/Partnerschaft
  // steht nicht nochmals als laufender Partner zur Verfügung.
  if (selectId === "d-partner-person") {
    kandidaten = kandidaten.filter((p) => !partnerIdsAuswahlCache.has(p.id));
  }

  // Kinder: Eine Person, die bereits als Kind einer Familie eingetragen ist,
  // soll nicht ein zweites Mal ein Elternpaar bekommen. Außerdem darf ein
  // Elternteil der aktuell bearbeiteten Person nicht gleichzeitig als deren
  // Kind ausgewählt werden. Das ist nur ein Auswahlfilter und verändert keine
  // bestehenden Daten.
  if (selectId === "d-kind-person") {
    try {
      const [{ data: kinderLinks, error: kinderError }, { data: eigeneFamilien, error: familienError }] = await Promise.all([
        sb.from("familien_kinder").select("kind_id"),
        sb.from("familien").select("partner_a_id, partner_b_id").or(`partner_a_id.eq.${excludePersonId},partner_b_id.eq.${excludePersonId}`)
      ]);
      if (kinderError) throw kinderError;
      if (familienError) throw familienError;

      const hatBereitsEltern = new Set((kinderLinks || []).map((k) => k.kind_id).filter(Boolean));
      const eigeneElternteile = new Set();
      for (const f of eigeneFamilien || []) {
        if (f.partner_a_id && f.partner_a_id !== excludePersonId) eigeneElternteile.add(f.partner_a_id);
        if (f.partner_b_id && f.partner_b_id !== excludePersonId) eigeneElternteile.add(f.partner_b_id);
      }

      kandidaten = kandidaten.filter((p) =>
        !hatBereitsEltern.has(p.id) && !eigeneElternteile.has(p.id)
      );
    } catch (err) {
      debugLog(`⚠️ Kinder-Auswahlfilter: ${err.message || err}`);
      // Bei einem Filterfehler keine Daten verstecken. Die Auswahl bleibt
      // wie bisher funktionsfähig.
    }
  }

  kandidaten.sort((a, b) => {
    const name = personenAuswahlText(a).localeCompare(personenAuswahlText(b), "de", { sensitivity: "base" });
    return name;
  });

  for (const p of kandidaten) {
    const opt = document.createElement("option");
    opt.value = p.id;
    opt.textContent = personenAuswahlText(p);
    select.appendChild(opt);
  }
}

async function findeOderErstelleFamilie(partnerAId, partnerBId, typ = "Partnerschaft", beginn = null, ende = null) {
  if (!partnerAId) throw new Error("Partner A fehlt.");

  // Partnerschaft: bewusst nur EIN einfacher INSERT.
  // Keine gegenseitige Prüfung, keine Vorab-Suche, kein RETURNING/SELECT.
  if (partnerBId) {
    // Exakt derselbe einfache INSERT wie der erfolgreiche SQL-Test.
    // Die Datenbank erzeugt die UUID selbst.
    const datensatz = {
      partner_a_id: partnerAId,
      partner_b_id: partnerBId,
      familientyp: typ || "Partnerschaft",
      beginn: beginn || null,
      ende: ende || null,
    };

    debugLog(`Familien-INSERT: ${partnerAId} ↔ ${partnerBId}`);
    const { error } = await sb.from("familien").insert(datensatz);
    if (error) throw error;

    debugLog("Familien-INSERT erfolgreich.");
    return datensatz;
  }

  // Ein Eltern-/Einzel-Eltern-Familieneintrag.
  const neueId = crypto.randomUUID();
  const datensatz = {
    id: neueId,
    partner_a_id: partnerAId,
    partner_b_id: null,
    familientyp: typ || "Partnerschaft",
    beginn: beginn || null,
    ende: ende || null,
  };

  const { error } = await sb.from("familien").insert(datensatz);
  if (error) throw error;
  return datensatz;
}

async function addKindZuFamilie(familieId, kindId, beziehungstyp = "biologisch") {
  const { error } = await sb.from("familien_kinder").upsert({
    familie_id: familieId,
    kind_id: kindId,
    beziehungstyp,
  }, { onConflict: "familie_id,kind_id" });
  if (error) throw error;
}

async function speichereElternZuKind(kindId, vaterId, mutterId) {
  if (vaterId && mutterId && vaterId === mutterId) {
    throw new Error("Vater und Mutter dürfen nicht dieselbe Person sein.");
  }

  // Alle Familienverknüpfungen dieses Kindes laden.
  const { data: links, error: linksError } = await sb
    .from("familien_kinder")
    .select("id, familie_id, kind_id, beziehungstyp")
    .eq("kind_id", kindId);
  if (linksError) throw linksError;

  const familyIds = [...new Set((links || []).map((l) => l.familie_id))];
  let families = [];
  if (familyIds.length) {
    const { data, error } = await sb.from("familien")
      .select("id, partner_a_id, partner_b_id, familientyp, beginn, ende")
      .in("id", familyIds);
    if (error) throw error;
    families = data || [];
  }

  const oldParentLinks = (links || []).filter((l) =>
    families.some((f) => f.id === l.familie_id && f.familientyp === "Eltern")
  );

  // Ziel-Familie: A=Vater (oder einziger Elternteil), B=Mutter.
  const zielA = vaterId || mutterId || null;
  const zielB = vaterId && mutterId ? mutterId : null;

  // Keine Eltern gewählt: alle Elternlinks dieses Kindes entfernen.
  if (!zielA) {
    for (const link of oldParentLinks) {
      const { error } = await sb.from("familien_kinder").delete().eq("id", link.id);
      if (error) throw error;
      await loescheElternfamilieWennLeer(link.familie_id);
    }
    return;
  }

  // Wichtig:
  // Die Elternfamilie wird NICHT nur bei den Familien dieses Kindes gesucht.
  // Eine Elternfamilie gehört zu den Eltern und wird von mehreren Geschwistern
  // gemeinsam verwendet. Früher konnte deshalb beim Speichern eines weiteren
  // Kindes eine zweite identische Elternfamilie entstehen.
  let zielFamilie = null;

  if (zielB) {
    const { data, error } = await sb.from("familien")
      .select("id, partner_a_id, partner_b_id, familientyp, beginn, ende")
      .eq("familientyp", "Eltern")
      .or(
        `and(partner_a_id.eq.${zielA},partner_b_id.eq.${zielB}),` +
        `and(partner_a_id.eq.${zielB},partner_b_id.eq.${zielA})`
      )
      .order("created_at", { ascending: true })
      .limit(1);
    if (error) throw error;
    zielFamilie = (data || [])[0] || null;
  } else {
    const { data, error } = await sb.from("familien")
      .select("id, partner_a_id, partner_b_id, familientyp, beginn, ende")
      .eq("familientyp", "Eltern")
      .eq("partner_a_id", zielA)
      .is("partner_b_id", null)
      .order("created_at", { ascending: true })
      .limit(1);
    if (error) throw error;
    zielFamilie = (data || [])[0] || null;
  }

  // Nur wenn wirklich noch keine passende Elternfamilie existiert,
  // wird eine neue angelegt.
  if (!zielFamilie) {
    const { data, error } = await sb.from("familien")
      .insert({
        partner_a_id: zielA,
        partner_b_id: zielB,
        familientyp: "Eltern"
      })
      .select("id, partner_a_id, partner_b_id, familientyp, beginn, ende")
      .single();
    if (error) throw error;
    zielFamilie = data;
  }

  // Alle bisherigen Elternlinks dieses Kindes entfernen.
  // Dadurch bleiben keine alten falschen Vater/Mutter-Kombinationen bestehen.
  for (const link of oldParentLinks) {
    if (link.familie_id === zielFamilie.id) continue;
    const { error } = await sb.from("familien_kinder").delete().eq("id", link.id);
    if (error) throw error;
    await loescheElternfamilieWennLeer(link.familie_id);
  }

  const existingTarget = oldParentLinks.find((l) => l.familie_id === zielFamilie.id);
  if (!existingTarget) {
    const { error } = await sb.from("familien_kinder").insert({
      familie_id: zielFamilie.id,
      kind_id: kindId,
      beziehungstyp: "biologisch"
    });
    if (error) throw error;
  }
}

async function loescheElternfamilieWennLeer(familieId) {
  const { data, error } = await sb.from("familien_kinder")
    .select("id")
    .eq("familie_id", familieId)
    .limit(1);
  if (error) throw error;

  if (!data || data.length === 0) {
    const { error: delError } = await sb.from("familien")
      .delete()
      .eq("id", familieId);
    if (delError) throw delError;
  }
}

document.getElementById("d-save-eltern-btn").addEventListener("click", async () => {
  const msg = document.getElementById("d-familie-message");
  const vater = document.getElementById("d-vater").value || null;
  const mutter = document.getElementById("d-mutter").value || null;

  msg.textContent = "Speichere Eltern …";
  try {
    await speichereElternZuKind(currentDetailPersonId, vater, mutter);
    msg.textContent = "Eltern gespeichert ✓";
    await loadDetailFamilie(currentDetailPersonId);
  } catch (err) {
    msg.textContent = `Fehler: ${err.message}`;
    debugLog(`❌ Eltern speichern: ${err.message}`);
  }
});

// Partner/in auswählen löst KEIN automatisches Speichern aus.
// Zuerst Partner/in, Art (Partnerschaft/Ehe) und optional die Daten auswählen,
// anschließend ausdrücklich auf „Partner/in hinzufügen“ tippen.
function aktualisiereNeueEhejahre() {
  const el = document.getElementById("d-partner-ehejahre");
  if (!el) return;
  const typ = document.getElementById("d-partner-typ")?.value || "";
  if (typ.toLocaleLowerCase("de") !== "ehe") { el.textContent = "–"; return; }
  const start = getDatum("d-partner-beginn");
  let end = getDatum("d-partner-ende");
  if (!start || !end) { el.textContent = "–"; return; }
  const a = new Date(`${start}T00:00:00`);
  const b = new Date(`${end}T00:00:00`);
  if (Number.isNaN(a.getTime()) || Number.isNaN(b.getTime()) || b < a) { el.textContent = "–"; return; }
  let jahre = b.getFullYear() - a.getFullYear();
  if ((b.getMonth() * 100 + b.getDate()) < (a.getMonth() * 100 + a.getDate())) jahre--;
  el.textContent = jahre >= 0 ? `${jahre} Jahre` : "–";
}

document.getElementById("d-partner-person").addEventListener("change", () => {
  const msg = document.getElementById("d-familie-message");
  if (msg) msg.textContent = "";
  aktualisiereNeueEhejahre();
});
["d-partner-typ","d-partner-beginn-tag","d-partner-beginn-monat","d-partner-beginn-jahr","d-partner-ende-tag","d-partner-ende-monat","d-partner-ende-jahr"].forEach((id) => {
  document.getElementById(id)?.addEventListener("change", aktualisiereNeueEhejahre);
});
aktualisiereNeueEhejahre();

document.getElementById("d-add-partner-btn").addEventListener("click", async () => {
  const wasAutoPartnerSave = autoPartnerSave;
  const msg = document.getElementById("d-familie-message");
  const partnerId = document.getElementById("d-partner-person").value;
  if (!partnerId) { msg.textContent = "Bitte Partner/in auswählen."; return; }

  msg.textContent = "INSERT Partnerschaft: wird gespeichert …";
  try {
    await ensureSession();
    const { data: sessionData } = await sb.auth.getSession();
    const userId = sessionData?.session?.user?.id || "keine Session-ID";
    debugLog(`Partnerschaftstest: Session ${userId}`);

    const typ = document.getElementById("d-partner-typ").value;
    if (!typ) {
      msg.textContent = "Bitte zuerst Partnerschaft oder Ehe auswählen.";
      return;
    }
    const beginn = getDatum("d-partner-beginn");
    const ende = getDatum("d-partner-ende");

    const beziehungsDatensatz = {
      personen_a_id: currentDetailPersonId,
      personen_b_id: partnerId,
      beziehungstyp: typ,
    };

    debugLog(`BEZIEHUNG-INSERT: ${JSON.stringify(beziehungsDatensatz)}`);

    const { data: beziehungData, error: beziehungsError } = await sb
      .from("beziehung")
      .insert(beziehungsDatensatz)
      .select("id, personen_a_id, personen_b_id, beziehungstyp")
      .single();

    if (beziehungsError) {
      const detail = [
        beziehungsError.message,
        beziehungsError.details,
        beziehungsError.hint,
        beziehungsError.code ? `Code: ${beziehungsError.code}` : ""
      ].filter(Boolean).join(" | ");
      debugLog(`❌ BEZIEHUNG-INSERT FEHLER: ${detail}`);
      msg.textContent = `❌ INSERT FEHLER: ${detail}`;
      return;
    }

    debugLog(`✅ BEZIEHUNG-INSERT ERFOLGREICH: ${JSON.stringify(beziehungData)}`);
    msg.textContent = `✅ INSERT erfolgreich – ID: ${beziehungData.id}`;

    // Zusätzlich Familien-Datensatz versuchen. Ein Fehler hier wird separat angezeigt.
    try {
      const familienDatensatz = {
        partner_a_id: currentDetailPersonId,
        partner_b_id: partnerId,
        familientyp: typ,
        beginn,
        ende,
      };
      debugLog(`FAMILIEN-INSERT: ${JSON.stringify(familienDatensatz)}`);
      const { data: familienData, error: familyErr } = await sb
        .from("familien")
        .insert(familienDatensatz)
        .select("id, partner_a_id, partner_b_id, familientyp, beginn, ende")
        .single();

      if (familyErr) {
        const detail = [familyErr.message, familyErr.details, familyErr.hint, familyErr.code ? `Code: ${familyErr.code}` : ""]
          .filter(Boolean).join(" | ");
        debugLog(`⚠️ FAMILIEN-INSERT FEHLER: ${detail}`);
        msg.textContent = `✅ Beziehung gespeichert. ⚠️ Familien-INSERT Fehler: ${detail}`;
      } else {
        debugLog(`✅ FAMILIEN-INSERT ERFOLGREICH: ${JSON.stringify(familienData)}`);
        // Nur bei einer Ehe: derselbe Trauungsbuch-Link darf beim anderen
        // Ehepartner ergänzt werden. Andere Buch-Links werden nicht angefasst.
        if (typ === "Ehe") {
          try {
            await synchronisiereTrauungsbuchBeiEhe(currentDetailPersonId, partnerId);
          } catch (syncErr) {
            debugLog(`⚠️ Trauungsbuch-Synchronisierung bei Ehe: ${syncErr.message || syncErr}`);
          }
        }
        msg.textContent = `✅ INSERT erfolgreich – Beziehung + Familie gespeichert`;
      }
    } catch (familyErr) {
      const detail = familyErr?.message || String(familyErr);
      debugLog(`⚠️ FAMILIEN-INSERT AUSNAHME: ${detail}`);
      msg.textContent = `✅ Beziehung gespeichert. ⚠️ Familien-INSERT Fehler: ${detail}`;
    }

    if (!wasAutoPartnerSave) {
      document.getElementById("d-partner-person").value = "";
      setDatum("d-partner-beginn", null);
      setDatum("d-partner-ende", null);
    }
    await loadDetailFamilie(currentDetailPersonId);
    if (wasAutoPartnerSave) {
      const partnerSelect = document.getElementById("d-partner-person");
      if (partnerSelect) partnerSelect.value = partnerId;
    }
  } catch (err) {
    const detail = err?.message || String(err);
    debugLog(`❌ Partnerschaftstest AUSNAHME: ${detail}`);
    msg.textContent = `❌ INSERT FEHLER: ${detail}`;
  }
});

document.getElementById("d-add-kind-btn").addEventListener("click", async () => {
  const msg = document.getElementById("d-familie-message");
  const kindId = document.getElementById("d-kind-person").value;
  if (!kindId) { msg.textContent = "Bitte Kind auswählen."; return; }
  try {
    let familie = null;
    const partnerFamilies = await sb.from("familien").select("*").or(`partner_a_id.eq.${currentDetailPersonId},partner_b_id.eq.${currentDetailPersonId}`);
    const validPartnerFamilies = (partnerFamilies.data || []).filter((f) =>
      familiePartnerIds(f, currentDetailPersonId)[0]
    );
    const preferredPartnerId = document.getElementById("d-kind-partner-family").value || null;
    if (preferredPartnerId) familie = validPartnerFamilies.find((f) => f.id === preferredPartnerId) || null;
    if (!familie && validPartnerFamilies.length === 1) familie = validPartnerFamilies[0];
    if (!familie && validPartnerFamilies.length > 1) {
      msg.textContent = "Bitte die Partnerschaft auswählen, zu der das Kind gehört.";
      return;
    }
    if (!familie) {
      // Keine Partnerschaft vorhanden: Einzel-Elternfamilie anlegen, wie bisher.
      familie = await findeOderErstelleFamilie(currentDetailPersonId, null, "Eltern");
    }
    await addKindZuFamilie(familie.id, kindId, document.getElementById("d-kind-typ").value || "biologisch");
    msg.textContent = "Kind hinzugefügt ✓";
    document.getElementById("d-kind-person").value = "";
    await loadDetailFamilie(currentDetailPersonId);
  } catch (err) { msg.textContent = `Fehler: ${err.message}`; }
});

// ---- Person vollständig löschen ----
document.getElementById("d-delete-person-btn").addEventListener("click", async () => {
  const msg = document.getElementById("d-delete-message");
  if (!confirm("Diese Person inkl. aller Fotos, Sprachnotizen und Beziehungen unwiderruflich löschen?")) return;
  msg.textContent = "Lösche …";

  try {
    await ensureSession();

    // Zuerst abhängige Datensätze löschen. Dadurch blockieren alte
    // Beziehungen die Löschung der Person nicht mehr.
    const { error: beziehungError } = await sb.from("beziehung")
      .delete()
      .or(`personen_a_id.eq.${currentDetailPersonId},personen_b_id.eq.${currentDetailPersonId}`);
    if (beziehungError) throw beziehungError;

    // Familienzuordnungen explizit entfernen; vorhandene CASCADEs bleiben zusätzlich wirksam.
    const { data: familien, error: familienFetchError } = await sb.from("familien")
      .select("id")
      .or(`partner_a_id.eq.${currentDetailPersonId},partner_b_id.eq.${currentDetailPersonId}`);
    if (familienFetchError) throw familienFetchError;

    const familienIds = (familien || []).map(f => f.id);
    if (familienIds.length) {
      const { error: kinderError } = await sb.from("familien_kinder")
        .delete()
        .in("familie_id", familienIds);
      if (kinderError) throw kinderError;

      const { error: familienError } = await sb.from("familien")
        .delete()
        .in("id", familienIds);
      if (familienError) throw familienError;
    }

    const { data: fotos, error: fotoFetchError } = await sb.from("fotos")
      .select("*").eq("personen_id", currentDetailPersonId);
    if (fotoFetchError) throw fotoFetchError;

    for (const f of fotos || []) {
      if (f.dateipfad) await sb.storage.from(BUCKET_FOTOS).remove([f.dateipfad]);
      const { error } = await sb.from("fotos").delete().eq("id", f.id);
      if (error) throw error;
    }

    const { data: audios, error: audioFetchError } = await sb.from("sprachnotizen")
      .select("*").eq("person_id", currentDetailPersonId);
    if (audioFetchError) throw audioFetchError;

    for (const a of audios || []) {
      if (a.dateipfad) await sb.storage.from(BUCKET_AUDIO).remove([a.dateipfad]);
      const { error } = await sb.from("sprachnotizen").delete().eq("id", a.id);
      if (error) throw error;
    }

    const { error: personError } = await sb.from("personen")
      .delete()
      .eq("id", currentDetailPersonId);
    if (personError) throw personError;

    detailOverlay.hidden = true;
    currentDetailPersonId = null;
    msg.textContent = "";
    await loadPersonen();
  } catch (err) {
    const detail = (err && (err.message || err.error_description || err.msg)) || "Unbekannter Fehler";
    msg.textContent = `Fehler: ${detail}`;
    debugLog(`❌ Person löschen: ${detail}`);
  }
});

// ==========================================================
// EXPORT
// ==========================================================

function downloadFile(filename, content, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

async function fetchAllTableRows(table, orderColumn = "id") {
  const rows = [];
  const pageSize = 500;
  let from = 0;
  while (true) {
    const { data, error } = await sb.from(table).select("*").order(orderColumn).range(from, from + pageSize - 1);
    if (error) throw error;
    const page = data || [];
    rows.push(...page);
    if (page.length < pageSize) break;
    from += pageSize;
  }
  return rows;
}

async function optimiereBestehendeFotos() {
  const msg = document.getElementById("foto-optimieren-message");
  if (!msg) return;
  msg.textContent = "Fotos werden geprüft …";
  try {
    await ensureSession();
    const { data: fotos, error } = await sb.from("fotos").select("id, dateipfad");
    if (error) throw error;
    const eintraege = (fotos || []).filter(f => f.dateipfad);
    let gesamtAlt = 0;
    let ueberLimit = 0;
    const kandidaten = [];

    for (let i = 0; i < eintraege.length; i++) {
      const foto = eintraege[i];
      msg.textContent = `Fotos prüfen … ${i + 1}/${eintraege.length}`;
      const { data: blob, error: downloadError } = await sb.storage.from(BUCKET_FOTOS).download(foto.dateipfad);
      if (downloadError || !blob) continue;
      gesamtAlt += blob.size;
      if (blob.size > 200 * 1024) {
        ueberLimit++;
        kandidaten.push(foto);
      }
    }

    const altMB = gesamtAlt / 1024 / 1024;
    if (!kandidaten.length) {
      msg.textContent = `Keine Optimierung nötig. ${eintraege.length} Fotos · ${altMB.toFixed(2)} MB.`;
      return;
    }

    const ok = confirm(`${eintraege.length} Fotos · ${altMB.toFixed(2)} MB\n\n${ueberLimit} Fotos sind größer als 200 KB und werden optimiert.\n\nDie Originale auf deinem Gerät bleiben unverändert. Nur die Dateien in Supabase werden ersetzt.\n\nOptimierung starten?`);
    if (!ok) {
      msg.textContent = "Optimierung abgebrochen.";
      return;
    }

    let verarbeitet = 0;
    let altKandidaten = 0;
    let neuKandidaten = 0;
    let fehler = 0;

    for (let i = 0; i < kandidaten.length; i++) {
      const foto = kandidaten[i];
      msg.textContent = `Foto optimieren … ${i + 1}/${kandidaten.length}`;
      try {
        const { data: original, error: downloadError } = await sb.storage.from(BUCKET_FOTOS).download(foto.dateipfad);
        if (downloadError || !original) throw new Error(downloadError?.message || "Foto konnte nicht geladen werden");
        const optimiert = await blobZuJPEGUnter200KB(original);
        if (!optimiert) throw new Error("Optimierung fehlgeschlagen");
        altKandidaten += original.size;
        neuKandidaten += optimiert.size;

        const { error: updateError } = await sb.storage.from(BUCKET_FOTOS).update(foto.dateipfad, optimiert, {
          contentType: "image/jpeg",
          cacheControl: "3600",
        });
        if (updateError) throw updateError;
        verarbeitet++;
      } catch (err) {
        fehler++;
        debugLog(`❌ Fotooptimierung ${foto.dateipfad}: ${err.message || err}`);
      }
    }

    const altMB2 = altKandidaten / 1024 / 1024;
    const neuMB2 = neuKandidaten / 1024 / 1024;
    msg.textContent = `${verarbeitet} Fotos optimiert ✓ · ${altMB2.toFixed(2)} MB → ${neuMB2.toFixed(2)} MB${fehler ? ` · ${fehler} Fehler` : ""}`;
  } catch (err) {
    msg.textContent = `Fehler: ${err.message || err}`;
    debugLog(`❌ Fotooptimierung: ${err.message || err}`);
  }
}

async function fetchAllExportData() {
  const [personen, familien, familien_kinder, fotos, foto_personen, sprachnotizen] = await Promise.all([
    fetchAllTableRows("personen", "nachname"),
    fetchAllTableRows("familien", "id"),
    fetchAllTableRows("familien_kinder", "id"),
    fetchAllTableRows("fotos", "id"),
    fetchAllTableRows("foto_personen", "id"),
    fetchAllTableRows("sprachnotizen", "id"),
  ]);
  return { personen, familien, familien_kinder, fotos, foto_personen, sprachnotizen };
}

function backupDateiname() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `Partezettel_Backup_${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}.zip`;
}

function u16(value) {
  const a = new Uint8Array(2);
  new DataView(a.buffer).setUint16(0, value, true);
  return a;
}

function u32(value) {
  const a = new Uint8Array(4);
  new DataView(a.buffer).setUint32(0, value >>> 0, true);
  return a;
}

function concatBytes(parts) {
  const total = parts.reduce((sum, part) => sum + part.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const part of parts) {
    out.set(part, offset);
    offset += part.length;
  }
  return out;
}

// CRC-32 für ZIP-Dateien. Wir verwenden bewusst STORE (keine Kompression),
// damit das Backup ohne zusätzliche Bibliothek auf iPad/iPhone erzeugt werden kann.
const ZIP_CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(bytes) {
  let c = 0xFFFFFFFF;
  for (let i = 0; i < bytes.length; i++) c = ZIP_CRC_TABLE[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}

function zipEncodeName(name) {
  return new TextEncoder().encode(name);
}

function erstelleZip(entries) {
  const locals = [];
  const centrals = [];
  let offset = 0;

  for (const entry of entries) {
    const nameBytes = zipEncodeName(entry.name);
    const data = entry.data instanceof Uint8Array ? entry.data : new Uint8Array(entry.data);
    const crc = crc32(data);
    const local = concatBytes([
      new Uint8Array([0x50,0x4B,0x03,0x04]),
      u16(20), u16(0x0800), u16(0), u16(0), u16(0),
      u32(crc), u32(data.length), u32(data.length),
      u16(nameBytes.length), u16(0), nameBytes, data
    ]);
    locals.push(local);

    const central = concatBytes([
      new Uint8Array([0x50,0x4B,0x01,0x02]),
      u16(20), u16(20), u16(0x0800), u16(0), u16(0), u16(0),
      u32(crc), u32(data.length), u32(data.length),
      u16(nameBytes.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(offset),
      nameBytes
    ]);
    centrals.push(central);
    offset += local.length;
  }

  const centralOffset = offset;
  const centralBytes = concatBytes(centrals);
  const localBytes = concatBytes(locals);
  const count = entries.length;
  const eocd = concatBytes([
    new Uint8Array([0x50,0x4B,0x05,0x06]),
    u16(0), u16(0), u16(count), u16(count),
    u32(centralBytes.length), u32(centralOffset), u16(0)
  ]);
  return concatBytes([localBytes, centralBytes, eocd]);
}

function zipReadDirectory(bytes) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let eocd = -1;
  const min = Math.max(0, bytes.length - 65557);
  for (let i = bytes.length - 22; i >= min; i--) {
    if (view.getUint32(i, true) === 0x06054B50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error("Keine gültige ZIP-Datei.");

  const count = view.getUint16(eocd + 10, true);
  const centralSize = view.getUint32(eocd + 12, true);
  const centralOffset = view.getUint32(eocd + 16, true);
  if (centralOffset + centralSize > bytes.length) throw new Error("ZIP-Datei ist beschädigt.");

  const decoder = new TextDecoder();
  const entries = new Map();
  let p = centralOffset;
  for (let i = 0; i < count; i++) {
    if (view.getUint32(p, true) !== 0x02014B50) throw new Error("Ungültiger ZIP-Verzeichniseintrag.");
    const flags = view.getUint16(p + 8, true);
    const method = view.getUint16(p + 10, true);
    const compressedSize = view.getUint32(p + 20, true);
    const uncompressedSize = view.getUint32(p + 24, true);
    const nameLength = view.getUint16(p + 28, true);
    const extraLength = view.getUint16(p + 30, true);
    const commentLength = view.getUint16(p + 32, true);
    const localOffset = view.getUint32(p + 42, true);
    if (flags & 0x08) throw new Error("ZIP mit Daten-Deskriptor wird nicht unterstützt.");
    if (method !== 0) throw new Error("Dieses Backup verwendet eine nicht unterstützte Kompression.");

    const name = decoder.decode(bytes.subarray(p + 46, p + 46 + nameLength));
    const local = localOffset;
    if (view.getUint32(local, true) !== 0x04034B50) throw new Error("Ungültiger ZIP-Dateikopf.");
    const localNameLength = view.getUint16(local + 26, true);
    const localExtraLength = view.getUint16(local + 28, true);
    const dataStart = local + 30 + localNameLength + localExtraLength;
    const dataEnd = dataStart + compressedSize;
    if (dataEnd > bytes.length || uncompressedSize !== compressedSize) throw new Error("ZIP-Datei ist beschädigt.");
    entries.set(name, bytes.slice(dataStart, dataEnd));
    p += 46 + nameLength + extraLength + commentLength;
  }
  return entries;
}

function sichereDateiname(name) {
  return String(name || "datei").replace(/[^a-zA-Z0-9._-]/g, "_");
}

function mediaZipPath(bucket, path) {
  const parts = String(path || "").split("/").filter(Boolean).map(sichereDateiname);
  return `media/${bucket === BUCKET_FOTOS ? "fotos" : "sprachnotizen"}/${parts.join("/")}`;
}

async function sammleMedien(backupData, msg) {
  const media = [];
  const fehlendeFotos = [];
  const fehlendeAudio = [];
  const seen = new Set();
  const quellen = [
    ...(backupData.fotos || []).map((row) => ({ bucket: BUCKET_FOTOS, path: row.dateipfad, type: "foto" })),
    ...(backupData.sprachnotizen || []).map((row) => ({ bucket: BUCKET_AUDIO, path: row.dateipfad, type: "audio" })),
  ];

  let index = 0;
  for (const quelle of quellen) {
    if (!quelle.path || seen.has(`${quelle.bucket}|${quelle.path}`)) continue;
    seen.add(`${quelle.bucket}|${quelle.path}`);
    index++;
    msg.textContent = `Medien sichern … ${index}/${quellen.length}`;
    const { data, error } = await sb.storage.from(quelle.bucket).download(quelle.path);
    if (error || !data) {
      if (quelle.type === "foto") fehlendeFotos.push(quelle.path);
      else fehlendeAudio.push(quelle.path);
      debugLog(`⚠️ Mediendatei fehlt und wird im Backup übersprungen: ${quelle.bucket}/${quelle.path}`);
      continue;
    }
    const bytes = new Uint8Array(await data.arrayBuffer());
    media.push({
      bucket: quelle.bucket,
      path: quelle.path,
      zipPath: mediaZipPath(quelle.bucket, quelle.path),
      mimeType: data.type || (quelle.type === "foto" ? "image/jpeg" : "audio/mp4"),
      size: bytes.length,
      bytes,
    });
  }
  return { media, fehlendeFotos, fehlendeAudio };
}

async function teileOderLadeDateiHerunter(file) {
  if (navigator.share && navigator.canShare) {
    try {
      if (navigator.canShare({ files: [file] })) {
        await navigator.share({ title: "Partezettel Backup", text: "Vollständiges Partezettel-Backup", files: [file] });
        return "geteilt";
      }
    } catch (err) {
      if (err && err.name === "AbortError") return "abgebrochen";
      debugLog(`⚠️ Teilen nicht möglich, verwende Download: ${err.message || err}`);
    }
  }
  const url = URL.createObjectURL(file);
  const a = document.createElement("a");
  a.href = url;
  a.download = file.name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  return "download";
}

async function erstelleICloudBackup() {
  const msg = document.getElementById("backup-message");
  msg.textContent = "Backup wird vorbereitet …";
  try {
    await ensureSession();
    const data = await fetchAllExportData();
    const gesammelt = await sammleMedien(data, msg);
    const media = gesammelt.media;

    // Verwaiste Foto-Einträge werden beim Backup ebenfalls bereinigt.
    // Das verhindert, dass ein bereits gelöschtes Storage-Objekt später
    // beim Backup oder Restore wieder als defekter Foto-Datensatz auftaucht.
    if (gesammelt.fehlendeFotos.length) {
      const fehlendeSet = new Set(gesammelt.fehlendeFotos);
      data.fotos = (data.fotos || []).filter(row => !fehlendeSet.has(row.dateipfad));
      for (const path of gesammelt.fehlendeFotos) {
        const { error: deleteError } = await sb.from("fotos").delete().eq("dateipfad", path);
        if (deleteError) debugLog(`⚠️ Verwaister Fotoeintrag konnte nicht gelöscht werden: ${path} – ${deleteError.message}`);
      }
    }
    if (gesammelt.fehlendeAudio.length) {
      const fehlendeSet = new Set(gesammelt.fehlendeAudio);
      data.sprachnotizen = (data.sprachnotizen || []).filter(row => !fehlendeSet.has(row.dateipfad));
    }

    const manifest = {
      format: "partezettel-complete-backup",
      version: 2,
      createdAt: new Date().toISOString(),
      app: "Partezettel Archiv",
      tables: ["personen", "familien", "familien_kinder", "fotos", "foto_personen", "sprachnotizen"],
      media: media.map(({ bucket, path, zipPath, mimeType, size }) => ({ bucket, path, zipPath, mimeType, size })),
    };
    const daten = { ...data };
    const entries = [
      { name: "backup.json", data: new TextEncoder().encode(JSON.stringify({ manifest, data: daten }, null, 2)) },
    ];
    for (const item of media) entries.push({ name: item.zipPath, data: item.bytes });

    msg.textContent = `ZIP-Backup wird erstellt … (${entries.length} Dateien)`;
    const zipBytes = erstelleZip(entries);
    const file = new File([zipBytes], backupDateiname(), { type: "application/zip" });
    const result = await teileOderLadeDateiHerunter(file);
    const bereinigt = gesammelt.fehlendeFotos.length + gesammelt.fehlendeAudio.length;
    const hinweis = bereinigt ? ` · ${bereinigt} verwaiste Medieneinträge übersprungen` : "";
    if (result === "abgebrochen") msg.textContent = "Backup nicht gespeichert.";
    else if (result === "geteilt") msg.textContent = `Vollständiges Backup erstellt ✓ (${media.length} Mediendateien). Über „Dateien“ kannst du es in iCloud Drive speichern.${hinweis}`;
    else msg.textContent = `Vollständiges Backup erstellt ✓ (${media.length} Mediendateien).${hinweis}`;
  } catch (err) {
    msg.textContent = `Fehler: ${err.message || err}`;
    debugLog(`❌ Vollständiges Backup: ${err.message || err}`);
  }
}

async function stelleBackupWiederHer(file) {
  const msg = document.getElementById("backup-message");
  if (!file) return;
  if (!confirm("Dieses vollständige Backup in Supabase einspielen? Vorhandene Datensätze mit gleicher ID werden überschrieben; vorhandene Mediendateien bleiben unverändert.")) return;
  msg.textContent = "Backup wird geprüft …";
  try {
    await ensureSession();
    let backup;
    let zipEntries = null;
    if (file.name.toLowerCase().endsWith(".zip") || file.type === "application/zip") {
      const bytes = new Uint8Array(await file.arrayBuffer());
      zipEntries = zipReadDirectory(bytes);
      const backupBytes = zipEntries.get("backup.json");
      if (!backupBytes) throw new Error("backup.json fehlt im Backup.");
      backup = JSON.parse(new TextDecoder().decode(backupBytes));
    } else {
      backup = JSON.parse(await file.text());
    }

    const data = backup.data || backup;
    if (!data || (backup.manifest?.format !== "partezettel-complete-backup" && backup.format !== "partezettel-backup") || !Array.isArray(data.personen) || !Array.isArray(data.familien) || !Array.isArray(data.familien_kinder)) {
      throw new Error("Keine gültige Partezettel-Backup-Datei.");
    }

    const upsertBatch = async (table, rows, label) => {
      const batchSize = 100;
      for (let i = 0; i < rows.length; i += batchSize) {
        const batch = rows.slice(i, i + batchSize);
        if (!batch.length) continue;
        const { error } = await sb.from(table).upsert(batch, { onConflict: "id" });
        if (error) throw new Error(`${label}: ${error.message}`);
      }
    };

    await upsertBatch("personen", data.personen, "Personen");
    await upsertBatch("familien", data.familien || [], "Familien");
    await upsertBatch("familien_kinder", data.familien_kinder || [], "Kinder-Verknüpfungen");
    await upsertBatch("fotos", data.fotos || [], "Foto-Daten");
    await upsertBatch("foto_personen", data.foto_personen || [], "Foto-Personen-Verknüpfungen");
    await upsertBatch("sprachnotizen", data.sprachnotizen || [], "Sprachnotizen");

    let restoredMedia = 0;
    let skippedMedia = 0;
    const media = backup.manifest?.media || [];
    if (zipEntries && media.length) {
      for (let i = 0; i < media.length; i++) {
        const item = media[i];
        msg.textContent = `Mediendateien wiederherstellen … ${i + 1}/${media.length}`;
        const bytes = zipEntries.get(item.zipPath);
        if (!bytes) throw new Error(`Mediendatei fehlt im ZIP: ${item.zipPath}`);

        // Bestehende Datei nicht überschreiben. So benötigt der Restore keine UPDATE-Rechte
        // und ein vorhandenes Original bleibt unangetastet.
        const { data: vorhanden } = await sb.storage.from(item.bucket).download(item.path);
        if (vorhanden) {
          skippedMedia++;
          continue;
        }
        const blob = new Blob([bytes], { type: item.mimeType || "application/octet-stream" });
        const { error } = await sb.storage.from(item.bucket).upload(item.path, blob, {
          upsert: false,
          contentType: item.mimeType || "application/octet-stream",
        });
        if (error) throw new Error(`Mediendatei ${item.path}: ${error.message}`);
        restoredMedia++;
      }
    }

    await loadPersonen();
    if (zipEntries) {
      msg.textContent = `Vollständiges Backup wiederhergestellt ✓ (${data.personen.length} Personen, ${restoredMedia} Mediendateien ergänzt, ${skippedMedia} vorhandene beibehalten).`;
    } else {
      msg.textContent = `Datenbank-Backup wiederhergestellt ✓ (${data.personen.length} Personen).`;
    }
  } catch (err) {
    msg.textContent = `Fehler beim Wiederherstellen: ${err.message || err}`;
    debugLog(`❌ Backup wiederherstellen: ${err.message || err}`);
  }
}

const fotoOptimierenBtn = document.getElementById("foto-optimieren-btn");
if (fotoOptimierenBtn) fotoOptimierenBtn.addEventListener("click", optimiereBestehendeFotos);

const backupBtn = document.getElementById("backup-icloud-btn");
if (backupBtn) backupBtn.addEventListener("click", erstelleICloudBackup);
const backupInput = document.getElementById("backup-restore-input");
if (backupInput) backupInput.addEventListener("change", async (event) => {
  const file = event.target.files?.[0];
  await stelleBackupWiederHer(file);
  event.target.value = "";
});

document.getElementById("export-json-btn").addEventListener("click", async () => {
  const msg = document.getElementById("export-message");
  msg.textContent = "Erstelle JSON …";
  const data = await fetchAllExportData();
  downloadFile("partezettel-export.json", JSON.stringify(data, null, 2), "application/json");
  msg.textContent = "JSON-Datei heruntergeladen ✓";
});

document.getElementById("export-gedcom-btn").addEventListener("click", async () => {
  const msg = document.getElementById("export-message");
  msg.textContent = "Erstelle GEDCOM …";
  const { personen, familien, familien_kinder } = await fetchAllExportData();

  const gedcomDate = (d) => {
    if (!d) return null;
    const [y, m, day] = String(d).slice(0, 10).split("-");
    const monate = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"];
    return `${parseInt(day, 10)} ${monate[parseInt(m, 10) - 1]} ${y}`;
  };
  const clean = (v) => String(v || "").replace(/[\r\n]+/g, " ").trim();
  const personById = new Map(personen.map((p) => [p.id, p]));
  const gidById = new Map();
  personen.forEach((p, i) => gidById.set(p.id, `@I${i + 1}@`));
  const fidById = new Map();
  familien.forEach((f, i) => fidById.set(f.id, `@F${i + 1}@`));

  const famsByPerson = new Map();
  const famcByPerson = new Map();
  for (const f of familien) {
    for (const pid of [f.partner_a_id, f.partner_b_id].filter(Boolean)) {
      if (!famsByPerson.has(pid)) famsByPerson.set(pid, []);
      famsByPerson.get(pid).push(f.id);
    }
  }
  for (const fk of familien_kinder) {
    if (!famcByPerson.has(fk.kind_id)) famcByPerson.set(fk.kind_id, []);
    famcByPerson.get(fk.kind_id).push(fk.familie_id);
  }

  const lines = [
    "0 HEAD",
    "1 SOUR PartezettelArchiv",
    "2 NAME Partezettel Archiv",
    "1 GEDC",
    "2 VERS 5.5.1",
    "1 CHAR UTF-8",
  ];

  for (const p of personen) {
    lines.push(`0 ${gidById.get(p.id)} INDI`);
    lines.push(`1 NAME ${clean(p.vorname)} /${clean(p.nachname)}/`);
    if (p.geschlecht === "männlich") lines.push("1 SEX M");
    else if (p.geschlecht === "weiblich") lines.push("1 SEX F");
    else lines.push("1 SEX U");
    if (p.Ledigenname) lines.push(`1 NOTE Geburtsname: ${clean(p.Ledigenname)}`);
    if (p.geburtsdatum || p.geburtsjahr) {
      lines.push("1 BIRT");
      lines.push(`2 DATE ${p.geburtsdatum ? gedcomDate(p.geburtsdatum) : String(p.geburtsjahr)}`);
    }
    if (p.sterbedatum || p.sterbejahr) { lines.push("1 DEAT"); lines.push(`2 DATE ${p.sterbedatum ? gedcomDate(p.sterbedatum) : String(p.sterbejahr)}`); }
    if (p.Notiz) lines.push(`1 NOTE ${clean(p.Notiz)}`);
    for (const fid of famsByPerson.get(p.id) || []) lines.push(`1 FAMS ${fidById.get(fid)}`);
    for (const fid of famcByPerson.get(p.id) || []) lines.push(`1 FAMC ${fidById.get(fid)}`);
  }

  for (const f of familien) {
    const fid = fidById.get(f.id);
    lines.push(`0 ${fid} FAM`);
    const a = personById.get(f.partner_a_id);
    const b = f.partner_b_id ? personById.get(f.partner_b_id) : null;
    const partners = [a, b].filter(Boolean);
    const male = partners.find((p) => p.geschlecht === "männlich");
    const female = partners.find((p) => p.geschlecht === "weiblich");
    if (male) lines.push(`1 HUSB ${gidById.get(male.id)}`);
    if (female && (!male || female.id !== male.id)) lines.push(`1 WIFE ${gidById.get(female.id)}`);
    if (!male && a) lines.push(`1 HUSB ${gidById.get(a.id)}`);
    if (!female && b && (!male || b.id !== male.id)) lines.push(`1 WIFE ${gidById.get(b.id)}`);
    if (f.beginn) {
      lines.push("1 MARR");
      lines.push(`2 DATE ${gedcomDate(f.beginn)}`);
    }
    if (f.ende) {
      if ((f.familientyp || "").toLowerCase() === "ehe") {
        lines.push("1 DIV");
        lines.push(`2 DATE ${gedcomDate(f.ende)}`);
      } else {
        lines.push(`1 NOTE Ende der ${clean(f.familientyp || "Partnerschaft")}: ${gedcomDate(f.ende)}`);
      }
    }
    if (f.familientyp && f.familientyp.toLowerCase() !== "ehe" && !f.beginn) {
      lines.push(`1 NOTE ${clean(f.familientyp)}`);
    }
    if (f.notiz) lines.push(`1 NOTE ${clean(f.notiz)}`);
    for (const fk of familien_kinder.filter((x) => x.familie_id === f.id)) {
      if (gidById.has(fk.kind_id)) {
        lines.push(`1 CHIL ${gidById.get(fk.kind_id)}`);
        if (fk.beziehungstyp && fk.beziehungstyp !== "biologisch") lines.push(`2 NOTE ${clean(fk.beziehungstyp)}`);
      }
    }
  }

  lines.push("0 TRLR");
  downloadFile("partezettel-export.ged", lines.join("\n"), "text/plain;charset=utf-8");
  msg.textContent = "GEDCOM-Datei heruntergeladen ✓";
});

document.getElementById("export-pdf-btn").addEventListener("click", async () => {
  const msg = document.getElementById("export-message");
  msg.textContent = "Erstelle PDF …";
  const { personen, familien, familien_kinder } = await fetchAllExportData();

  if (!window.jspdf) {
    msg.textContent = "PDF-Bibliothek konnte nicht geladen werden.";
    return;
  }
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  let y = 15;
  const personById = new Map(personen.map((p) => [p.id, p]));
  const name = (id) => {
    const p = personById.get(id);
    return p ? `${p.vorname} ${p.nachname}` : "(unbekannte Person)";
  };
  const addLine = (text, size = 10, bold = false) => {
    if (y > 275) { doc.addPage(); y = 15; }
    doc.setFontSize(size);
    doc.setFont(undefined, bold ? "bold" : "normal");
    const wrapped = doc.splitTextToSize(String(text), 180);
    doc.text(wrapped, 14, y);
    y += wrapped.length * 5 + 1;
  };

  addLine("Partezettel Archiv — Familienübersicht", 16, true);
  y += 3;
  for (const p of personen) {
    addLine(`${p.vorname} ${p.nachname}${p.Ledigenname ? ` geb. ${p.Ledigenname}` : ""}`, 11, true);
    const sterbeJahrAnzeige = p.sterbedatum
      ? p.sterbedatum.split("-")[0]
      : (p.sterbejahr ? String(p.sterbejahr) : "");
    const jahre = [p.geburtsdatum ? p.geburtsdatum.split("-")[0] : (p.geburtsjahr ? String(p.geburtsjahr) : ""), sterbeJahrAnzeige]
      .filter(Boolean)
      .join(" – ");
    if (jahre) addLine(jahre);
    if (p.Notiz) addLine(p.Notiz);
    y += 2;
  }
  if (familien.length) {
    addLine("Familien", 13, true);
    for (const f of familien) {
      const partner = [f.partner_a_id, f.partner_b_id].filter(Boolean).map(name).join(" + ");
      addLine(`${partner} — ${f.familientyp || "Partnerschaft"}`, 10, true);
      const kids = familien_kinder.filter((k) => k.familie_id === f.id);
      for (const k of kids) addLine(`  Kind: ${name(k.kind_id)}${k.beziehungstyp && k.beziehungstyp !== "biologisch" ? ` — ${k.beziehungstyp}` : ""}`);
    }
  }
  doc.save("partezettel-export.pdf");
  msg.textContent = "PDF heruntergeladen ✓";
});

// ===================== Stammbaum v31 =====================
let treeZoom = 1;
let treeData = { personen: [], familien: [], kinder: [], photos: new Map() };

function escTree(value) {
  return String(value ?? "").replace(/[&<>\"]/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
}

function treeNormalizeName(value) {
  return String(value || "").trim().toLocaleLowerCase("de").normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function treeMaleAncestorSurname(personId, seen = new Set()) {
  if (!personId || seen.has(personId)) return "";
  seen.add(personId);
  const person = treePerson(personId);
  if (!person) return "";
  const geschlecht = treeNormalizeName(person.geschlecht);
  if (geschlecht === "m" || geschlecht === "mann" || geschlecht === "maennlich" || geschlecht === "männlich") {
    return String(person.nachname || "").trim();
  }
  const families = treeParentFamiliesForPerson(personId);
  for (const family of families) {
    const candidates = [family.partner_a_id, family.partner_b_id].filter(Boolean);
    for (const candidateId of candidates) {
      const candidate = treePerson(candidateId);
      if (!candidate) continue;
      const candidateGender = treeNormalizeName(candidate.geschlecht);
      if (candidateGender === "m" || candidateGender === "mann" || candidateGender === "maennlich" || candidateGender === "männlich") {
        const surname = treeMaleAncestorSurname(candidateId, seen);
        if (surname) return surname;
      }
    }
  }
  return String(person.nachname || "").trim();
}

function treeLineColorClass(lineSurname) {
  const value = treeNormalizeName(lineSurname);
  if (!value) return "";
  let hash = 0;
  for (let i = 0; i < value.length; i += 1) hash = ((hash << 5) - hash + value.charCodeAt(i)) | 0;
  return `tree-line-color-${Math.abs(hash) % 6}`;
}

function treePersonCard(person, rootId = null, extraClass = "", lineSurname = "") {
  if (!person) return "";
  const jahre = [(person.geburtsdatum ? person.geburtsdatum.split("-")[0] : (person.geburtsjahr ? String(person.geburtsjahr) : "")), (person.sterbedatum ? person.sterbedatum.split("-")[0] : (person.sterbejahr ? String(person.sterbejahr) : ""))].filter(Boolean).join(" – ");
  const foto = treeData.photos.get(person.id);
  const isLinePerson = lineSurname && treeNormalizeName(person.nachname) === treeNormalizeName(lineSurname);
  const lineClass = isLinePerson ? `tree-node--line ${treeLineColorClass(lineSurname)}` : "";
  const relationClass = treeRelationshipSelection.personAId === person.id
    ? "tree-node--relation-a"
    : treeRelationshipSelection.personBId === person.id
      ? "tree-node--relation-b"
      : "";
  return `<button type="button" class="tree-node ${rootId === person.id ? "tree-node--root" : ""} ${relationClass} ${lineClass} ${extraClass}" data-tree-person="${person.id}">
    ${foto ? `<img class="tree-node__photo" src="${escTree(foto)}" alt="Schlüsselfoto von ${escTree(person.vorname)} ${escTree(person.nachname)}">` : `<span class="tree-node__placeholder" aria-hidden="true">👤</span>`}
    <span class="tree-node__name">${escTree(person.vorname)} ${escTree(person.nachname)}</span>
    ${jahre ? `<span class="tree-node__years">${escTree(jahre)}</span>` : ""}
  </button>`;
}

function treePerson(id) {
  return treeData.personen.find((p) => p.id === id) || null;
}

function treeFamiliesForPerson(id) {
  return treeData.familien.filter((f) => f.partner_a_id === id || f.partner_b_id === id);
}

function treeChildrenForFamily(familyId) {
  return treeData.kinder
    .filter((k) => k.familie_id === familyId)
    .map((k) => ({ ...k, person: treePerson(k.kind_id) }))
    .filter((k) => k.person)
    .sort((a, b) => {
      const dateA = a.person.geburtsdatum || "";
      const dateB = b.person.geburtsdatum || "";
      // Kinder werden chronologisch nach dem vollständigen Geburtsdatum angezeigt.
      // Fehlende Geburtsdaten stehen am Ende.
      if (dateA && dateB) return dateA.localeCompare(dateB);
      if (dateA) return -1;
      if (dateB) return 1;
      const nameA = `${a.person.nachname || ""} ${a.person.vorname || ""}`;
      const nameB = `${b.person.nachname || ""} ${b.person.vorname || ""}`;
      return nameA.localeCompare(nameB, "de", { sensitivity: "base" });
    });
}

function treeParentFamiliesForPerson(id) {
  return treeData.kinder.filter((k) => k.kind_id === id).map((k) => treeData.familien.find((f) => f.id === k.familie_id)).filter(Boolean);
}

async function loadStammbaumData() {
  await ensureSession();
  const [{ data: personen, error: personenError }, { data: familien, error: familienError }, { data: kinder, error: kinderError }] = await Promise.all([
    sb.from("personen").select("id, vorname, nachname, geschlecht, geburtsdatum, geburtsjahr, sterbedatum, sterbejahr").order("nachname", { ascending: true }),
    sb.from("familien").select("id, partner_a_id, partner_b_id, familientyp, beginn, ende, ende_automatik_ignorieren"),
    sb.from("familien_kinder").select("id, familie_id, kind_id, beziehungstyp")
  ]);
  if (personenError) throw personenError;
  if (familienError) throw familienError;
  if (kinderError) throw kinderError;

  treeData.personen = personen || [];
  treeData.familien = familien || [];
  treeData.kinder = kinder || [];
  treeData.photos = new Map();

  const ids = treeData.personen.map((p) => p.id);
  if (ids.length) {
    const { data: fotos, error: fotoError } = await sb.from("fotos")
      .select("personen_id, dateipfad, ist_schluesselfoto")
      .in("personen_id", ids)
      .eq("ist_schluesselfoto", true);
    if (fotoError) debugLog(`❌ Stammbaum-Schlüsselfotos: ${fotoError.message}`);
    for (const foto of fotos || []) {
      const { data: signed } = await sb.storage.from(BUCKET_FOTOS).createSignedUrl(foto.dateipfad, 3600);
      if (signed?.signedUrl) treeData.photos.set(foto.personen_id, signed.signedUrl);
    }
  }
}

function treeUniquePeople(ids) {
  const seen = new Set();
  const result = [];
  for (const id of ids || []) {
    if (!id || seen.has(id) || !treePerson(id)) continue;
    seen.add(id);
    result.push(treePerson(id));
  }
  return result;
}

function treeParentIdsForPeople(ids) {
  const parents = [];
  for (const id of ids || []) {
    for (const family of treeParentFamiliesForPerson(id)) {
      if (family.partner_a_id) parents.push(family.partner_a_id);
      if (family.partner_b_id) parents.push(family.partner_b_id);
    }
  }
  return [...new Set(parents)];
}

function treeChildIdsForPeople(ids) {
  const children = [];
  for (const id of ids || []) {
    for (const family of treeFamiliesForPerson(id)) {
      for (const child of treeChildrenForFamily(family.id)) children.push(child.person.id);
    }
  }
  return [...new Set(children)];
}

function treeGenerationName(distance, direction) {
  const names = {
    1: direction === "up" ? "Eltern" : "Kinder",
    2: direction === "up" ? "Großeltern" : "Enkelkinder",
    3: direction === "up" ? "Urgroßeltern" : "Urenkelkinder",
    4: direction === "up" ? "Ururgroßeltern" : "Ururenkelkinder",
    5: direction === "up" ? "Urururgroßeltern" : "Urururenkelkinder"
  };
  return names[distance] || `${distance}. Generation`;
}

function treeGenerationRow(personIds, rootId, stammlinie, label, extraClass = "") {
  const people = treeUniquePeople(personIds);
  if (!people.length) return null;
  const section = document.createElement("div");
  section.className = `tree-deep-generation ${extraClass}`.trim();

  const title = document.createElement("div");
  title.className = "tree-deep-generation__label";
  title.textContent = label;
  section.appendChild(title);

  const row = document.createElement("div");
  row.className = "tree-generation tree-deep-generation__row";
  row.innerHTML = people.map((person) => treePersonCard(person, rootId, "", stammlinie)).join("");
  section.appendChild(row);
  return section;
}

function renderStammbaum(rootId) {
  const stage = document.getElementById("tree-stage");
  const message = document.getElementById("tree-message");
  if (!stage) return;
  stage.innerHTML = "";
  const root = treePerson(rootId);
  if (!root) {
    stage.innerHTML = '<div class="tree-empty">Bitte eine Person auswählen.</div>';
    return;
  }

  const stammlinie = treeMaleAncestorSurname(rootId) || String(root.nachname || "").trim();
  const stammlinieFarbe = treeLineColorClass(stammlinie);

  const legend = document.createElement("div");
  legend.className = `tree-line-legend ${stammlinieFarbe}`;
  legend.innerHTML = `<span class="tree-line-legend__dot" aria-hidden="true"></span><span>Stammlinie: <strong>${escTree(stammlinie || "unbekannt")}</strong></span>`;
  stage.appendChild(legend);

  // Die Stammlinienansicht zeigt mindestens fünf Generationsebenen:
  // zwei Ebenen oberhalb, die ausgewählte Person in der Mitte und zwei Ebenen
  // darunter. Wenn weitere Eltern oder Nachkommen vorhanden sind, werden diese
  // ebenfalls angezeigt. Bereits besuchte Personen verhindern Schleifen.
  const MAX_GENERATIONS = 12;
  const ancestorLevels = [];
  const descendantLevels = [];

  let currentUp = [rootId];
  const seenUp = new Set([rootId]);
  for (let distance = 1; distance <= MAX_GENERATIONS; distance += 1) {
    const next = treeUniquePeople(treeParentIdsForPeople(currentUp))
      .map((p) => p.id)
      .filter((id) => !seenUp.has(id));
    if (!next.length) break;
    next.forEach((id) => seenUp.add(id));
    ancestorLevels.push(next);
    currentUp = next;
  }

  let currentDown = [rootId];
  const seenDown = new Set([rootId]);
  for (let distance = 1; distance <= MAX_GENERATIONS; distance += 1) {
    const next = treeUniquePeople(treeChildIdsForPeople(currentDown))
      .map((p) => p.id)
      .filter((id) => !seenDown.has(id));
    if (!next.length) break;
    next.forEach((id) => seenDown.add(id));
    descendantLevels.push(next);
    currentDown = next;
  }

  // Älteste Vorfahren zuerst, damit der Stammbaum von oben nach unten lesbar ist.
  for (let i = ancestorLevels.length - 1; i >= 0; i -= 1) {
    const distance = i + 1;
    const section = treeGenerationRow(
      ancestorLevels[i],
      rootId,
      stammlinie,
      treeGenerationName(distance, "up"),
      "tree-deep-generation--ancestor"
    );
    if (section) stage.appendChild(section);
  }

  const rootSection = document.createElement("div");
  rootSection.className = "tree-root-generation";
  const rootLabel = document.createElement("div");
  rootLabel.className = "tree-deep-generation__label tree-root-generation__label";
  rootLabel.textContent = `${root.vorname || ""} ${root.nachname || ""}`.trim();
  rootSection.appendChild(rootLabel);

  const rootFamilies = treeFamiliesForPerson(rootId);
  const visibleRootFamilies = rootFamilies.filter((f) => treeChildrenForFamily(f.id).length || f.partner_a_id === rootId || f.partner_b_id === rootId);
  if (visibleRootFamilies.length) {
    for (const f of visibleRootFamilies) {
      const block = document.createElement("div");
      block.className = "tree-family-block tree-root-family-block";
      const otherId = [f.partner_a_id, f.partner_b_id].find((id) => id && id !== rootId);
      const partner = treePerson(otherId);
      const isMarriage = String(f.familientyp || "").toLowerCase() === "ehe";
      const partnerCard = partner
        ? treePersonCard(partner, null, "", stammlinie)
        : `<div class="tree-node"><span class="tree-node__placeholder">?</span><span class="tree-node__name">Unbekannter Partner</span></div>`;
      const relationType = f.familientyp || "Partnerschaft";
      block.innerHTML = `
        <div class="tree-couple">
          ${treePersonCard(root, rootId, "", stammlinie)}
          <div class="tree-relationship ${isMarriage ? "tree-relationship--marriage" : ""}" aria-label="${escTree(relationType)}">
            <span class="tree-marriage__label">${escTree(relationType)}</span>
            ${isMarriage ? `<span class="tree-marriage__rings" aria-hidden="true">◯◯</span>` : `<span class="tree-partner-link" aria-hidden="true"></span>`}
          </div>
          ${partnerCard}
        </div>`;
      rootSection.appendChild(block);
    }
  } else {
    const row = document.createElement("div");
    row.className = "tree-generation tree-deep-generation__row";
    row.innerHTML = treePersonCard(root, rootId, "", stammlinie);
    rootSection.appendChild(row);
  }
  stage.appendChild(rootSection);

  for (let i = 0; i < descendantLevels.length; i += 1) {
    const distance = i + 1;
    const section = treeGenerationRow(
      descendantLevels[i],
      rootId,
      stammlinie,
      treeGenerationName(distance, "down"),
      "tree-deep-generation--descendant"
    );
    if (section) stage.appendChild(section);
  }

  let suppressNextTreeClick = false;
  let lastTreeTouch = { id: null, time: 0 };

  stage.querySelectorAll("[data-tree-person]").forEach((el) => {
    const openTreePerson = async (event) => {
      if (suppressNextTreeClick) {
        suppressNextTreeClick = false;
        if (event) {
          event.preventDefault();
          event.stopPropagation();
        }
        return;
      }
      if (event) event.preventDefault();
      const id = el.dataset.treePerson;
      if (!id) return;
      const select = document.getElementById("tree-person-select");
      if (select) select.value = id;
      renderStammbaum(id);
    };

    el.addEventListener("click", openTreePerson);

    // Desktop: Doppelklick.
    el.addEventListener("dblclick", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      const id = el.dataset.treePerson;
      if (!id) return;
      const select = document.getElementById("tree-person-select");
      if (select) select.value = id;
      await openPersonDetail(id, { fromTree: true });
    });

    // iPad/iPhone: schneller zweiter Fingertipp = Doppelklick.
    el.addEventListener("pointerup", async (event) => {
      if (event.pointerType !== "touch") return;
      const id = el.dataset.treePerson;
      if (!id) return;
      const now = Date.now();
      const isDoubleTap = lastTreeTouch.id === id && (now - lastTreeTouch.time) <= 450;
      if (isDoubleTap) {
        lastTreeTouch = { id: null, time: 0 };
        suppressNextTreeClick = true;
        event.preventDefault();
        event.stopPropagation();
        const select = document.getElementById("tree-person-select");
        if (select) select.value = id;
        await openPersonDetail(id, { fromTree: true });
      } else {
        lastTreeTouch = { id, time: now };
      }
    });
  });
  if (message) message.textContent = "";
}


function treePersonGender(person) {
  const g = String(person?.geschlecht || "").toLowerCase();
  if (g.includes("weib")) return "w";
  if (g.includes("männ") || g.includes("maenn") || g === "m") return "m";
  return "u";
}

let treeRelationshipSelection = { personAId: null, personBId: null };

function treePersonLabel(id) {
  const p = treePerson(id);
  return p ? `${p.vorname || ""} ${p.nachname || ""}`.trim() : "Unbekannt";
}

function treeRelationshipModel() {
  const parentMap = new Map();
  const childMap = new Map();
  const add = (map, key, value) => {
    if (!key || !value || key === value) return;
    if (!map.has(key)) map.set(key, new Set());
    map.get(key).add(value);
  };

  // Das Verwandtschaftsmodell arbeitet ausschließlich mit echten
  // Eltern-Kind-Verbindungen. Ehe/Partnerschaft wird separat behandelt.
  for (const family of treeData.familien || []) {
    const parents = [family.partner_a_id, family.partner_b_id].filter(Boolean);
    if (!parents.length) continue;
    for (const childLink of treeData.kinder.filter((k) => k.familie_id === family.id)) {
      const childId = childLink.kind_id;
      if (!childId || !treePerson(childId)) continue;
      for (const parentId of parents) {
        if (!treePerson(parentId)) continue;
        add(parentMap, childId, parentId);
        add(childMap, parentId, childId);
      }
    }
  }
  return { parentMap, childMap };
}

function treeAncestorDistances(startId, model) {
  const distances = new Map([[startId, 0]]);
  const queue = [startId];
  while (queue.length) {
    const id = queue.shift();
    const distance = distances.get(id) || 0;
    for (const parentId of model.parentMap.get(id) || []) {
      if (distances.has(parentId)) continue;
      distances.set(parentId, distance + 1);
      queue.push(parentId);
    }
  }
  return distances;
}

function treeChooseCommonAncestor(aId, bId, model) {
  const aAncestors = treeAncestorDistances(aId, model);
  const bAncestors = treeAncestorDistances(bId, model);
  const candidates = [];
  for (const [ancestorId, aDistance] of aAncestors) {
    if (ancestorId === aId || ancestorId === bId) continue;
    const bDistance = bAncestors.get(ancestorId);
    if (bDistance == null) continue;
    candidates.push({ ancestorId, aDistance, bDistance });
  }
  candidates.sort((x, y) =>
    (x.aDistance + x.bDistance) - (y.aDistance + y.bDistance) ||
    Math.max(x.aDistance, x.bDistance) - Math.max(y.aDistance, y.bDistance)
  );
  return candidates[0] || null;
}

function treeParentPathToAncestor(startId, ancestorId, model) {
  if (startId === ancestorId) return [];
  const queue = [startId];
  const visited = new Set([startId]);
  const prev = new Map();
  while (queue.length) {
    const id = queue.shift();
    for (const parentId of model.parentMap.get(id) || []) {
      if (visited.has(parentId)) continue;
      visited.add(parentId);
      prev.set(parentId, id);
      if (parentId === ancestorId) {
        const ids = [];
        let cur = ancestorId;
        while (cur !== startId) {
          ids.unshift(cur);
          cur = prev.get(cur);
          if (!cur) return null;
        }
        return ids;
      }
      queue.push(parentId);
    }
  }
  return null;
}

function treeSiblingPath(aId, bId, model) {
  const aParents = model.parentMap.get(aId) || new Set();
  const bParents = model.parentMap.get(bId) || new Set();
  for (const parentId of aParents) {
    if (bParents.has(parentId)) return { parentId };
  }
  return null;
}

function treeBloodRelationFromDistances(aId, bId, aDistance, bDistance) {
  const target = treePerson(bId);
  const targetGender = treePersonGender(target);
  const source = treePerson(aId);
  const sourceGender = treePersonGender(source);
  const word = (male, female) => targetGender === "m" ? male : targetGender === "w" ? female : male;
  const sourceWord = (male, female) => sourceGender === "m" ? male : sourceGender === "w" ? female : male;

  if (aDistance === 1 && bDistance === 1) return sourceWord("Bruder", "Schwester");

  // A ist direkter Vorfahr von B.
  if (aDistance === 0) {
    if (bDistance === 1) return sourceWord("Vater", "Mutter");
    if (bDistance === 2) return sourceWord("Großvater", "Großmutter");
    return `${"Ur".repeat(bDistance - 2)}groß${sourceWord("vater", "mutter")}`;
  }

  // A ist direkter Nachkomme von B.
  if (bDistance === 0) {
    if (aDistance === 1) return sourceWord("Sohn", "Tochter");
    if (aDistance === 2) return sourceWord("Enkel", "Enkelin");
    return `${"Ur".repeat(aDistance - 2)}enkel${sourceGender === "w" ? "in" : ""}`;
  }

  // Seitenlinie: gleicher gemeinsamer Vorfahr.
  if (aDistance === 1 && bDistance >= 2) {
    const grade = bDistance - 2;
    if (grade === 0) return sourceWord("Onkel", "Tante");
    if (grade === 1) return sourceWord("Großonkel (1. Grades)", "Großtante (1. Grades)");
    return sourceWord(`${"Ur".repeat(grade - 1)}großonkel (${grade}. Grades)`, `${"Ur".repeat(grade - 1)}großtante (${grade}. Grades)`);
  }

  if (bDistance === 1 && aDistance >= 2) {
    const grade = aDistance - 2;
    if (grade === 0) return sourceWord("Neffe", "Nichte");
    if (grade === 1) return sourceWord("Großneffe (1. Grades)", "Großnichte (1. Grades)");
    return sourceWord(`${"Ur".repeat(grade - 1)}großneffe (${grade}. Grades)`, `${"Ur".repeat(grade - 1)}großnichte (${grade}. Grades)`);
  }

  if (aDistance >= 2 && bDistance >= 2) {
    const cousinDegree = Math.min(aDistance, bDistance) - 1;
    const removed = Math.abs(aDistance - bDistance);
    const base = `Cousin/Cousine ${cousinDegree}. Grades`;
    return removed ? `${base}, ${removed} Generation${removed === 1 ? "" : "en"} entfernt` : base;
  }
  return null;
}

function treeBloodRelationship(aId, bId, model) {
  const sibling = treeSiblingPath(aId, bId, model);
  if (sibling) {
    return {
      relation: treeGenderWord(aId, "Bruder", "Schwester"),
      commonAncestor: sibling.parentId,
      aDistance: 1,
      bDistance: 1
    };
  }

  const aAncestors = treeAncestorDistances(aId, model);
  const bAncestors = treeAncestorDistances(bId, model);

  // Direkte Vorfahren/Nachkommen müssen vor dem gemeinsamen Vorfahren geprüft werden.
  if (aAncestors.has(bId)) {
    const distance = aAncestors.get(bId);
    return { relation: treeBloodRelationFromDistances(aId, bId, distance, 0), commonAncestor: bId, aDistance: distance, bDistance: 0 };
  }
  if (bAncestors.has(aId)) {
    const distance = bAncestors.get(aId);
    return { relation: treeBloodRelationFromDistances(aId, bId, 0, distance), commonAncestor: aId, aDistance: 0, bDistance: distance };
  }

  const common = treeChooseCommonAncestor(aId, bId, model);
  if (!common) return null;
  return {
    relation: treeBloodRelationFromDistances(aId, bId, common.aDistance, common.bDistance),
    commonAncestor: common.ancestorId,
    aDistance: common.aDistance,
    bDistance: common.bDistance
  };
}

function treeRelationshipGraph() {
  // Kompatibilität für die bestehende UI und für angeheiratete Beziehungen.
  const graph = new Map();
  const add = (a, b, type) => {
    if (!a || !b || a === b) return;
    if (!graph.has(a)) graph.set(a, []);
    graph.get(a).push({ id: b, type });
  };
  for (const f of treeData.familien || []) {
    const a = f.partner_a_id, b = f.partner_b_id;
    if (a && b) { add(a, b, "spouse"); add(b, a, "spouse"); }
    for (const k of treeChildrenForFamily(f.id)) {
      const child = k.person?.id || k.kind_id;
      if (!child) continue;
      if (a) { add(child, a, "parent"); add(a, child, "child"); }
      if (b) { add(child, b, "parent"); add(b, child, "child"); }
    }
  }
  return graph;
}

function treeFindRelationshipPath(startId, targetId) {
  if (!startId || !targetId) return null;
  if (startId === targetId) return [];
  const graph = treeRelationshipGraph();
  const queue = [startId];
  const visited = new Set([startId]);
  const prev = new Map();
  while (queue.length) {
    const id = queue.shift();
    for (const edge of graph.get(id) || []) {
      if (visited.has(edge.id)) continue;
      visited.add(edge.id);
      prev.set(edge.id, { from: id, type: edge.type });
      if (edge.id === targetId) {
        const path = [];
        let cur = targetId;
        while (cur !== startId) {
          const step = prev.get(cur);
          if (!step) return null;
          path.unshift({ from: step.from, to: cur, type: step.type });
          cur = step.from;
        }
        return path;
      }
      queue.push(edge.id);
    }
  }
  return null;
}

function treeGenderWord(id, male, female, neutral = "Person") {
  const g = treePersonGender(treePerson(id));
  return g === "m" ? male : g === "w" ? female : neutral;
}

function treeInLawRelation(path) {
  const spouseIndexes = path.map((e, i) => e.type === "spouse" ? i : -1).filter(i => i >= 0);
  if (!spouseIndexes.length) return null;
  if (path.length === 1) return treeGenderWord(path[0].to, "Ehemann", "Ehefrau");
  if (path.length === 2) {
    const spouseEdge = path.find(e => e.type === "spouse");
    const other = path.find(e => e !== spouseEdge);
    if (other?.type === "parent") return treeGenderWord(path[path.length - 1].to, "Schwiegersohn", "Schwiegertochter");
    if (other?.type === "child") return treeGenderWord(path[path.length - 1].to, "Schwiegervater", "Schwiegermutter");
  }
  const bloodOnly = path.filter(e => e.type !== "spouse");
  if (bloodOnly.length === 2 && bloodOnly.some(e => e.type === "parent") && bloodOnly.some(e => e.type === "child")) {
    return treeGenderWord(path[path.length - 1].to, "Schwager", "Schwägerin");
  }
  if (bloodOnly.length === 1) {
    const e = bloodOnly[0];
    if (e.type === "parent") return treeGenderWord(path[path.length - 1].to, "Schwiegervater", "Schwiegermutter");
    if (e.type === "child") return treeGenderWord(path[path.length - 1].to, "Schwiegersohn", "Schwiegertochter");
  }
  return "angeheiratet verwandt";
}

function treeRelationshipStepWord(fromId, edgeType, toId) {
  if (edgeType === "sibling") {
    return treeGenderWord(fromId, "Bruder", "Schwester") + " von";
  }

  if (edgeType === "spouse") {
    return treeGenderWord(fromId, "Ehemann", "Ehefrau") + " von";
  }

  // parent: from = Kind, to = Elternteil
  if (edgeType === "parent") {
    return treeGenderWord(fromId, "Sohn", "Tochter") + " von";
  }

  // child: from = Elternteil, to = Kind
  // Die Bezeichnung beschreibt die Beziehung der oberen Person zur
  // darunterliegenden Person. Deshalb entscheidet das Geschlecht
  // des Elternteils (fromId):
  // Vater -> Tochter/Sohn = "Vater von"
  // Mutter -> Tochter/Sohn = "Mutter von"
  const fromGender = treePersonGender(treePerson(fromId));
  if (fromGender === "m") return "Vater von";
  if (fromGender === "w") return "Mutter von";
  return "Elternteil von";
}

function treeBuildBloodPath(aId, bId, model, blood) {
  if (!blood) return null;
  if (blood.aDistance === 1 && blood.bDistance === 1) {
    return [{ from: aId, to: bId, type: "sibling" }];
  }

  const aToAncestor = treeParentPathToAncestor(aId, blood.commonAncestor, model) || [];
  const bToAncestor = treeParentPathToAncestor(bId, blood.commonAncestor, model) || [];

  // Der Pfad soll aus Sicht der gewählten Startperson verlaufen.
  // Bei einer Seitenlinie wird deshalb nicht über den gemeinsamen Vorfahren
  // „hinweg“ gezeichnet. Stattdessen verbinden wir die beiden Äste über
  // deren Geschwister auf der Ebene direkt unterhalb des gemeinsamen
  // Vorfahren. Dadurch entsteht z. B.:
  //
  // Oskar → Paula → Hubert → Andreas
  //
  // und nicht eine technisch richtige, aber für den Benutzer verwirrende
  // Darstellung über den gemeinsamen Großeltern-Knoten.
  const path = [];
  let current = aId;

  // Direkter Vorfahren-/Nachkommenpfad.
  // Der gemeinsame Knoten ist bei einem direkten Vorfahren bereits
  // die Startperson und darf deshalb niemals nochmals als Pfadknoten
  // eingefügt werden.
  if (blood.aDistance === 0 || blood.bDistance === 0) {
    if (blood.aDistance === 0) {
      const childPath = [...bToAncestor]
        .filter((id) => id !== blood.commonAncestor)
        .reverse();

      for (const childId of childPath) {
        if (childId === current) continue;
        path.push({ from: current, to: childId, type: "child" });
        current = childId;
      }

      if (current !== bId) {
        path.push({ from: current, to: bId, type: "child" });
      }
    } else {
      for (const parentId of aToAncestor) {
        if (parentId === blood.commonAncestor && parentId === current) continue;
        path.push({ from: current, to: parentId, type: "parent" });
        current = parentId;
      }
    }
    return path;
  }

  // Beide Personen liegen in unterschiedlichen Ästen desselben Vorfahren.
  // Zuerst von A bis zum Geschwisterknoten des B-Zweigs.
  const aBranch = aToAncestor.length >= 2 ? aToAncestor[aToAncestor.length - 2] : aId;
  const bBranch = bToAncestor.length >= 2 ? bToAncestor[bToAncestor.length - 2] : bId;

  if (aBranch && bBranch && aBranch !== bBranch) {
    // Von A nur bis zum ersten Knoten unterhalb des gemeinsamen Vorfahren.
    // Wichtig: Der gemeinsame Vorfahr selbst darf NICHT in den sichtbaren
    // Verwandtschaftspfad aufgenommen werden. Beispiel:
    // Oskar -> Paula -> Hubert -> Andreas, nicht Oskar -> Christian -> ...
    for (const parentId of aToAncestor) {
      if (parentId === blood.commonAncestor) break;
      path.push({ from: current, to: parentId, type: "parent" });
      current = parentId;
    }

    // Die beiden Knoten direkt unterhalb des gemeinsamen Vorfahren sind
    // Geschwister. Bei einem direkten Geschwisterfall ist A selbst aBranch.
    if (current === aBranch) {
      path.push({ from: current, to: bBranch, type: "sibling" });
      current = bBranch;
    } else {
      return null;
    }

    // Vom Geschwisterknoten des B-Zweigs nach unten bis zu B.
    const bDown = [...bToAncestor].reverse().filter(
      (id) => id !== blood.commonAncestor && id !== bBranch
    );
    for (const childId of bDown) {
      path.push({ from: current, to: childId, type: "child" });
      current = childId;
    }

    // Nur anhängen, wenn B nicht bereits erreicht wurde. Dadurch kann ein
    // Knoten niemals doppelt im sichtbaren Pfad erscheinen.
    if (current !== bId) {
      path.push({ from: current, to: bId, type: "child" });
    }
    return path;
  }

  // Fallback für ungewöhnliche Graphen: sauberer gerichteter Pfad.
  for (const parentId of aToAncestor) {
    path.push({ from: current, to: parentId, type: "parent" });
    current = parentId;
  }
  const down = [...bToAncestor].reverse();
  for (const childId of down) {
    if (childId === blood.commonAncestor || childId === current) continue;
    path.push({ from: current, to: childId, type: "child" });
    current = childId;
  }
  path.push({ from: current, to: bId, type: "child" });
  return path;
}

function treeHumanRelationshipPath(aId, path) {
  if (!path || !path.length) return "";
  const steps = [];
  let currentId = aId;
  for (const e of path) {
    steps.push(`${treeRelationshipStepWord(currentId, e.type, e.to)} ${treePersonLabel(e.to)}`);
    currentId = e.to;
  }
  return steps.join(" → ");
}

function treeRelationshipPathGraphic(aId, path) {
  if (!path || !path.length) return "";
  const items = [{ id: aId, label: treePersonLabel(aId) }];
  let currentId = aId;
  for (const edge of path) {
    const relationLabel = treeRelationshipStepWord(currentId, edge.type, edge.to);
    items.push({ id: edge.to, label: treePersonLabel(edge.to), relationLabel });
    currentId = edge.to;
  }
  return `<div class="tree-relationship-graphic" aria-label="Grafischer Verwandtschaftspfad">${items.map((item, index) => {
    const person = treePerson(item.id);
    const dates = person ? [person.geburtsjahr, person.sterbejahr].filter(Boolean).join("–") : "";
    const card = `<div class="tree-relationship-node" data-tree-relation-node="${escTree(item.id)}"><strong>${escTree(item.label)}</strong>${dates ? `<small>${escTree(String(dates))}</small>` : ""}</div>`;
    if (index === 0) return card;
    return `<div class="tree-relationship-arrow" aria-hidden="true"><span>${escTree(item.relationLabel)}</span><b>↓</b></div>${card}`;
  }).join("")}</div>`;
}

function treeRelationshipSentence(aId, bId, relation) {
  const a = treePersonLabel(aId);
  const b = treePersonLabel(bId);
  if (!relation || relation === "dieselbe Person") return relation ? `${a} und ${b} sind dieselbe Person.` : "";
  return `${a} ist ${relation.toLowerCase()} von ${b}.`;
}

function treeRelationshipResult(aId, bId) {
  if (!aId || !bId) return null;
  if (aId === bId) return { relation: "dieselbe Person", path: [] };

  const model = treeRelationshipModel();
  const blood = treeBloodRelationship(aId, bId, model);
  if (blood?.relation) {
    const path = treeBuildBloodPath(aId, bId, model, blood);
    return {
      relation: blood.relation,
      path: path || [],
      sentence: treeRelationshipSentence(aId, bId, blood.relation),
      pathText: treeHumanRelationshipPath(aId, path || [])
    };
  }

  // Falls keine Blutsverwandtschaft existiert, bleibt die bisherige
  // angeheiratete Ermittlung erhalten.
  const path = treeFindRelationshipPath(aId, bId);
  if (!path) return { relation: "Keine gespeicherte Verwandtschaft gefunden", path: null };
  const relation = treeInLawRelation(path) || "verwandt (genauer Verwandtschaftsgrad nicht eindeutig bestimmbar)";
  return {
    relation,
    path,
    sentence: treeRelationshipSentence(aId, bId, relation),
    pathText: treeHumanRelationshipPath(aId, path)
  };
}

function fillTreeRelationshipSelects() {
  const selects = [document.getElementById("tree-relation-person-a"), document.getElementById("tree-relation-person-b")].filter(Boolean);
  const current = selects.map(s => s.value);
  const personen = [...(treeData.personen || [])].sort(personenAuswahlSortierung);
  for (const select of selects) {
    select.innerHTML = '<option value="">— Person auswählen —</option>';
    for (const p of personen) {
      const opt = document.createElement("option");
      opt.value = p.id;
      opt.textContent = treePersonSearchText(p);
      select.appendChild(opt);
    }
  }
  selects.forEach((s, i) => { if (current[i] && treePerson(current[i])) s.value = current[i]; });
}

function initTreeRelationshipUI() {
  const open = document.getElementById("tree-relationship-open");
  const close = document.getElementById("tree-relationship-close");
  const panel = document.getElementById("tree-relationship-panel");
  const calc = document.getElementById("tree-relationship-calc");
  const reset = document.getElementById("tree-relationship-reset");
  const a = document.getElementById("tree-relation-person-a");
  const b = document.getElementById("tree-relation-person-b");
  const result = document.getElementById("tree-relationship-result");
  if (!open || !panel || !calc || !reset || !a || !b || !result) return;
  open.addEventListener("click", () => {
    panel.hidden = false;
    fillTreeRelationshipSelects();
    if (!a.value && treeSelect?.value) a.value = treeSelect.value;
  });
  close?.addEventListener("click", () => { panel.hidden = true; });
  reset.addEventListener("click", () => {
    a.value = "";
    b.value = "";
    result.innerHTML = "";
    treeRelationshipSelection = { personAId: null, personBId: null };
    const treeSelectElement = document.getElementById("tree-person-select");
    if (treeSelectElement?.value) renderStammbaum(treeSelectElement.value);
  });
  calc.addEventListener("click", () => {
    const personAId = a.value;
    const personBId = b.value;
    const found = treeRelationshipResult(personAId, personBId);
    if (!found) { result.innerHTML = "Bitte zwei Personen auswählen."; return; }

    treeRelationshipSelection = { personAId, personBId };
    const treeSelectElement = document.getElementById("tree-person-select");
    if (treeSelectElement && personAId && treePerson(personAId)) {
      treeSelectElement.value = personAId;
      renderStammbaum(personAId);
    }
    if (found.path === null) { result.innerHTML = `<strong>${escTree(found.relation)}</strong>`; return; }
    result.innerHTML = `<strong>${escTree(found.relation)}</strong>${found.sentence ? `<div class="tree-relationship-sentence">${escTree(found.sentence)}</div>` : ""}${found.pathText ? `<div class="tree-relationship-path"><span class="tree-relationship-path-title">So ergibt sich die Beziehung:</span>${escTree(found.pathText)}</div>` : ""}${found.path?.length ? treeRelationshipPathGraphic(a.value, found.path) : ""}`;
  });
}

function treePersonSearchText(person) {
  return personenAuswahlText(person);
}

function fillTreePersonSelect(searchValue = "", preferredId = "") {
  const select = document.getElementById("tree-person-select");
  if (!select) return "";
  const query = treeNormalizeName(searchValue);
  const previous = preferredId || select.value;
  const matches = (treeData.personen || []).filter((p) => {
    if (!query) return true;
    const haystack = treeNormalizeName(`${p.vorname || ""} ${p.nachname || ""} ${p.geburtsjahr || ""} ${p.geburtsdatum || ""}`);
    return haystack.includes(query);
  });
  select.innerHTML = `<option value="">— Person auswählen —</option>`;
  for (const p of matches) {
    const opt = document.createElement("option");
    opt.value = p.id;
    opt.textContent = treePersonSearchText(p);
    select.appendChild(opt);
  }
  if (previous && matches.some((p) => p.id === previous)) {
    select.value = previous;
  } else if (matches.length === 1) {
    select.value = matches[0].id;
  }
  return select.value;
}

async function loadStammbaum() {
  const message = document.getElementById("tree-message");
  const select = document.getElementById("tree-person-select");
  const search = document.getElementById("tree-person-search");
  try {
    message.textContent = "Stammbaum wird geladen …";
    await loadStammbaumData();
    if (!treeData.personen.length) {
      select.innerHTML = '<option value="">— keine Personen vorhanden —</option>';
      renderStammbaum("");
      message.textContent = "";
      return;
    }
    const current = select.value && treePerson(select.value) ? select.value : treeData.personen[0].id;
    fillTreePersonSelect(search?.value || "", current);
    if (!select.value) {
      select.value = current;
    }
    renderStammbaum(select.value);
    fillTreeRelationshipSelects();
    message.textContent = "";
  } catch (err) {
    message.textContent = `Fehler beim Laden des Stammbaums: ${err.message || err}`;
    debugLog(`❌ Stammbaum: ${err.message || err}`);
  }
}

function updateTreeZoom() {
  const stage = document.getElementById("tree-stage");
  const value = document.getElementById("tree-zoom-value");
  if (stage) stage.style.transform = `scale(${treeZoom})`;
  if (value) value.textContent = `${Math.round(treeZoom * 100)} %`;
}

const treeSelect = document.getElementById("tree-person-select");
const treePersonSearch = document.getElementById("tree-person-search");
if (treeSelect) treeSelect.addEventListener("change", () => renderStammbaum(treeSelect.value));
if (treePersonSearch) treePersonSearch.addEventListener("input", () => {
  const selected = fillTreePersonSelect(treePersonSearch.value, treeSelect?.value || "");
  if (selected) renderStammbaum(selected);
});
const treeZoomIn = document.getElementById("tree-zoom-in");
const treeZoomOut = document.getElementById("tree-zoom-out");
const treeReset = document.getElementById("tree-reset");
if (treeZoomIn) treeZoomIn.addEventListener("click", () => { treeZoom = Math.min(1.5, +(treeZoom + 0.1).toFixed(2)); updateTreeZoom(); });
if (treeZoomOut) treeZoomOut.addEventListener("click", () => { treeZoom = Math.max(0.6, +(treeZoom - 0.1).toFixed(2)); updateTreeZoom(); });
if (treeReset) treeReset.addEventListener("click", () => { treeZoom = 1; updateTreeZoom(); });
updateTreeZoom();
initTreeRelationshipUI();
